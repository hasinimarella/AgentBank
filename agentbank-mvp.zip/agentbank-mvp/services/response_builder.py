"""Builds user-facing text strictly from agent/tool results. No model output, no invention."""
from __future__ import annotations

import json
import re
from typing import Any

from agents.base import AgentResult
from llm.base import Intent

SIM_NOTE = "_Simulated data. This is a demonstration system, not real banking._"


def format_inr(value: float | int | None, decimals: int = 2) -> str:
    """Format with Indian digit grouping, e.g. 1234567.5 -> ₹12,34,567.50"""
    if value is None:
        return "not available"
    neg = value < 0
    s = f"{abs(float(value)):.{decimals}f}"
    whole, _, frac = s.partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups: list[str] = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{'-' if neg else ''}₹{whole}" + (f".{frac}" if decimals else "")


def clarification_message(intent: Intent, missing: list[str], hint: str | None = None) -> str:
    needs = " and ".join(missing)
    examples = {
        Intent.ACCOUNT_BALANCE: "What is the account balance for customer C1001?",
        Intent.TRANSACTION_HISTORY: "Show the last five transactions for customer C1002.",
        Intent.FRAUD_ASSESSMENT: "Check transaction TXN-9003 for fraud risk.",
        Intent.LOAN_ELIGIBILITY: "Is customer C1001 eligible for a loan of ₹200000?",
        Intent.CUSTOMER_FINANCIAL_SUMMARY: "Give me a complete financial summary for customer C1003.",
        Intent.SPENDING_ANALYSIS: "Show the monthly spending analysis for customer C1002.",
    }
    text = f"I can help with that, but I still need the {needs}."
    if hint:
        text += f" {hint}"
    if intent in examples:
        text += f"\n\nFor example: _{examples[intent]}_"
    return text


UNKNOWN_MESSAGE = (
    "I'm not sure how to help with that. This simulator can:\n\n"
    "- show an **account balance** (e.g. _What is the account balance for customer C1001?_)\n"
    "- list **transactions** (e.g. _Show the last five transactions for customer C1002._)\n"
    "- run a **fraud-risk check** (e.g. _Check transaction TXN-9003 for fraud risk._)\n"
    "- assess **loan eligibility** (e.g. _Is customer C1001 eligible for a loan of ₹200000?_)\n"
    "- give a **financial summary** (e.g. _Give me a complete financial summary for customer C1003._)\n"
    "- analyse **monthly spending** (e.g. _Show the monthly spending analysis for customer C1002._)"
)

UNSUPPORTED_ACTION_MESSAGE = (
    "This simulator is read-only. It cannot transfer money, make payments, freeze or block accounts, "
    "approve loans or change any records. I can look up balances, transactions, fraud-risk scores, "
    "illustrative loan eligibility and financial summaries."
)


def _error_text(result: AgentResult) -> str:
    err = result.errors[0] if result.errors else {"code": "ERROR", "message": "Unknown error."}
    if result.status == "not_found":
        return f"I couldn't find that record. {err['message']} Please check the ID and try again."
    if result.status == "invalid_input":
        return f"That input isn't valid: {err['message']}"
    return ("Something went wrong while running a banking tool "
            f"({err.get('tool', 'tool')}: {err.get('code', 'ERROR')}). No data was changed. Please try again.")


def build_response(intent: Intent, result: AgentResult) -> str:
    if not result.succeeded:
        return _error_text(result)
    d = result.data
    t = result.result_type
    if t == "balance":
        return _balance(d)
    if t in ("transactions", "transaction"):
        return _transactions(d)
    if t == "fraud":
        return _fraud(d)
    if t == "loan":
        return _loan(d)
    if t == "summary":
        return _summary(d, result)
    if t == "spending":
        return _spending(d)
    return "Done."


def _balance(d: dict[str, Any]) -> str:
    c, b = d["customer"], d["balance"]
    lines = [f"**{c['full_name']}** ({c['customer_id']}) has a total balance of **{format_inr(b['total_balance'])}** "
             f"across {len(b['accounts'])} account(s):", ""]
    for a in b["accounts"]:
        lines.append(f"- {a['account_id']} · {a['account_type'].title()} · {format_inr(a['balance'])} · status **{a['status']}**")
    dormant = [a for a in b["accounts"] if a["status"] != "ACTIVE"]
    if dormant:
        lines += ["", "Note: at least one account is not ACTIVE; balances are shown as recorded."]
    return "\n".join(lines + ["", SIM_NOTE])


def _transactions(d: dict[str, Any]) -> str:
    if "transaction" in d:
        t = d["transaction"]
        return (f"Transaction **{t['transaction_id']}** for customer {t['customer_id']}: "
                f"{t['direction'].title()} of **{format_inr(t['amount'])}** at {t['merchant']} "
                f"({t['city']}, {t['country']}) on {t['occurred_at'].replace('T', ' ')}, status **{t['status']}**.\n\n{SIM_NOTE}")
    c, h = d["customer"], d["history"]
    if h["returned"] == 0:
        filt = d.get("filters", {})
        extra = " matching your filters" if any(k in filt for k in ("status", "start_date", "end_date", "transaction_id")) else ""
        return f"No transactions{extra} were found for **{c['full_name']}** ({c['customer_id']}).\n\n{SIM_NOTE}"
    lines = [f"Showing {h['returned']} of {h['total_matching']} transaction(s) for **{c['full_name']}** ({c['customer_id']}), newest first:", ""]
    for t in h["transactions"]:
        sign = "+" if t["direction"] == "CREDIT" else "-"
        lines.append(f"- `{t['transaction_id']}` · {t['occurred_at'][:16].replace('T', ' ')} · {sign}{format_inr(t['amount'])} · "
                     f"{t['merchant']} · {t['status']}")
    return "\n".join(lines + ["", SIM_NOTE])


def _fraud(d: dict[str, Any]) -> str:
    a, t = d["assessment"], d["transaction"]
    lines = [
        f"Transaction **{a['transaction_id']}** ({format_inr(t['amount'])} at {t['merchant']}, {t['city']}, {t['country']}) "
        f"scored **{a['risk_score']}/100**, risk level **{a['risk_level']}** (recommended action: **{a['recommended_action']}**).",
        "",
        "**Why:**",
    ]
    if a["contributing_indicators"]:
        for i in a["contributing_indicators"]:
            lines.append(f"- +{i['points']} {i['indicator'].replace('_', ' ')}: {i['reason']}")
    else:
        lines.append("- No risk indicators were triggered.")
    lines += ["", "**Suggested next steps:**"] + [f"- {r}" for r in a["recommendations"]]
    lines += ["", f"_{a['disclaimer']}_ Engine: {a['engine']['name']} ({a['engine']['kind']})."]
    return "\n".join(lines)


def _loan(d: dict[str, Any]) -> str:
    a, c = d["assessment"], d["customer"]
    labels = {"ELIGIBLE": "ELIGIBLE (illustrative)", "REFER_TO_REVIEW": "REFER TO REVIEW (illustrative)",
              "NOT_ELIGIBLE": "NOT ELIGIBLE (illustrative)", "INSUFFICIENT_DATA": "INSUFFICIENT DATA"}
    lines = [f"Loan assessment for **{c['full_name']}** ({c['customer_id']}), requested amount "
             f"**{format_inr(a['requested_amount'], 0)}**: **{labels[a['decision']]}**.", ""]
    if a["decision"] != "INSUFFICIENT_DATA":
        lines.append(f"Estimated monthly payment: {format_inr(a['estimated_monthly_payment'])} "
                     f"(assumes {a['assumptions']['annual_interest_rate']:.0%} p.a. over {a['assumptions']['tenure_months']} months). "
                     f"Debt-to-income: {a['dti_before_loan']:.1%} now, {a['dti_after_loan']:.1%} after the loan.")
        lines.append("")
    lines.append("**Reasons:**")
    lines += [f"- {r}" for r in a["reasons"]]
    if a["missing_information"]:
        lines += ["", "**Missing information:** " + ", ".join(a["missing_information"])]
    lines += ["", "**Recommendations:**"] + [f"- {r}" for r in a["recommendations"]]
    lines += ["", f"_{a['disclaimer']}_ Engine: {a['engine']['name']} ({a['engine']['kind']})."]
    return "\n".join(lines)


def _spending(d: dict[str, Any]) -> str:
    c, s = d["customer"], d["spending"]
    if s["month"] is None or s["transaction_count"] == 0:
        extra = f" for {s['month']}" if s["month"] else ""
        months = f" Months with spending: {', '.join(s['available_months'])}." if s["available_months"] else ""
        return f"No completed spending was found{extra} for **{c['full_name']}** ({c['customer_id']}).{months}\n\n{SIM_NOTE}"
    lines = [f"**Spending for {c['full_name']}** ({c['customer_id']}) in **{s['month']}**: "
             f"**{format_inr(s['total_spent'])}** across {s['transaction_count']} completed debit(s) "
             f"(average {format_inr(s['average_per_transaction'])}).", "", "**By category:**"]
    for cat in s["by_category"]:
        lines.append(f"- {cat['category'].replace('_', ' ').title()}: {format_inr(cat['amount'])} ({cat['share']:.0%})")
    if s["top_merchants"]:
        lines += ["", "**Top merchants:** " + ", ".join(f"{m['merchant']} {format_inr(m['amount'], 0)}" for m in s["top_merchants"])]
    if not s["month_was_requested"]:
        lines += ["", f"_No month was specified, so the most recent month with spending was used. Available: {', '.join(s['available_months'])}._"]
    return "\n".join(lines + ["", f"_{s['basis']}_ {SIM_NOTE}"])


def _summary(d: dict[str, Any], result: AgentResult) -> str:
    s = d["summary"]
    lines = [f"**Financial summary for {s['full_name']}** ({s['customer_id']}) · KYC {s['kyc_status']} · customer since {s['customer_since']}", ""]
    if "total_balance" in s:
        lines.append(f"- **Total balance:** {format_inr(s['total_balance'])} across {s['account_count']} account(s)")
    act = s.get("activity")
    if act:
        if act["transactions_analysed"] == 0:
            lines.append("- **Activity:** no transactions on file.")
        else:
            lines.append(f"- **Activity ({act['transactions_analysed']} transactions on file):** "
                         f"completed inflow {format_inr(act['completed_inflow'])}, outflow {format_inr(act['completed_outflow'])}; "
                         f"{act['pending_or_failed']} pending/failed.")
            if act["top_spending_categories"]:
                cats = ", ".join(f"{c['category'].replace('_', ' ').title()} {format_inr(c['amount'], 0)}" for c in act["top_spending_categories"])
                lines.append(f"- **Top spending:** {cats}")
    if s.get("recent_transactions"):
        lines.append("- **Recent transactions:**")
        for t in s["recent_transactions"]:
            sign = "+" if t["direction"] == "CREDIT" else "-"
            lines.append(f"  - `{t['transaction_id']}` {t['occurred_at'][:10]} · {sign}{format_inr(t['amount'])} · {t['merchant']} ({t['category'].replace('_', ' ').title()})")
    cp = s.get("credit_profile")
    if cp:
        income = f"{format_inr(cp['monthly_income'], 0)}/month" if cp["monthly_income"] else "not on file"
        debt = f"{format_inr(cp['monthly_debt'], 0)}/month" if cp["monthly_debt"] is not None else "not on file"
        dti = f"{cp['current_dti']:.1%}" if cp["current_dti"] is not None else "not available"
        score = cp["credit_score"] if cp["credit_score"] is not None else "not on file"
        lines.append(f"- **Credit profile:** income {income}, existing debt {debt}, debt-to-income {dti}, credit score {score}")
    if s["unavailable"] or result.errors:
        lines += ["", "**Not available:** " + ", ".join(s["unavailable"] + [f"{e['tool']} failed" for e in result.errors])]
    return "\n".join(lines + ["", SIM_NOTE])


# ---- grounding check for optional LLM rephrasing ------------------------------------------------------
_NUM_RE = re.compile(r"\d[\d,]*(?:\.\d+)?")


def _numbers(text: str) -> set[str]:
    out = set()
    for m in _NUM_RE.findall(text):
        out.add(m.replace(",", "").rstrip("."))
    return out


def numbers_grounded(candidate: str, facts_text: str, data: Any) -> bool:
    """Every number in an LLM-phrased answer must already appear in the tool-backed facts/data."""
    allowed = _numbers(facts_text) | _numbers(json.dumps(data, default=str))
    # Also accept rounded forms of values already present (e.g. 41.0 vs 41).
    allowed |= {n.rstrip("0").rstrip(".") for n in allowed if "." in n}
    return all(n in allowed or n.rstrip("0").rstrip(".") in allowed for n in _numbers(candidate))
