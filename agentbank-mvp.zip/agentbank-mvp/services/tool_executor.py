"""Allow-listed tool execution with per-agent permissions and tracing.

Agents (and therefore the LLM) cannot call arbitrary code: every call goes through
``AgentToolbox.call`` which checks the tool name against that agent's allow-list, times the
call, converts unexpected exceptions into error results, and records the call in the trace.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from config.settings import Settings
from services.audit_service import Trace, ToolCallRecord, sanitize
from tools import banking_tools, fraud_tools, loan_tools
from tools.common import err


@dataclass(frozen=True)
class ToolSpec:
    fn: Callable[..., dict[str, Any]]
    needs_db: bool = True
    config_key: str | None = None   # "risk" | "loan"


TOOL_REGISTRY: dict[str, ToolSpec] = {
    "get_customer": ToolSpec(banking_tools.get_customer),
    "get_account_balance": ToolSpec(banking_tools.get_account_balance),
    "get_transactions": ToolSpec(banking_tools.get_transactions),
    "get_transaction": ToolSpec(banking_tools.get_transaction),
    "get_spending_analysis": ToolSpec(banking_tools.get_spending_analysis),
    "get_financial_summary": ToolSpec(banking_tools.get_financial_summary),
    "compute_financial_summary": ToolSpec(banking_tools.compute_financial_summary, needs_db=False),
    "get_loan_profile": ToolSpec(loan_tools.get_loan_profile),
    "assess_loan_eligibility": ToolSpec(loan_tools.assess_loan_eligibility, config_key="loan"),
    "calculate_fraud_risk": ToolSpec(fraud_tools.calculate_fraud_risk, config_key="risk"),
}

# Which agent may call which tool. Anything else is blocked and logged.
AGENT_PERMISSIONS: dict[str, frozenset[str]] = {
    "BankingAgent": frozenset({
        "get_customer", "get_account_balance", "get_transactions", "get_transaction",
        "get_loan_profile", "compute_financial_summary", "get_spending_analysis"}),
    "FraudAgent": frozenset({"get_transaction", "calculate_fraud_risk"}),
    "LoanAgent": frozenset({"get_customer", "get_loan_profile", "assess_loan_eligibility"}),
}


class AgentToolbox:
    """The only handle an agent has on the outside world."""

    def __init__(self, agent_name: str, trace: Trace, settings: Settings, db_path: str | None):
        self.agent_name = agent_name
        self.trace = trace
        self.settings = settings
        self.db_path = db_path

    def call(self, tool_name: str, **kwargs: Any) -> dict[str, Any]:
        spec = TOOL_REGISTRY.get(tool_name)
        allowed = AGENT_PERMISSIONS.get(self.agent_name, frozenset())
        args_view = sanitize(kwargs)

        if spec is None or tool_name not in allowed:
            self.trace.add_tool_call(ToolCallRecord(
                self.agent_name, tool_name, args_view, "blocked", 0.0, "TOOL_NOT_ALLOWED",
                "Tool is not on this agent's allow-list."))
            return err("TOOL_NOT_ALLOWED", f"{self.agent_name} is not permitted to call '{tool_name}'.")

        call_kwargs = dict(kwargs)
        if spec.needs_db:
            call_kwargs["db_path"] = self.db_path
        if spec.config_key:
            call_kwargs["config"] = getattr(self.settings, spec.config_key)

        start = time.perf_counter()
        try:
            result = spec.fn(**call_kwargs)
            if not isinstance(result, dict) or "ok" not in result:
                result = err("MALFORMED_TOOL_RESULT", f"Tool '{tool_name}' returned an invalid result.")
        except Exception as exc:  # error boundary: one failing tool must not crash the app
            result = err("TOOL_EXCEPTION", f"Tool '{tool_name}' failed unexpectedly ({type(exc).__name__}).")
        elapsed = (time.perf_counter() - start) * 1000

        if result["ok"]:
            self.trace.add_tool_call(ToolCallRecord(
                self.agent_name, tool_name, args_view, "success", elapsed, None, sanitize(result["data"])))
        else:
            self.trace.add_tool_call(ToolCallRecord(
                self.agent_name, tool_name, args_view, "error", elapsed, result["error"]["code"],
                sanitize(result["error"]["message"])))
        return result
