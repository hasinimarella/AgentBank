"""Intent -> specialised agent routing. A small, explicit, auditable table."""
from __future__ import annotations

from agents.base import BaseAgent
from llm.base import Intent

# Which entities must be present before an intent can run. Each entry is a group of
# alternatives: the group is satisfied if ANY listed field is present.
REQUIRED_ENTITIES: dict[Intent, list[tuple[str, ...]]] = {
    Intent.ACCOUNT_BALANCE: [("customer_id",)],
    Intent.TRANSACTION_HISTORY: [("customer_id", "transaction_id")],
    Intent.FRAUD_ASSESSMENT: [("transaction_id",)],
    Intent.LOAN_ELIGIBILITY: [("customer_id",), ("amount",)],
    Intent.CUSTOMER_FINANCIAL_SUMMARY: [("customer_id",)],
    Intent.SPENDING_ANALYSIS: [("customer_id",)],
}

FIELD_LABELS = {
    "customer_id": "customer ID (e.g. C1001)",
    "transaction_id": "transaction ID (e.g. TXN-9003)",
    "amount": "loan amount (e.g. ₹200000)",
}


class AgentRouter:
    def __init__(self, agents: list[BaseAgent]):
        self._by_intent: dict[Intent, BaseAgent] = {}
        for agent in agents:
            for intent in agent.supported_intents:
                self._by_intent[intent] = agent

    def route(self, intent: Intent) -> BaseAgent | None:
        return self._by_intent.get(intent)

    @staticmethod
    def missing_entities(intent: Intent, entities: dict) -> list[str]:
        """Return human-readable labels of required information that was not provided."""
        missing: list[str] = []
        for group in REQUIRED_ENTITIES.get(intent, []):
            if not any(entities.get(f) is not None for f in group):
                missing.append(" or ".join(FIELD_LABELS[f] for f in group))
        return missing
