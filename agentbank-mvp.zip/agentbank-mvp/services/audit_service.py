"""Execution tracing and audit logging.

A ``Trace`` is built *by the code that actually runs* (supervisor, executor): every step and
tool call is appended at the moment it happens. Nothing is synthesised afterwards.
Traces are sanitised before display or storage: contact details redacted, long values and
lists truncated, secret-looking keys removed.
"""
from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from database.db import connect

_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE_RE = re.compile(r"\+?\d[\d -]{8,}\d")
_SECRET_KEY_RE = re.compile(r"(api[_-]?key|secret|password|token|authorization)", re.IGNORECASE)
MAX_STR = 140
MAX_LIST = 5
MAX_DEPTH = 5


def sanitize(value: Any, depth: int = 0) -> Any:
    """Return a display/storage-safe copy of ``value``."""
    if depth > MAX_DEPTH:
        return "…"
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if _SECRET_KEY_RE.search(str(k)):
                out[k] = "[REDACTED]"
            else:
                out[k] = sanitize(v, depth + 1)
        return out
    if isinstance(value, (list, tuple)):
        items = [sanitize(v, depth + 1) for v in list(value)[:MAX_LIST]]
        if len(value) > MAX_LIST:
            items.append(f"… {len(value) - MAX_LIST} more")
        return items
    if isinstance(value, str):
        text = _EMAIL_RE.sub("[email]", value)
        text = _PHONE_RE.sub("[phone]", text)
        return text if len(text) <= MAX_STR else text[:MAX_STR] + "…"
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return sanitize(str(value), depth + 1)


@dataclass
class ToolCallRecord:
    agent: str
    tool: str
    args: dict[str, Any]
    status: str                    # "success" | "error" | "blocked"
    duration_ms: float
    error_code: str | None = None
    result: Any = None             # sanitised

    def to_dict(self) -> dict[str, Any]:
        return {"agent": self.agent, "tool": self.tool, "args": self.args, "status": self.status,
                "duration_ms": round(self.duration_ms, 2), "error_code": self.error_code,
                "result": self.result}


@dataclass
class Trace:
    user_message: str
    mode: dict[str, Any]
    trace_id: str = field(default_factory=lambda: "TR-" + uuid.uuid4().hex[:10].upper())
    started_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    intent: str | None = None
    intent_source: str | None = None       # "llm" | "fallback"
    confidence: float | None = None
    entities: dict[str, Any] = field(default_factory=dict)
    selected_agent: str | None = None
    llm: dict[str, Any] = field(default_factory=dict)
    steps: list[dict[str, Any]] = field(default_factory=list)
    tool_calls: list[ToolCallRecord] = field(default_factory=list)
    response_status: str = "pending"
    duration_ms: float = 0.0
    _t0: float = field(default_factory=time.perf_counter, repr=False)

    def step(self, actor: str, action: str, detail: str = "") -> None:
        self.steps.append({
            "n": len(self.steps) + 1,
            "actor": actor,
            "action": action,
            "detail": sanitize(detail),
            "t_ms": round((time.perf_counter() - self._t0) * 1000, 1),
        })

    def add_tool_call(self, record: ToolCallRecord) -> None:
        self.tool_calls.append(record)
        self.step(record.agent, f"tool:{record.tool}", f"{record.status}" + (f" ({record.error_code})" if record.error_code else ""))

    def finish(self, status: str) -> None:
        self.response_status = status
        self.duration_ms = round((time.perf_counter() - self._t0) * 1000, 2)
        self.step("Supervisor", "respond", status)

    def to_dict(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "started_at": self.started_at,
            "user_message": sanitize(self.user_message),
            "mode": self.mode,
            "llm": self.llm,
            "intent": self.intent,
            "intent_source": self.intent_source,
            "confidence": self.confidence,
            "entities": sanitize(self.entities),
            "selected_agent": self.selected_agent,
            "steps": self.steps,
            "tool_calls": [c.to_dict() for c in self.tool_calls],
            "response_status": self.response_status,
            "duration_ms": self.duration_ms,
        }


class AuditService:
    """Persists sanitised traces to the ``audit_log`` table. Failures never break a request."""

    def __init__(self, db_path: str | None = None):
        self.db_path = db_path

    def record(self, trace: Trace) -> bool:
        payload = trace.to_dict()
        try:
            conn = connect(self.db_path)
            try:
                conn.execute(
                    "INSERT INTO audit_log (trace_id, created_at, intent, selected_agent, llm_mode,"
                    " status, trace_json) VALUES (?,?,?,?,?,?,?)",
                    (payload["trace_id"], payload["started_at"], payload["intent"],
                     payload["selected_agent"], str(payload["mode"].get("mode")),
                     payload["response_status"], json.dumps(payload, default=str)),
                )
                conn.commit()
            finally:
                conn.close()
            return True
        except Exception:  # audit must never take the application down
            return False

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        conn = connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT trace_id, created_at, intent, selected_agent, llm_mode, status"
                " FROM audit_log ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        finally:
            conn.close()
        return [dict(r) for r in rows]
