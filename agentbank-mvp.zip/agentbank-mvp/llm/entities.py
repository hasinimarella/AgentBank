"""Deterministic entity extraction (IDs, amounts, limits, dates, status).

Used by the fallback classifier AND to ground-check LLM output: a model may not invent an
ID that the user never typed.
"""
from __future__ import annotations

import re
from typing import Any

CUSTOMER_RE = re.compile(r"\bC-?(\d{4})\b", re.IGNORECASE)
CUSTOMER_WORD_RE = re.compile(r"\bcustomer(?:\s+(?:id|number|no\.?))?\s*#?\s*:?\s*(\d{4})\b", re.IGNORECASE)
TXN_RE = re.compile(r"\bTXN[\s_-]?(\d{4,})\b", re.IGNORECASE)

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
    "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20,
}
_NW = "|".join(NUMBER_WORDS)
UNIT_MULT = {"k": 1e3, "lakh": 1e5, "lakhs": 1e5, "lac": 1e5, "lacs": 1e5,
             "crore": 1e7, "crores": 1e7, "cr": 1e7}
_NUM = r"(\d[\d,]*(?:\.\d+)?)"
_UNIT = r"(k|lakhs?|lacs?|crores?|cr)"
_CUR_PREFIX = r"(?:₹|rs\.?|inr|rupees?)"

# The lookbehind stops words such as "customers 1001" from being read as "rs 1001".
AMOUNT_PREFIXED = re.compile(rf"(?<![A-Za-z]){_CUR_PREFIX}\s*{_NUM}\s*{_UNIT}?\b", re.IGNORECASE)
AMOUNT_SUFFIXED = re.compile(rf"\b{_NUM}\s*{_UNIT}?\s*(?:rupees?|inr|rs\b)", re.IGNORECASE)
AMOUNT_UNIT = re.compile(rf"\b{_NUM}\s*{_UNIT}\b", re.IGNORECASE)
AMOUNT_BARE = re.compile(rf"(?<![\w.]){_NUM}(?![\w])")

LIMIT_PATTERNS = [
    re.compile(rf"\b(?:last|latest|recent|past|previous|top|first)\s+(\d{{1,3}}|{_NW})\b", re.IGNORECASE),
    re.compile(rf"\b(\d{{1,3}}|{_NW})\s+(?:most\s+)?(?:recent|latest|last)\b", re.IGNORECASE),
    re.compile(rf"\b(\d{{1,3}}|{_NW})\s+(?:\w+\s+)?transactions?\b", re.IGNORECASE),
]
STATUS_RE = re.compile(r"\b(failed|pending|completed)\b", re.IGNORECASE)
DATE = r"(\d{4}-\d{2}-\d{2})"
START_RE = re.compile(rf"\b(?:since|after|from|starting)\s+{DATE}", re.IGNORECASE)
END_RE = re.compile(rf"\b(?:before|until|till|to|through)\s+{DATE}", re.IGNORECASE)
ON_RE = re.compile(rf"\bon\s+{DATE}", re.IGNORECASE)


def find_ids(text: str) -> tuple[list[str], list[str]]:
    """Return (customer_ids, transaction_ids), de-duplicated, normalised, in order of appearance."""
    customers: list[str] = []
    for rx in (CUSTOMER_RE, CUSTOMER_WORD_RE):
        for m in rx.finditer(text):
            cid = f"C{m.group(1)}"
            if cid not in customers:
                customers.append(cid)
    txns: list[str] = []
    for m in TXN_RE.finditer(text):
        tid = f"TXN-{m.group(1)}"
        if tid not in txns:
            txns.append(tid)
    return customers, txns


def strip_ids(text: str) -> str:
    text = TXN_RE.sub(" ", text)
    text = CUSTOMER_RE.sub(" ", text)
    return CUSTOMER_WORD_RE.sub(" ", text)


def _to_number(raw: str, unit: str | None) -> float | None:
    try:
        value = float(raw.replace(",", ""))
    except ValueError:
        return None
    if unit:
        value *= UNIT_MULT[unit.lower()]
    return value


def extract_amount(text: str, allow_bare: bool = False) -> float | None:
    """Parse amounts such as ₹200000, Rs 2,00,000, 2 lakh, 50k. IDs are ignored."""
    body = strip_ids(text)
    for rx in (AMOUNT_PREFIXED, AMOUNT_SUFFIXED, AMOUNT_UNIT):
        m = rx.search(body)
        if m:
            value = _to_number(m.group(1), m.group(2))
            if value is not None:
                return value
    if allow_bare:
        for m in AMOUNT_BARE.finditer(body):
            value = _to_number(m.group(1), None)
            if value is not None and value >= 1000:
                return value
    return None


def extract_limit(text: str) -> int | None:
    body = strip_ids(text)
    for rx in LIMIT_PATTERNS:
        m = rx.search(body)
        if m:
            raw = m.group(1).lower()
            return NUMBER_WORDS[raw] if raw in NUMBER_WORDS else int(raw)
    return None


def extract_status(text: str) -> str | None:
    m = STATUS_RE.search(text)
    return m.group(1).upper() if m else None


def extract_dates(text: str) -> tuple[str | None, str | None]:
    on = ON_RE.search(text)
    if on:
        return on.group(1), on.group(1)
    s, e = START_RE.search(text), END_RE.search(text)
    return (s.group(1) if s else None, e.group(1) if e else None)


MONTHS = {"january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3, "april": 4, "apr": 4,
          "may": 5, "june": 6, "jun": 6, "july": 7, "jul": 7, "august": 8, "aug": 8,
          "september": 9, "sept": 9, "sep": 9, "october": 10, "oct": 10, "november": 11, "nov": 11,
          "december": 12, "dec": 12}
_MONTH_NAMES = "|".join(sorted(MONTHS, key=len, reverse=True))
MONTH_ISO_RE = re.compile(r"\b(\d{4})-(0[1-9]|1[0-2])\b(?!-\d)")
MONTH_NAME_RE = re.compile(rf"\b({_MONTH_NAMES})\.?\s*,?\s*(\d{{4}})\b", re.IGNORECASE)


def extract_month(text: str) -> str | None:
    """Return 'YYYY-MM' for '2026-09' or 'September 2026'. A month name without a year is not guessed."""
    m = MONTH_ISO_RE.search(text)
    if m:
        return f"{m.group(1)}-{m.group(2)}"
    m = MONTH_NAME_RE.search(text)
    if m:
        return f"{m.group(2)}-{MONTHS[m.group(1).lower()]:02d}"
    return None


def extract_entities(text: str, allow_bare_amount: bool = False) -> dict[str, Any]:
    customers, txns = find_ids(text)
    start, end = extract_dates(text)
    return {
        "customer_id": customers[0] if customers else None,
        "transaction_id": txns[0] if txns else None,
        "amount": extract_amount(text, allow_bare=allow_bare_amount),
        "limit": extract_limit(text),
        "status": extract_status(text),
        "start_date": start,
        "end_date": end,
        "month": extract_month(text),
    }
