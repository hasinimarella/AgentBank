"""Chooses the active provider from configuration, after actually checking availability."""
from __future__ import annotations

from dataclasses import dataclass

from config.settings import Settings, get_settings
from llm.base import LLMProvider, ProviderStatus
from llm.ollama_provider import OllamaProvider
from llm.openai_compatible_provider import OpenAICompatibleProvider


@dataclass
class ProviderSelection:
    """What the Supervisor will use, and an honest description of why."""

    llm: LLMProvider | None          # None means: no LLM will be called
    requested: str                   # configured LLM_PROVIDER value
    detail: str                      # human-readable reason / status

    @property
    def mode(self) -> str:
        return "LLM" if self.llm is not None else "FALLBACK"

    @property
    def provider_name(self) -> str:
        return self.llm.name if self.llm else "rules"

    @property
    def model(self) -> str | None:
        return self.llm.model if self.llm else None

    def describe(self) -> dict:
        return {"mode": self.mode, "provider": self.provider_name, "model": self.model,
                "requested": self.requested, "detail": self.detail}


def fallback_selection(detail: str = "LLM disabled by configuration.", requested: str = "fallback") -> ProviderSelection:
    return ProviderSelection(llm=None, requested=requested, detail=detail)


def select_provider(settings: Settings | None = None) -> ProviderSelection:
    cfg = (settings or get_settings()).llm
    requested = cfg.provider
    if requested == "fallback":
        return fallback_selection("LLM disabled by configuration (LLM_PROVIDER=fallback).")

    candidates: list[LLMProvider] = []
    if requested in ("auto", "ollama"):
        candidates.append(OllamaProvider(cfg.ollama_base_url, cfg.ollama_model, cfg.timeout_seconds))
    if requested == "openai_compatible":
        candidates.append(OpenAICompatibleProvider(
            cfg.openai_compat_base_url, cfg.openai_compat_model, cfg.openai_compat_api_key, cfg.timeout_seconds))

    reasons: list[str] = []
    for provider in candidates:
        status: ProviderStatus = provider.check_available()
        if status.available:
            return ProviderSelection(llm=provider, requested=requested, detail=status.detail)
        reasons.append(f"{provider.name}: {status.detail}")
    return ProviderSelection(
        llm=None, requested=requested,
        detail="Using deterministic fallback. " + " ".join(reasons))
