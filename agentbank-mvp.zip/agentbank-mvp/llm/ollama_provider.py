"""Ollama (local model) provider. Needs no API key. Talks to a running Ollama server over HTTP."""
from __future__ import annotations

import requests

from llm.base import (
    FORMULATE_PROMPT,
    IntentResult,
    LLMError,
    LLMProvider,
    LLMTimeoutError,
    LLMUnavailableError,
    ProviderStatus,
    build_messages,
    validate_llm_output,
)


class OllamaProvider(LLMProvider):
    name = "ollama"

    def __init__(self, base_url: str, model: str, timeout: float = 30.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    # -- availability: really asks the server which models are installed ------------------------
    def check_available(self) -> ProviderStatus:
        try:
            resp = requests.get(f"{self.base_url}/api/tags", timeout=min(5.0, self.timeout))
            resp.raise_for_status()
            installed = [m.get("name", "") for m in resp.json().get("models", [])]
        except requests.Timeout:
            return ProviderStatus(False, f"Ollama at {self.base_url} timed out.", self.model)
        except requests.ConnectionError:
            return ProviderStatus(False, f"Ollama is not reachable at {self.base_url}.", self.model)
        except (requests.RequestException, ValueError):
            return ProviderStatus(False, f"Unexpected response from Ollama at {self.base_url}.", self.model)

        wanted = self.model
        matches = {wanted, f"{wanted}:latest"} if ":" not in wanted else {wanted}
        if not any(name in matches for name in installed):
            return ProviderStatus(
                False,
                f"Ollama is running but model '{wanted}' is not installed. Run: ollama pull {wanted}",
                self.model,
            )
        return ProviderStatus(True, f"Ollama reachable; model '{wanted}' is installed.", self.model)

    def _chat(self, messages: list[dict[str, str]], json_mode: bool) -> str:
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": 0},
        }
        if json_mode:
            payload["format"] = "json"
        try:
            resp = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=self.timeout)
        except requests.Timeout:
            raise LLMTimeoutError(f"Ollama did not answer within {self.timeout:g}s") from None
        except requests.ConnectionError:
            raise LLMUnavailableError(f"Ollama is not reachable at {self.base_url}") from None
        except requests.RequestException:
            raise LLMError("request to Ollama failed") from None
        if resp.status_code != 200:
            raise LLMError(f"Ollama returned HTTP {resp.status_code}")
        try:
            return resp.json()["message"]["content"]
        except (ValueError, KeyError, TypeError):
            raise LLMError("Ollama response had an unexpected shape") from None

    def classify_intent(self, message: str) -> IntentResult:
        raw = self._chat(build_messages(message), json_mode=True)
        return validate_llm_output(raw, message)

    def formulate(self, user_message: str, facts: str) -> str | None:
        content = f"{FORMULATE_PROMPT}\n\nQUESTION: {user_message}\n\nFACTS:\n{facts}"
        text = self._chat([{"role": "user", "content": content}], json_mode=False)
        return text.strip() or None
