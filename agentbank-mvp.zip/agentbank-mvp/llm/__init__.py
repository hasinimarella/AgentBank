"""LLM provider abstraction."""
