"""Provider abstraction, structured-output schema and validation of model output.

The LLM is only ever asked to produce an ``IntentResult``. Its output is untrusted input:
it is parsed, schema-validated and grounded against the user's actual message before the
Supervisor uses it to pick an agent. The model never selects tools and never writes SQL.
"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from llm.entities import extract_amount, extract_limit, extract_month, find_ids, strip_ids
from tools.common import MAX_TXN_LIMIT, VALID_TXN_STATUSES, normalize_customer_id, normalize_transaction_id


class Intent(str, Enum):
    ACCOUNT_BALANCE = "ACCOUNT_BALANCE"
    TRANSACTION_HISTORY = "TRANSACTION_HISTORY"
    FRAUD_ASSESSMENT = "FRAUD_ASSESSMENT"
    LOAN_ELIGIBILITY = "LOAN_ELIGIBILITY"
    CUSTOMER_FINANCIAL_SUMMARY = "CUSTOMER_FINANCIAL_SUMMARY"
    SPENDING_ANALYSIS = "SPENDING_ANALYSIS"
    UNKNOWN = "UNKNOWN"


# ---- errors ---------------------------------------------------------------------------------
class LLMError(Exception):
    """Base class. Messages must never contain secrets."""


class LLMUnavailableError(LLMError):
    pass


class LLMTimeoutError(LLMError):
    pass


class LLMValidationError(LLMError):
    """The model answered, but the answer is malformed, out of schema, or ungrounded."""


# ---- structured output -----------------------------------------------------------------------
DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class IntentResult(BaseModel):
    model_config = ConfigDict(extra="ignore")

    intent: Intent
    customer_id: str | None = None
    transaction_id: str | None = None
    amount: float | None = None
    limit: int | None = None
    status: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    month: str | None = None
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    source: str = "fallback"  # set by the application, never trusted from the model

    @field_validator("customer_id")
    @classmethod
    def _cid(cls, v):
        if v is None or v == "":
            return None
        norm = normalize_customer_id(v)
        if norm is None:
            raise ValueError("customer_id has invalid format")
        return norm

    @field_validator("transaction_id")
    @classmethod
    def _tid(cls, v):
        if v is None or v == "":
            return None
        norm = normalize_transaction_id(v)
        if norm is None:
            raise ValueError("transaction_id has invalid format")
        return norm

    @field_validator("amount")
    @classmethod
    def _amount(cls, v):
        if v is None:
            return None
        if v != v or v in (float("inf"), float("-inf")) or v <= 0:
            raise ValueError("amount must be a positive finite number")
        return float(v)

    @field_validator("limit")
    @classmethod
    def _limit(cls, v):
        if v is None:
            return None
        if v < 1 or v > MAX_TXN_LIMIT:
            raise ValueError("limit out of range")
        return v

    @field_validator("status")
    @classmethod
    def _status(cls, v):
        if v is None or v == "":
            return None
        v = v.strip().upper()
        if v not in VALID_TXN_STATUSES:
            raise ValueError("status not allowed")
        return v

    @field_validator("month")
    @classmethod
    def _month(cls, v):
        if v is None or v == "":
            return None
        if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", v):
            raise ValueError("month must be YYYY-MM")
        return v

    @field_validator("start_date", "end_date")
    @classmethod
    def _dates(cls, v):
        if v is None or v == "":
            return None
        if not DATE_PATTERN.match(v):
            raise ValueError("date must be YYYY-MM-DD")
        return v

    def entities(self) -> dict[str, Any]:
        return {k: getattr(self, k) for k in (
            "customer_id", "transaction_id", "amount", "limit", "status", "start_date", "end_date", "month")}


@dataclass
class ProviderStatus:
    available: bool
    detail: str
    model: str | None = None


# ---- prompt shared by LLM providers ------------------------------------------------------------
SYSTEM_PROMPT = """You are the intent classifier for a SIMULATED banking assistant.
Read the user's message and reply with ONE JSON object, nothing else:
{"intent": "<ACCOUNT_BALANCE|TRANSACTION_HISTORY|FRAUD_ASSESSMENT|LOAN_ELIGIBILITY|CUSTOMER_FINANCIAL_SUMMARY|SPENDING_ANALYSIS|UNKNOWN>",
 "customer_id": "<e.g. C1001 or null>", "transaction_id": "<e.g. TXN-9003 or null>",
 "amount": <number in rupees or null>, "limit": <integer or null>,
 "status": "<COMPLETED|PENDING|FAILED or null>", "start_date": "<YYYY-MM-DD or null>",
 "end_date": "<YYYY-MM-DD or null>", "month": "<YYYY-MM or null>", "confidence": <0.0-1.0>}
Intent guide:
- ACCOUNT_BALANCE: asks for balance or account status of a customer.
- TRANSACTION_HISTORY: asks to list or look up transactions.
- FRAUD_ASSESSMENT: asks whether a specific transaction is suspicious or risky.
- LOAN_ELIGIBILITY: asks whether a customer qualifies for a loan of some amount.
- CUSTOMER_FINANCIAL_SUMMARY: asks for an overview of a customer's finances.
- SPENDING_ANALYSIS: asks how much a customer spent, or where their money went (monthly spending by category).
- UNKNOWN: anything else, including requests to transfer, pay, freeze, approve or change anything.
Rules: copy IDs exactly as written by the user; use null when a value is not stated; never invent
values; convert "2 lakh" to 200000; output JSON only."""


def build_messages(user_message: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message},
    ]


FORMULATE_PROMPT = (
    "Rewrite the FACTS below as a short, friendly answer (at most 4 sentences) to the user's "
    "question. Use ONLY information in the FACTS. Do not add, change, round or estimate any number, "
    "name or date. Do not give advice beyond the FACTS."
)

# ---- output validation ------------------------------------------------------------------------
_JSON_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
_NUMBERISH = re.compile(r"\d|thousand|lakh|lac|crore|hundred|million|\bk\b", re.IGNORECASE)


def _extract_json_object(raw: str) -> dict[str, Any]:
    if not isinstance(raw, str) or not raw.strip():
        raise LLMValidationError("model returned an empty response")
    text = raw.strip()
    fence = _JSON_FENCE.search(text)
    if fence:
        text = fence.group(1).strip()
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end <= start:
            raise LLMValidationError("model response did not contain a JSON object") from None
        try:
            obj = json.loads(text[start:end + 1])
        except json.JSONDecodeError:
            raise LLMValidationError("model response contained malformed JSON") from None
    if not isinstance(obj, dict):
        raise LLMValidationError("model response JSON was not an object")
    return obj


def validate_llm_output(raw: str, user_message: str) -> IntentResult:
    """Parse, schema-check and ground the model's answer. Raises ``LLMValidationError``.

    Grounding rules:
      * customer_id / transaction_id must be IDs the user actually typed;
      * amount / limit: when deterministic extraction finds a value it must agree with the
        model; when it finds none, the message must still contain a numeric token, otherwise
        the model's value is rejected as invented.
    """
    obj = _extract_json_object(raw)
    obj = {k: (None if v in ("", "null", "None") else v) for k, v in obj.items()}
    obj.pop("source", None)
    try:
        result = IntentResult.model_validate(obj)
    except ValidationError as exc:
        first = exc.errors()[0]
        loc = ".".join(str(p) for p in first.get("loc", ())) or "response"
        raise LLMValidationError(f"model output failed schema validation at '{loc}'") from None

    customers, txns = find_ids(user_message)
    if result.customer_id and result.customer_id not in customers:
        raise LLMValidationError("model returned a customer_id that the user did not provide")
    if result.transaction_id and result.transaction_id not in txns:
        raise LLMValidationError("model returned a transaction_id that the user did not provide")

    # Digits inside IDs (C1001, TXN-9003) must not count as "the user mentioned a number".
    body = strip_ids(user_message)
    has_number = bool(_NUMBERISH.search(body))
    det_amount = extract_amount(user_message, allow_bare=True)
    if result.amount is not None:
        if det_amount is not None:
            if abs(det_amount - result.amount) > 0.5:
                raise LLMValidationError("model amount disagrees with the amount in the message")
        elif not has_number:
            raise LLMValidationError("model returned an amount but the message contains no number")
    det_limit = extract_limit(user_message)
    if result.limit is not None and det_limit is not None and det_limit != result.limit:
        raise LLMValidationError("model limit disagrees with the limit in the message")
    if result.limit is not None and det_limit is None and not has_number:
        raise LLMValidationError("model returned a limit but the message contains no number")

    if result.month is not None and extract_month(user_message) != result.month:
        raise LLMValidationError("model returned a month that the user did not state")

    result.source = "llm"
    return result


# ---- provider interface -------------------------------------------------------------------------
class LLMProvider(ABC):
    name: str = "base"
    model: str | None = None
    uses_llm: bool = True

    @abstractmethod
    def check_available(self) -> ProviderStatus:
        """Verify reachability. Must not claim availability without actually checking."""

    @abstractmethod
    def classify_intent(self, message: str) -> IntentResult:
        """Return a validated IntentResult or raise an ``LLMError`` subclass."""

    def formulate(self, user_message: str, facts: str) -> str | None:
        """Optional natural-language rephrasing of tool-backed facts."""
        return None
