"""Optional provider for any OpenAI-style ``/v1/chat/completions`` endpoint.

Examples: a local llama.cpp / LM Studio / vLLM server, or a hosted service. No key is required
by this project; if your endpoint needs one, set OPENAI_COMPAT_API_KEY in your private .env.
The key is only sent as an Authorization header and is never logged or displayed.
"""
from __future__ import annotations

import requests

from llm.base import (
    FORMULATE_PROMPT,
    IntentResult,
    LLMError,
    LLMProvider,
    LLMTimeoutError,
    LLMUnavailableError,
    ProviderStatus,
    build_messages,
    validate_llm_output,
)


class OpenAICompatibleProvider(LLMProvider):
    name = "openai_compatible"

    def __init__(self, base_url: str, model: str, api_key: str = "", timeout: float = 30.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._api_key = api_key
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    def check_available(self) -> ProviderStatus:
        if not self.base_url or not self.model:
            return ProviderStatus(False, "OPENAI_COMPAT_BASE_URL and OPENAI_COMPAT_MODEL must both be set.", self.model or None)
        try:
            resp = requests.get(f"{self.base_url}/models", headers=self._headers(), timeout=min(5.0, self.timeout))
        except requests.Timeout:
            return ProviderStatus(False, "Endpoint timed out.", self.model)
        except requests.RequestException:
            return ProviderStatus(False, "Endpoint is not reachable.", self.model)
        if resp.status_code in (401, 403):
            return ProviderStatus(False, "Endpoint rejected the credentials.", self.model)
        if resp.status_code != 200:
            return ProviderStatus(False, f"Endpoint returned HTTP {resp.status_code}.", self.model)
        return ProviderStatus(True, "Endpoint reachable (model name not verified).", self.model)

    def _chat(self, messages: list[dict[str, str]]) -> str:
        payload = {"model": self.model, "messages": messages, "temperature": 0}
        try:
            resp = requests.post(f"{self.base_url}/chat/completions", json=payload,
                                 headers=self._headers(), timeout=self.timeout)
        except requests.Timeout:
            raise LLMTimeoutError(f"endpoint did not answer within {self.timeout:g}s") from None
        except requests.ConnectionError:
            raise LLMUnavailableError("endpoint is not reachable") from None
        except requests.RequestException:
            raise LLMError("request to endpoint failed") from None
        if resp.status_code != 200:
            raise LLMError(f"endpoint returned HTTP {resp.status_code}")
        try:
            return resp.json()["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError):
            raise LLMError("endpoint response had an unexpected shape") from None

    def classify_intent(self, message: str) -> IntentResult:
        return validate_llm_output(self._chat(build_messages(message)), message)

    def formulate(self, user_message: str, facts: str) -> str | None:
        content = f"{FORMULATE_PROMPT}\n\nQUESTION: {user_message}\n\nFACTS:\n{facts}"
        text = self._chat([{"role": "user", "content": content}])
        return text.strip() or None
