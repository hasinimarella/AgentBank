"""Deterministic, keyword/regex intent classifier. No LLM is called, ever."""
from __future__ import annotations

import re

from llm.base import Intent, IntentResult, LLMProvider, ProviderStatus
from llm.entities import extract_entities
from tools.common import MAX_TXN_LIMIT

# Verbs that always mean "do something" (the simulator never executes actions).
STRONG_ACTION_RE = re.compile(
    r"\b(transfer|send\s+money|withdraw|freeze|unfreeze|approve|disburse|"
    r"close\s+(?:my\s+|the\s+)?account|open\s+(?:a\s+|an\s+|new\s+)?account)\b",
    re.IGNORECASE,
)
# Weaker words; only treated as actions when the message is not a read-style question.
WEAK_ACTION_RE = re.compile(r"\b(deposit|block|unblock|reverse|refund|delete|change|update|pay)\b", re.IGNORECASE)
READ_HINT_RE = re.compile(r"\b(eligib\w*|check|show|what|how|is|are|list|give|tell)\b", re.IGNORECASE)
FRAUD_RE = re.compile(r"\b(fraud\w*|suspicious|suspect|risky|risk|scam\w*|anomal\w*|unauthori[sz]ed|phishing)\b", re.IGNORECASE)
LOAN_RE = re.compile(r"\b(loan\w*|eligib\w*|borrow\w*|mortgage|emi|afford\w*|qualif\w*)\b", re.IGNORECASE)
SUMMARY_RE = re.compile(
    r"\b(summary|summari[sz]e|overview|financial\s+(?:profile|health|snapshot|picture|position|status)|"
    r"full\s+picture|everything\s+about)\b", re.IGNORECASE)
BALANCE_RE = re.compile(r"\b(balance|balances|how\s+much\s+(?:money|funds|do|does)|funds|account\s+status)\b", re.IGNORECASE)
SPENDING_RE = re.compile(r"\b(spending|spend|spent|expenses?|expenditure)\b", re.IGNORECASE)
TXN_RE = re.compile(r"\b(transactions?|history|statement|txns?|payments?\s+made|recent\s+activity)\b", re.IGNORECASE)


class FallbackProvider(LLMProvider):
    name = "rules"
    model = None
    uses_llm = False

    def check_available(self) -> ProviderStatus:
        return ProviderStatus(True, "Deterministic rule-based classifier (no LLM).", None)

    def classify_intent(self, message: str) -> IntentResult:
        text = message or ""
        intent, confidence = self._intent(text)
        entities = extract_entities(text, allow_bare_amount=(intent == Intent.LOAN_ELIGIBILITY))
        # Keep out-of-range values from breaking schema validation: clamp the limit, drop a
        # non-positive amount (the supervisor will then ask for it).
        if entities["limit"] is not None:
            entities["limit"] = min(entities["limit"], MAX_TXN_LIMIT) if entities["limit"] >= 1 else None
        if entities["amount"] is not None and entities["amount"] <= 0:
            entities["amount"] = None
        return IntentResult(intent=intent, confidence=confidence, source="fallback", **entities)

    @staticmethod
    def _intent(text: str) -> tuple[Intent, float]:
        if FallbackProvider.is_unsupported_action(text):
            return Intent.UNKNOWN, 0.9
        if FRAUD_RE.search(text):
            return Intent.FRAUD_ASSESSMENT, 0.9
        if LOAN_RE.search(text):
            return Intent.LOAN_ELIGIBILITY, 0.9
        if SUMMARY_RE.search(text):
            return Intent.CUSTOMER_FINANCIAL_SUMMARY, 0.9
        if SPENDING_RE.search(text):
            return Intent.SPENDING_ANALYSIS, 0.9
        if BALANCE_RE.search(text):
            return Intent.ACCOUNT_BALANCE, 0.9
        if TXN_RE.search(text):
            return Intent.TRANSACTION_HISTORY, 0.9
        if re.search(r"\bTXN[\s_-]?\d{4,}\b", text, re.IGNORECASE):
            return Intent.TRANSACTION_HISTORY, 0.5  # a bare transaction ID: look it up
        return Intent.UNKNOWN, 0.3

    @staticmethod
    def is_unsupported_action(text: str) -> bool:
        """True when the message asks the simulator to *do* something (transfer, freeze, approve...)."""
        if STRONG_ACTION_RE.search(text):
            return True
        return bool(WEAK_ACTION_RE.search(text)) and not READ_HINT_RE.search(text)
