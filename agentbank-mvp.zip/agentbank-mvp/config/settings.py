"""Central configuration, read from environment variables (and an optional .env file).

Nothing secret is stored in source code. ``get_settings()`` re-reads the environment on
every call so tests and the UI can change configuration without restarting.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:  # python-dotenv is optional at runtime; .env never overrides real env vars
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)
except ImportError:  # pragma: no cover
    pass

PROJECT_ROOT = Path(__file__).resolve().parent.parent

VALID_PROVIDERS = ("auto", "ollama", "openai_compatible", "fallback")


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return float(default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.getenv(name, default)))
    except (TypeError, ValueError):
        return int(default)


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class RiskConfig:
    """Thresholds for the rule-based fraud-risk engine (score range 0-100).

    score < medium -> LOW, medium <= score < high -> MEDIUM, score >= high -> HIGH.
    """

    medium: int = 30
    high: int = 60


@dataclass(frozen=True)
class LoanConfig:
    """Illustrative thresholds. Not a real lending policy."""

    assumed_annual_rate: float = 0.11
    assumed_tenure_months: int = 36
    min_credit_score: int = 650
    refer_credit_score: int = 600
    max_dti: float = 0.40
    refer_dti: float = 0.50
    min_employment_years: float = 1.0
    max_multiple_of_annual_income: float = 2.0
    min_amount: float = 10_000
    max_amount: float = 5_000_000


@dataclass(frozen=True)
class LLMConfig:
    provider: str = "auto"
    timeout_seconds: float = 30.0
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2:3b"
    openai_compat_base_url: str = ""
    openai_compat_model: str = ""
    # Kept in memory only; never logged or displayed.
    openai_compat_api_key: str = field(default="", repr=False)
    formulate_responses: bool = False


@dataclass(frozen=True)
class Settings:
    db_path: str
    llm: LLMConfig
    risk: RiskConfig
    loan: LoanConfig


def get_settings() -> Settings:
    provider = os.getenv("LLM_PROVIDER", "auto").strip().lower()
    if provider not in VALID_PROVIDERS:
        provider = "auto"

    db_path = os.getenv("AGENTBANK_DB_PATH", "var/agentbank.db")
    if not os.path.isabs(db_path):
        db_path = str(PROJECT_ROOT / db_path)

    llm = LLMConfig(
        provider=provider,
        timeout_seconds=_env_float("LLM_TIMEOUT_SECONDS", 30.0),
        ollama_base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/"),
        ollama_model=os.getenv("OLLAMA_MODEL", "llama3.2:3b").strip(),
        openai_compat_base_url=os.getenv("OPENAI_COMPAT_BASE_URL", "").strip().rstrip("/"),
        openai_compat_model=os.getenv("OPENAI_COMPAT_MODEL", "").strip(),
        openai_compat_api_key=os.getenv("OPENAI_COMPAT_API_KEY", "").strip(),
        formulate_responses=_env_bool("LLM_FORMULATE_RESPONSES", False),
    )
    risk = RiskConfig(
        medium=_env_int("RISK_THRESHOLD_MEDIUM", 30),
        high=_env_int("RISK_THRESHOLD_HIGH", 60),
    )
    d = LoanConfig()
    loan = LoanConfig(
        assumed_annual_rate=_env_float("LOAN_ASSUMED_ANNUAL_RATE", d.assumed_annual_rate),
        assumed_tenure_months=_env_int("LOAN_ASSUMED_TENURE_MONTHS", d.assumed_tenure_months),
        min_credit_score=_env_int("LOAN_MIN_CREDIT_SCORE", d.min_credit_score),
        refer_credit_score=_env_int("LOAN_REFER_CREDIT_SCORE", d.refer_credit_score),
        max_dti=_env_float("LOAN_MAX_DTI", d.max_dti),
        refer_dti=_env_float("LOAN_REFER_DTI", d.refer_dti),
        min_employment_years=_env_float("LOAN_MIN_EMPLOYMENT_YEARS", d.min_employment_years),
        max_multiple_of_annual_income=_env_float(
            "LOAN_MAX_MULTIPLE_OF_ANNUAL_INCOME", d.max_multiple_of_annual_income
        ),
        min_amount=_env_float("LOAN_MIN_AMOUNT", d.min_amount),
        max_amount=_env_float("LOAN_MAX_AMOUNT", d.max_amount),
    )
    return Settings(db_path=db_path, llm=llm, risk=risk, loan=loan)
