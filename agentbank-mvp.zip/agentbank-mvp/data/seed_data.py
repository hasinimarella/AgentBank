"""Reproducible, entirely synthetic banking data.

Run ``python -m data.seed_data`` (add ``--reset`` to rebuild) to create the database.
Names, e-mails and phone numbers are invented. Nothing here is real customer data.

Scenario map (kept consistent with tests, docs and the demo script):

  C1001 Aarav Mehta   strong profile        -> loan of 200000 is ELIGIBLE
  C1002 Priya Nair    busy account (9 txns) -> loan 200000 ELIGIBLE, 600000 REFER_TO_REVIEW
  C1003 Rohan Das     stretched finances    -> loan 200000 NOT_ELIGIBLE (DTI, credit, tenure)
  C1004 Sneha Iyer    holds the risky txns  -> TXN-9003 HIGH (95), TXN-9004 MEDIUM (41), TXN-9010/9012 HIGH, TXN-9102 LOW
  C1005 Vikram Singh  income not on file    -> loan assessment INSUFFICIENT_DATA
  C1006 Ananya Rao    new customer          -> no transactions (empty history)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from config.settings import get_settings
from database.db import connect, create_schema

CUSTOMERS = [
    # id, name, email, phone, city, country, kyc, since, income, debt, employment, emp_years, credit
    ("C1001", "Aarav Mehta", "aarav.mehta@example.test", "+91-90000-10001", "Bengaluru", "IN",
     "VERIFIED", "2018-04-12", 120000, 15000, "SALARIED", 6.0, 790),
    ("C1002", "Priya Nair", "priya.nair@example.test", "+91-90000-10002", "Kochi", "IN",
     "VERIFIED", "2020-09-03", 65000, 12000, "SALARIED", 3.0, 710),
    ("C1003", "Rohan Das", "rohan.das@example.test", "+91-90000-10003", "Kolkata", "IN",
     "VERIFIED", "2022-01-20", 45000, 22000, "SALARIED", 0.8, 620),
    ("C1004", "Sneha Iyer", "sneha.iyer@example.test", "+91-90000-10004", "Chennai", "IN",
     "VERIFIED", "2019-06-30", 90000, 8000, "SALARIED", 2.0, 745),
    ("C1005", "Vikram Singh", "vikram.singh@example.test", "+91-90000-10005", "Delhi", "IN",
     "PENDING", "2023-03-15", None, None, "SELF_EMPLOYED", None, 680),
    ("C1006", "Ananya Rao", "ananya.rao@example.test", "+91-90000-10006", "Hyderabad", "IN",
     "VERIFIED", "2026-08-25", 30000, 0, "SALARIED", 0.5, 580),
]

ACCOUNTS = [
    # account_id, customer_id, type, balance, currency, status, opened_on
    ("ACC-1001-01", "C1001", "SAVINGS", 485250.75, "INR", "ACTIVE", "2018-04-12"),
    ("ACC-1001-02", "C1001", "CURRENT", 62000.00, "INR", "ACTIVE", "2021-02-01"),
    ("ACC-1002-01", "C1002", "SALARY", 84320.40, "INR", "ACTIVE", "2020-09-03"),
    ("ACC-1003-01", "C1003", "SAVINGS", 12840.10, "INR", "ACTIVE", "2022-01-20"),
    ("ACC-1004-01", "C1004", "SAVINGS", 256900.00, "INR", "ACTIVE", "2019-06-30"),
    ("ACC-1005-01", "C1005", "CURRENT", 143500.25, "INR", "DORMANT", "2023-03-15"),
    ("ACC-1006-01", "C1006", "SAVINGS", 5000.00, "INR", "ACTIVE", "2026-08-25"),
]

TXN_COLS = ("transaction_id", "customer_id", "account_id", "amount", "direction", "merchant",
            "category", "city", "country", "channel", "status", "occurred_at")

TRANSACTIONS = [
    # --- C1001: steady, domestic, everyday spending -------------------------------------
    ("TXN-9101", "C1001", "ACC-1001-01", 120000.00, "CREDIT", "Employer Payroll", "SALARY", "Bengaluru", "IN", "NETBANKING", "COMPLETED", "2026-09-01T10:00:00"),
    ("TXN-9102", "C1001", "ACC-1001-01", 2450.00, "DEBIT", "Fresh Basket Grocers", "GROCERIES", "Bengaluru", "IN", "UPI", "COMPLETED", "2026-09-04T18:20:00"),
    ("TXN-9103", "C1001", "ACC-1001-01", 18500.00, "DEBIT", "City Power Utility", "UTILITIES", "Bengaluru", "IN", "NETBANKING", "COMPLETED", "2026-09-07T11:05:00"),
    ("TXN-9104", "C1001", "ACC-1001-01", 3200.00, "DEBIT", "Urban Eats", "DINING", "Bengaluru", "IN", "CARD", "COMPLETED", "2026-09-12T20:45:00"),
    ("TXN-9105", "C1001", "ACC-1001-02", 15000.00, "DEBIT", "Home Loan EMI", "LOAN_EMI", "Bengaluru", "IN", "NETBANKING", "COMPLETED", "2026-09-15T09:00:00"),
    # --- C1002: busy account, 9 transactions (supports the "last five" demo) ------------
    ("TXN-9201", "C1002", "ACC-1002-01", 65000.00, "CREDIT", "Employer Payroll", "SALARY", "Kochi", "IN", "NETBANKING", "COMPLETED", "2026-09-01T09:30:00"),
    ("TXN-9202", "C1002", "ACC-1002-01", 1800.00, "DEBIT", "Spice Route Market", "GROCERIES", "Kochi", "IN", "UPI", "COMPLETED", "2026-09-03T17:10:00"),
    ("TXN-9203", "C1002", "ACC-1002-01", 650.00, "DEBIT", "Metro Card Recharge", "TRANSPORT", "Kochi", "IN", "UPI", "COMPLETED", "2026-09-06T08:15:00"),
    ("TXN-9204", "C1002", "ACC-1002-01", 4200.00, "DEBIT", "Lakeview Pharmacy", "HEALTH", "Kochi", "IN", "CARD", "COMPLETED", "2026-09-10T12:40:00"),
    ("TXN-9205", "C1002", "ACC-1002-01", 12000.00, "DEBIT", "Personal Loan EMI", "LOAN_EMI", "Kochi", "IN", "NETBANKING", "COMPLETED", "2026-09-15T09:00:00"),
    ("TXN-9206", "C1002", "ACC-1002-01", 2750.00, "DEBIT", "Streamly Subscriptions", "ENTERTAINMENT", "Kochi", "IN", "CARD", "COMPLETED", "2026-09-18T21:30:00"),
    ("TXN-9207", "C1002", "ACC-1002-01", 3900.00, "DEBIT", "Harbour Restaurant", "DINING", "Kochi", "IN", "CARD", "COMPLETED", "2026-09-22T20:05:00"),
    ("TXN-9208", "C1002", "ACC-1002-01", 1500.00, "DEBIT", "Fuel Point", "TRANSPORT", "Kochi", "IN", "UPI", "COMPLETED", "2026-09-26T07:50:00"),
    ("TXN-9209", "C1002", "ACC-1002-01", 5400.00, "DEBIT", "Book & Beyond", "SHOPPING", "Kochi", "IN", "CARD", "PENDING", "2026-09-29T15:25:00"),
    # --- C1003: modest income, heavy debt ------------------------------------------------
    ("TXN-9301", "C1003", "ACC-1003-01", 45000.00, "CREDIT", "Employer Payroll", "SALARY", "Kolkata", "IN", "NETBANKING", "COMPLETED", "2026-09-01T10:10:00"),
    ("TXN-9302", "C1003", "ACC-1003-01", 22000.00, "DEBIT", "Vehicle & Card EMIs", "LOAN_EMI", "Kolkata", "IN", "NETBANKING", "COMPLETED", "2026-09-05T09:00:00"),
    ("TXN-9303", "C1003", "ACC-1003-01", 9000.00, "DEBIT", "Metro Rent Co", "RENT", "Kolkata", "IN", "NETBANKING", "COMPLETED", "2026-09-06T10:30:00"),
    ("TXN-9304", "C1003", "ACC-1003-01", 1900.00, "DEBIT", "Daily Needs Mart", "GROCERIES", "Kolkata", "IN", "UPI", "COMPLETED", "2026-09-14T19:00:00"),
    # --- C1004: the deliberately suspicious scenarios -----------------------------------
    ("TXN-9001", "C1004", "ACC-1004-01", 1200.00, "DEBIT", "Cafe Madras", "DINING", "Chennai", "IN", "UPI", "COMPLETED", "2026-08-30T13:00:00"),
    ("TXN-9002", "C1004", "ACC-1004-01", 3100.00, "DEBIT", "Sunrise Supermarket", "GROCERIES", "Chennai", "IN", "UPI", "COMPLETED", "2026-09-02T18:30:00"),
    ("TXN-9005", "C1004", "ACC-1004-01", 2200.00, "DEBIT", "Chennai Cab Services", "TRANSPORT", "Chennai", "IN", "UPI", "COMPLETED", "2026-09-05T09:15:00"),
    ("TXN-9006", "C1004", "ACC-1004-01", 4800.00, "DEBIT", "Style Street Apparel", "SHOPPING", "Chennai", "IN", "CARD", "COMPLETED", "2026-09-09T16:40:00"),
    ("TXN-9007", "C1004", "ACC-1004-01", 1500.00, "DEBIT", "Chennai Bites", "DINING", "Chennai", "IN", "UPI", "COMPLETED", "2026-09-14T14:20:00"),
    ("TXN-9008", "C1004", "ACC-1004-01", 90000.00, "CREDIT", "Employer Payroll", "SALARY", "Chennai", "IN", "NETBANKING", "COMPLETED", "2026-09-30T10:00:00"),
    # TXN-9003: large, foreign, 02:10 a.m., crypto-exchange merchant, within minutes of other attempts
    ("TXN-9003", "C1004", "ACC-1004-01", 185000.00, "DEBIT", "GlobalCoin Exchange", "CRYPTO", "Lagos", "NG", "CARD", "COMPLETED", "2026-10-01T02:10:00"),
    ("TXN-9010", "C1004", "ACC-1004-01", 45000.00, "DEBIT", "GlobalCoin Exchange", "CRYPTO", "Lagos", "NG", "CARD", "FAILED", "2026-10-01T02:04:00"),
    ("TXN-9011", "C1004", "ACC-1004-01", 45000.00, "DEBIT", "GlobalCoin Exchange", "CRYPTO", "Lagos", "NG", "CARD", "FAILED", "2026-10-01T02:06:00"),
    ("TXN-9012", "C1004", "ACC-1004-01", 30000.00, "DEBIT", "GlobalCoin Exchange", "CRYPTO", "Lagos", "NG", "CARD", "FAILED", "2026-10-01T02:08:00"),
    # TXN-9004: moderately unusual - domestic but new city, high amount, gift cards
    ("TXN-9004", "C1004", "ACC-1004-01", 24000.00, "DEBIT", "Gift Card Hub", "GIFT_CARDS", "Pune", "IN", "CARD", "COMPLETED", "2026-10-02T23:40:00"),
    # --- C1005: dormant account, no spend pattern ---------------------------------------
    ("TXN-9501", "C1005", "ACC-1005-01", 25000.00, "CREDIT", "Client Invoice 118", "BUSINESS_INCOME", "Delhi", "IN", "NETBANKING", "COMPLETED", "2026-07-11T12:00:00"),
    ("TXN-9502", "C1005", "ACC-1005-01", 7000.00, "DEBIT", "Office Supplies Depot", "BUSINESS", "Delhi", "IN", "CARD", "COMPLETED", "2026-07-20T11:45:00"),
    # C1006: intentionally no transactions
]


def seed_database(db_path: str | None = None, reset: bool = False) -> str:
    """Create and populate the database. Idempotent unless ``reset`` is True."""
    path = Path(db_path or get_settings().db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if reset and path.exists():
        path.unlink()

    conn = connect(str(path))
    try:
        create_schema(conn)
        existing = conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
        if existing:
            return str(path)
        conn.executemany(
            "INSERT INTO customers (customer_id, full_name, email, phone, home_city, home_country,"
            " kyc_status, customer_since, monthly_income, monthly_debt, employment_status,"
            " employment_years, credit_score) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            CUSTOMERS,
        )
        conn.executemany(
            "INSERT INTO accounts (account_id, customer_id, account_type, balance, currency,"
            " status, opened_on) VALUES (?,?,?,?,?,?,?)",
            ACCOUNTS,
        )
        conn.executemany(
            f"INSERT INTO transactions ({', '.join(TXN_COLS)}) VALUES ({', '.join('?' * len(TXN_COLS))})",
            TRANSACTIONS,
        )
        conn.commit()
    finally:
        conn.close()
    return str(path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Create the synthetic AgentBank database.")
    parser.add_argument("--reset", action="store_true", help="delete and rebuild the database")
    parser.add_argument("--db", default=None, help="override database path")
    args = parser.parse_args(argv)
    path = seed_database(args.db, reset=args.reset)
    conn = connect(path)
    try:
        counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                  for t in ("customers", "accounts", "transactions")}
    finally:
        conn.close()
    print(f"Synthetic database ready at {path}: {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
