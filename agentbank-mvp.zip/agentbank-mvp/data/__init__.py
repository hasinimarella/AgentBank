"""Synthetic data."""
