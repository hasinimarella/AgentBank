"""Illustrative loan-eligibility engine (threshold-based; NOT a trained credit-scoring model).

The result is a simulated assessment for demonstration. It is not a lending decision, and
the thresholds are invented defaults that can be changed through environment variables.
"""
from __future__ import annotations

import math
from datetime import datetime
from typing import Any

from config.settings import LoanConfig, get_settings
from database.db import connect
from tools.common import err, normalize_customer_id, ok, validate_amount

DISCLAIMER = (
    "Illustrative simulated assessment using invented thresholds. It is not a real lending "
    "decision and no loan was approved, offered or recorded."
)


def monthly_payment(principal: float, annual_rate: float, months: int) -> float:
    """Standard amortised monthly instalment (EMI)."""
    r = annual_rate / 12
    if r == 0:
        return principal / months
    return principal * r * (1 + r) ** months / ((1 + r) ** months - 1)


def get_loan_profile(customer_id: str, db_path: str | None = None) -> dict[str, Any]:
    """The financial attributes used by the loan engine. NULL columns come back as None."""
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return err("INVALID_CUSTOMER_ID", "Customer ID must look like C1001 (letter C plus four digits).")
    conn = connect(db_path)
    try:
        row = conn.execute(
            "SELECT customer_id, monthly_income, monthly_debt, employment_status,"
            " employment_years, credit_score FROM customers WHERE customer_id = ?",
            (cid,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return err("CUSTOMER_NOT_FOUND", f"No customer with ID {cid} exists in the simulator.")
    data = dict(row)
    current_dti = None
    if data["monthly_income"] and data["monthly_debt"] is not None:
        current_dti = round(data["monthly_debt"] / data["monthly_income"], 4)
    data["current_dti"] = current_dti
    return ok(data)


def _check(name: str, outcome: str, detail: str, value: Any = None, threshold: Any = None) -> dict[str, Any]:
    return {"check": name, "outcome": outcome, "detail": detail, "value": value, "threshold": threshold}


def assess_loan_eligibility(
    customer_id: str,
    requested_amount: Any,
    db_path: str | None = None,
    config: LoanConfig | None = None,
    persist: bool = False,
) -> dict[str, Any]:
    """Return ELIGIBLE / REFER_TO_REVIEW / NOT_ELIGIBLE / INSUFFICIENT_DATA with explanations."""
    cfg = config or get_settings().loan
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return err("INVALID_CUSTOMER_ID", "Customer ID must look like C1001 (letter C plus four digits).")
    amount, problem = validate_amount(requested_amount, cfg.min_amount, cfg.max_amount)
    if problem:
        return err("INVALID_AMOUNT", problem)

    profile = get_loan_profile(cid, db_path)
    if not profile["ok"]:
        return profile
    p = profile["data"]

    # Missing attributes: income and credit score are required; debt defaults are NOT assumed.
    missing = [label for key, label in (
        ("monthly_income", "monthly income"),
        ("monthly_debt", "existing monthly debt"),
        ("credit_score", "credit score"),
        ("employment_years", "employment length"),
    ) if p[key] is None]

    emi = monthly_payment(amount, cfg.assumed_annual_rate, cfg.assumed_tenure_months)
    base = {
        "customer_id": cid,
        "requested_amount": amount,
        "assumptions": {
            "annual_interest_rate": cfg.assumed_annual_rate,
            "tenure_months": cfg.assumed_tenure_months,
        },
        "estimated_monthly_payment": round(emi, 2),
        "financial_profile": {k: p[k] for k in (
            "monthly_income", "monthly_debt", "employment_status", "employment_years", "credit_score")},
        "engine": {"name": "threshold-rules-v1", "kind": "rule-based (illustrative, not machine learning)"},
        "disclaimer": DISCLAIMER,
    }

    if missing:
        decision_data = {
            **base,
            "decision": "INSUFFICIENT_DATA",
            "dti_before_loan": p["current_dti"],
            "dti_after_loan": None,
            "checks": [],
            "reasons": [f"Cannot assess: {', '.join(missing)} not on file."],
            "missing_information": missing,
            "recommendations": [
                f"Collect the missing information ({', '.join(missing)}) and re-run the assessment.",
                "A loan officer should verify income documents before any assessment.",
            ],
        }
        _maybe_persist(persist, db_path, decision_data)
        return ok(decision_data)

    income = p["monthly_income"]
    if income <= 0:
        decision_data = {
            **base, "decision": "NOT_ELIGIBLE", "dti_before_loan": None, "dti_after_loan": None,
            "checks": [], "missing_information": [],
            "reasons": ["Monthly income on file is zero."],
            "recommendations": ["Update the income record if it is out of date."],
        }
        _maybe_persist(persist, db_path, decision_data)
        return ok(decision_data)

    dti_before = p["monthly_debt"] / income
    dti_after = (p["monthly_debt"] + emi) / income
    annual_income = income * 12
    multiple = amount / annual_income

    checks: list[dict[str, Any]] = []

    # Credit score
    score = p["credit_score"]
    if score >= cfg.min_credit_score:
        checks.append(_check("credit_score", "PASS", f"Credit score {score} meets the minimum of {cfg.min_credit_score}.", score, cfg.min_credit_score))
    elif score >= cfg.refer_credit_score:
        checks.append(_check("credit_score", "REFER", f"Credit score {score} is below {cfg.min_credit_score} but at or above {cfg.refer_credit_score}.", score, cfg.min_credit_score))
    else:
        checks.append(_check("credit_score", "FAIL", f"Credit score {score} is below the referral floor of {cfg.refer_credit_score}.", score, cfg.refer_credit_score))

    # Debt-to-income after the new loan
    if dti_after <= cfg.max_dti:
        checks.append(_check("debt_to_income", "PASS", f"Debt-to-income after the loan is {dti_after:.1%}, within {cfg.max_dti:.0%}.", round(dti_after, 4), cfg.max_dti))
    elif dti_after <= cfg.refer_dti:
        checks.append(_check("debt_to_income", "REFER", f"Debt-to-income after the loan is {dti_after:.1%}, above {cfg.max_dti:.0%} but within {cfg.refer_dti:.0%}.", round(dti_after, 4), cfg.max_dti))
    else:
        checks.append(_check("debt_to_income", "FAIL", f"Debt-to-income after the loan is {dti_after:.1%}, above the {cfg.refer_dti:.0%} limit.", round(dti_after, 4), cfg.refer_dti))

    # Employment stability
    yrs = p["employment_years"]
    if yrs >= cfg.min_employment_years:
        checks.append(_check("employment_stability", "PASS", f"{yrs:g} years of employment meets the {cfg.min_employment_years:g}-year minimum.", yrs, cfg.min_employment_years))
    else:
        checks.append(_check("employment_stability", "FAIL", f"{yrs:g} years of employment is below the {cfg.min_employment_years:g}-year minimum.", yrs, cfg.min_employment_years))

    # Loan size relative to annual income
    if multiple <= cfg.max_multiple_of_annual_income:
        checks.append(_check("loan_to_annual_income", "PASS", f"Requested amount is {multiple:.2f}x annual income (limit {cfg.max_multiple_of_annual_income:g}x).", round(multiple, 3), cfg.max_multiple_of_annual_income))
    else:
        checks.append(_check("loan_to_annual_income", "FAIL", f"Requested amount is {multiple:.2f}x annual income, above the {cfg.max_multiple_of_annual_income:g}x limit.", round(multiple, 3), cfg.max_multiple_of_annual_income))

    outcomes = {c["outcome"] for c in checks}
    if "FAIL" in outcomes:
        decision = "NOT_ELIGIBLE"
    elif "REFER" in outcomes:
        decision = "REFER_TO_REVIEW"
    else:
        decision = "ELIGIBLE"

    reasons = [c["detail"] for c in checks]
    recs: list[str] = []
    if decision == "ELIGIBLE":
        recs.append("Profile satisfies every illustrative criterion for this amount.")
        recs.append("A real lender would still verify documents and run its own credit policy.")
    else:
        failing = {c["check"] for c in checks if c["outcome"] == "FAIL"}
        if "debt_to_income" in failing or any(c["check"] == "debt_to_income" and c["outcome"] == "REFER" for c in checks):
            max_emi = max(0.0, cfg.max_dti * income - p["monthly_debt"])
            if max_emi > 0:
                r = cfg.assumed_annual_rate / 12
                n = cfg.assumed_tenure_months
                factor = r * (1 + r) ** n / ((1 + r) ** n - 1) if r else 1 / n
                suggested = math.floor(max_emi / factor / 1000) * 1000
                if suggested >= cfg.min_amount:
                    recs.append(f"A smaller amount of about {suggested:,.0f} would keep debt-to-income within {cfg.max_dti:.0%}.")
            recs.append("Reducing existing monthly debt would improve the debt-to-income ratio.")
        if "credit_score" in failing or any(c["check"] == "credit_score" and c["outcome"] == "REFER" for c in checks):
            recs.append("Improving the credit score through timely repayments would strengthen the profile.")
        if "employment_stability" in failing:
            recs.append("Re-apply after the minimum employment length is reached.")
        if "loan_to_annual_income" in failing:
            recs.append("Request a smaller amount relative to annual income.")
        if decision == "REFER_TO_REVIEW":
            recs.append("Route to a human loan officer for manual review.")

    data = {
        **base,
        "decision": decision,
        "dti_before_loan": round(dti_before, 4),
        "dti_after_loan": round(dti_after, 4),
        "checks": checks,
        "reasons": reasons,
        "missing_information": [],
        "recommendations": recs,
    }
    _maybe_persist(persist, db_path, data)
    return ok(data)


def _maybe_persist(persist: bool, db_path: str | None, data: dict[str, Any]) -> None:
    if not persist:
        return
    conn = connect(db_path)
    try:
        conn.execute(
            "INSERT INTO loan_assessments (customer_id, requested_amount, decision, dti_after_loan,"
            " created_at) VALUES (?,?,?,?,?)",
            (data["customer_id"], data["requested_amount"], data["decision"],
             data["dti_after_loan"], datetime.now().isoformat(timespec="seconds")),
        )
        conn.commit()
    finally:
        conn.close()


# Alias matching the name used in the assignment text.
evaluate_loan_eligibility = assess_loan_eligibility
