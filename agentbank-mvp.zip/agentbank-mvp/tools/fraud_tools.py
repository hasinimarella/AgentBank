"""Rule-based fraud-risk engine (NOT a trained machine-learning model).

The score is a transparent sum of weighted indicators (maximum 100). Each indicator reports
its points and a plain-language reason so the result is fully explainable.

A high score means "suspicious, worth a human look". It never means "confirmed fraud".
The engine is isolated behind the ``RiskScorer`` protocol so a trained model could replace
``RuleBasedRiskEngine`` later without touching the tool signature or the agent.
"""
from __future__ import annotations

import statistics
from datetime import datetime, timedelta
from typing import Any, Protocol

from config.settings import RiskConfig, get_settings
from database.db import connect, rows_to_dicts
from tools.common import err, normalize_transaction_id, ok

RISKY_CATEGORIES = {"CRYPTO", "GIFT_CARDS", "GAMBLING", "WIRE_TRANSFER"}

# Maximum points per indicator. Must sum to 100.
WEIGHTS = {
    "unusual_amount": 25,
    "high_absolute_amount": 15,
    "velocity": 20,
    "unusual_location": 20,
    "odd_hours": 5,
    "risky_merchant_category": 10,
    "transaction_status": 5,
}
assert sum(WEIGHTS.values()) == 100

DISCLAIMER = (
    "Simulated rule-based assessment. A high score indicates a SUSPICIOUS transaction, not a "
    "confirmed fraudulent one. No account was frozen and no transaction was blocked."
)

RECOMMENDATIONS = {
    "LOW": ["No action needed. Continue normal monitoring."],
    "MEDIUM": [
        "Add to a manual review queue.",
        "Consider an in-app confirmation prompt to the customer.",
    ],
    "HIGH": [
        "Escalate to a fraud analyst for prompt human review.",
        "Contact the customer through a verified channel to confirm the transaction.",
        "A human should decide whether any hold is needed. This simulator takes no action.",
    ],
}

# The action a human reviewer would be advised to take. The simulator itself never acts.
RECOMMENDED_ACTION = {"LOW": "ALLOW", "MEDIUM": "REVIEW", "HIGH": "ESCALATE"}


class RiskScorer(Protocol):
    """Interface a future trained model must implement."""

    name: str
    kind: str

    def score(self, txn: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        ...


def categorize(score: int, cfg: RiskConfig) -> str:
    if score >= cfg.high:
        return "HIGH"
    if score >= cfg.medium:
        return "MEDIUM"
    return "LOW"


def _parse(ts: str) -> datetime:
    return datetime.fromisoformat(ts)


class RuleBasedRiskEngine:
    name = "weighted-rules-v1"
    kind = "rule-based (deterministic, not machine learning)"

    def __init__(self, cfg: RiskConfig):
        self.cfg = cfg

    def score(self, txn: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        indicators: list[dict[str, Any]] = []

        def add(key: str, points: int, reason: str, triggered: bool = True) -> None:
            indicators.append({
                "indicator": key,
                "triggered": triggered,
                "points": points if triggered else 0,
                "max_points": WEIGHTS[key],
                "reason": reason,
            })

        amount = txn["amount"]
        history = context["history"]                # earlier DEBITs by same customer (excl. this)
        recent = context["recent_window"]           # other txns within 60 min before this one
        customer = context["customer"]

        # 1. Amount relative to the customer's own history
        debits = [h["amount"] for h in history if h["direction"] == "DEBIT" and h["status"] == "COMPLETED"]
        if debits:
            # Median, not mean: one earlier outlier should not hide a later one.
            avg = statistics.median(debits)
            ratio = amount / avg if avg > 0 else 0
            if ratio >= 10:
                add("unusual_amount", 25, f"Amount is {ratio:.1f}x the customer's typical (median) debit of {avg:,.0f}.")
            elif ratio >= 5:
                add("unusual_amount", 18, f"Amount is {ratio:.1f}x the customer's typical (median) debit of {avg:,.0f}.")
            elif ratio >= 3:
                add("unusual_amount", 10, f"Amount is {ratio:.1f}x the customer's typical (median) debit of {avg:,.0f}.")
            else:
                add("unusual_amount", 0, f"Amount is {ratio:.1f}x the customer's typical (median) debit; within normal range.", False)
        else:
            add("unusual_amount", 0, "No prior debit history to compare against.", False)

        # 2. Absolute amount
        if amount >= 100_000:
            add("high_absolute_amount", 15, f"Amount {amount:,.0f} is at or above 100,000.")
        elif amount >= 50_000:
            add("high_absolute_amount", 8, f"Amount {amount:,.0f} is at or above 50,000.")
        else:
            add("high_absolute_amount", 0, "Amount is below the high-value thresholds.", False)

        # 3. Velocity: other attempts shortly before this one
        n = len(recent)
        if n >= 3:
            add("velocity", 20, f"{n} other transactions in the 60 minutes before this one.")
        elif n == 2:
            add("velocity", 12, "2 other transactions in the 60 minutes before this one.")
        elif n == 1:
            add("velocity", 5, "1 other transaction in the 60 minutes before this one.")
        else:
            add("velocity", 0, "No other transactions in the preceding 60 minutes.", False)

        # 4. Location
        seen_cities = {h["city"] for h in history}
        if txn["country"] != customer["home_country"]:
            add("unusual_location", 20, f"Transaction country {txn['country']} differs from home country {customer['home_country']}.")
        elif txn["city"] != customer["home_city"] and txn["city"] not in seen_cities:
            add("unusual_location", 8, f"First transaction seen in {txn['city']} (home city is {customer['home_city']}).")
        else:
            add("unusual_location", 0, "Location matches the customer's usual pattern.", False)

        # 5. Time of day
        hour = _parse(txn["occurred_at"]).hour
        if 0 <= hour < 5 or hour == 23:
            add("odd_hours", 5, f"Transaction occurred at {hour:02d}:xx, outside normal hours.")
        else:
            add("odd_hours", 0, "Transaction occurred during normal hours.", False)

        # 6. Merchant category
        if txn["category"] in RISKY_CATEGORIES:
            add("risky_merchant_category", 10, f"Merchant category {txn['category']} is on the elevated-risk list.")
        else:
            add("risky_merchant_category", 0, "Merchant category is not on the elevated-risk list.", False)

        # 7. Status
        if txn["status"] == "FAILED":
            add("transaction_status", 5, "Transaction failed, which can indicate probing or declined attempts.")
        elif txn["status"] == "PENDING":
            add("transaction_status", 2, "Transaction is still pending.")
        else:
            add("transaction_status", 0, "Transaction completed normally.", False)

        total = min(100, sum(i["points"] for i in indicators))
        return {"score": total, "indicators": indicators}


def calculate_fraud_risk(
    transaction_id: str,
    db_path: str | None = None,
    config: RiskConfig | None = None,
    scorer: RiskScorer | None = None,
) -> dict[str, Any]:
    """Explainable fraud-risk assessment for one transaction."""
    tid = normalize_transaction_id(transaction_id)
    if tid is None:
        return err("INVALID_TRANSACTION_ID", "Transaction ID must look like TXN-9003.")
    cfg = config or get_settings().risk
    engine = scorer or RuleBasedRiskEngine(cfg)

    conn = connect(db_path)
    try:
        txn_row = conn.execute("SELECT * FROM transactions WHERE transaction_id = ?", (tid,)).fetchone()
        if txn_row is None:
            return err("TRANSACTION_NOT_FOUND", f"No transaction with ID {tid} exists in the simulator.")
        txn = dict(txn_row)
        cust_row = conn.execute(
            "SELECT customer_id, home_city, home_country FROM customers WHERE customer_id = ?",
            (txn["customer_id"],),
        ).fetchone()
        if cust_row is None:  # pragma: no cover - FK prevents this
            return err("CUSTOMER_NOT_FOUND", "Transaction references an unknown customer.")
        history = rows_to_dicts(conn.execute(
            "SELECT transaction_id, amount, direction, city, country, status, occurred_at"
            " FROM transactions WHERE customer_id = ? AND transaction_id != ? AND occurred_at < ?",
            (txn["customer_id"], tid, txn["occurred_at"]),
        ).fetchall())
    finally:
        conn.close()

    when = _parse(txn["occurred_at"])
    window_start = when - timedelta(minutes=60)
    recent = [h for h in history if _parse(h["occurred_at"]) >= window_start]

    result = engine.score(txn, {"history": history, "recent_window": recent, "customer": dict(cust_row)})
    score = int(result["score"])
    level = categorize(score, cfg)
    triggered = [i for i in result["indicators"] if i["triggered"]]
    return ok({
        "transaction_id": tid,
        "customer_id": txn["customer_id"],
        "amount": txn["amount"],
        "merchant": txn["merchant"],
        "occurred_at": txn["occurred_at"],
        "risk_score": score,
        "risk_level": level,
        "thresholds": {"medium": cfg.medium, "high": cfg.high},
        "contributing_indicators": triggered,
        "all_indicators": result["indicators"],
        "recommendations": RECOMMENDATIONS[level],
        "engine": {"name": engine.name, "kind": engine.kind},
        "recommended_action": RECOMMENDED_ACTION[level],
        "classification": "SUSPICIOUS" if level == "HIGH" else (
            "REVIEW_RECOMMENDED" if level == "MEDIUM" else "NOT_SUSPICIOUS"),
        "confirmed_fraud": False,
        "disclaimer": DISCLAIMER,
    })


# Alias matching the name used in the assignment text.
assess_transaction_risk = calculate_fraud_risk
