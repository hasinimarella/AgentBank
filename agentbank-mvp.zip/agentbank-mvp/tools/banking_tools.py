"""Simulated core-banking API: customers, accounts, transactions, summaries.

All functions are read-only, validate their inputs, use parameterised SQL and return the
{"ok": ..., "data"/"error": ...} envelope from ``tools.common``.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from database.db import connect, rows_to_dicts
from tools import loan_tools
from tools.common import (
    DATE_RE,
    DEFAULT_TXN_LIMIT,
    MONTH_RE,
    VALID_TXN_STATUSES,
    err,
    mask_email,
    mask_phone,
    normalize_customer_id,
    normalize_transaction_id,
    ok,
    validate_limit,
)


def _bad_customer(value: Any) -> dict[str, Any]:
    return err("INVALID_CUSTOMER_ID", "Customer ID must look like C1001 (letter C plus four digits).")


def get_customer(customer_id: str, db_path: str | None = None) -> dict[str, Any]:
    """Customer profile. E-mail and phone are masked; financial profile fields are not returned
    here (see ``get_loan_profile``)."""
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return _bad_customer(customer_id)
    conn = connect(db_path)
    try:
        row = conn.execute(
            "SELECT customer_id, full_name, email, phone, home_city, home_country, kyc_status,"
            " customer_since FROM customers WHERE customer_id = ?",
            (cid,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return err("CUSTOMER_NOT_FOUND", f"No customer with ID {cid} exists in the simulator.")
    data = dict(row)
    data["email"] = mask_email(data["email"])
    data["phone"] = mask_phone(data["phone"])
    return ok(data)


def get_account_balance(customer_id: str, db_path: str | None = None) -> dict[str, Any]:
    """All accounts for a customer with status and a per-currency total of ACTIVE+DORMANT balances."""
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return _bad_customer(customer_id)
    conn = connect(db_path)
    try:
        exists = conn.execute("SELECT 1 FROM customers WHERE customer_id = ?", (cid,)).fetchone()
        if exists is None:
            return err("CUSTOMER_NOT_FOUND", f"No customer with ID {cid} exists in the simulator.")
        accounts = rows_to_dicts(conn.execute(
            "SELECT account_id, account_type, balance, currency, status, opened_on"
            " FROM accounts WHERE customer_id = ? ORDER BY account_id",
            (cid,),
        ).fetchall())
    finally:
        conn.close()
    if not accounts:
        return err("NO_ACCOUNTS", f"Customer {cid} has no accounts on file.")
    totals: dict[str, float] = defaultdict(float)
    for a in accounts:
        if a["status"] in ("ACTIVE", "DORMANT"):
            totals[a["currency"]] += a["balance"]
    return ok({
        "customer_id": cid,
        "accounts": accounts,
        "total_balance": round(sum(totals.values()), 2),
        "currency": next(iter(totals), accounts[0]["currency"]),
    })


def get_transactions(
    customer_id: str,
    limit: int = DEFAULT_TXN_LIMIT,
    status: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    transaction_id: str | None = None,
    db_path: str | None = None,
) -> dict[str, Any]:
    """Most recent transactions (newest first) with optional filters.

    An empty history is a successful, empty result, not an error.
    """
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return _bad_customer(customer_id)
    lim, problem = validate_limit(limit)
    if problem:
        return err("INVALID_LIMIT", problem)

    clauses = ["customer_id = ?"]
    params: list[Any] = [cid]
    if status is not None:
        st = str(status).strip().upper()
        if st not in VALID_TXN_STATUSES:
            return err("INVALID_STATUS", f"status must be one of {', '.join(VALID_TXN_STATUSES)}.")
        clauses.append("status = ?")
        params.append(st)
    for label, value, op in (("start_date", start_date, ">="), ("end_date", end_date, "<=")):
        if value is None:
            continue
        if not isinstance(value, str) or not DATE_RE.match(value):
            return err("INVALID_DATE", f"{label} must use YYYY-MM-DD format.")
        if op == ">=":
            clauses.append("occurred_at >= ?")
            params.append(value + "T00:00:00")
        else:
            clauses.append("occurred_at <= ?")
            params.append(value + "T23:59:59")
    if transaction_id is not None:
        tid = normalize_transaction_id(transaction_id)
        if tid is None:
            return err("INVALID_TRANSACTION_ID", "Transaction ID must look like TXN-9003.")
        clauses.append("transaction_id = ?")
        params.append(tid)

    conn = connect(db_path)
    try:
        exists = conn.execute("SELECT 1 FROM customers WHERE customer_id = ?", (cid,)).fetchone()
        if exists is None:
            return err("CUSTOMER_NOT_FOUND", f"No customer with ID {cid} exists in the simulator.")
        total = conn.execute(
            f"SELECT COUNT(*) FROM transactions WHERE {' AND '.join(clauses)}", params
        ).fetchone()[0]
        rows = conn.execute(
            "SELECT transaction_id, account_id, amount, direction, merchant, category, city,"
            " country, channel, status, occurred_at FROM transactions"
            f" WHERE {' AND '.join(clauses)} ORDER BY occurred_at DESC, transaction_id DESC LIMIT ?",
            [*params, lim],
        ).fetchall()
    finally:
        conn.close()
    return ok({
        "customer_id": cid,
        "limit": lim,
        "total_matching": total,
        "returned": len(rows),
        "transactions": rows_to_dicts(rows),
    })


def get_transaction(transaction_id: str, db_path: str | None = None) -> dict[str, Any]:
    """A single transaction by ID."""
    tid = normalize_transaction_id(transaction_id)
    if tid is None:
        return err("INVALID_TRANSACTION_ID", "Transaction ID must look like TXN-9003.")
    conn = connect(db_path)
    try:
        row = conn.execute(
            "SELECT transaction_id, customer_id, account_id, amount, direction, merchant,"
            " category, city, country, channel, status, occurred_at"
            " FROM transactions WHERE transaction_id = ?",
            (tid,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return err("TRANSACTION_NOT_FOUND", f"No transaction with ID {tid} exists in the simulator.")
    return ok(dict(row))


def get_spending_analysis(customer_id: str, month: str | None = None, db_path: str | None = None) -> dict[str, Any]:
    """Spending by category for one calendar month (COMPLETED debits only).

    ``month`` is 'YYYY-MM'. When omitted, the most recent month that has completed debits is used.
    """
    cid = normalize_customer_id(customer_id)
    if cid is None:
        return _bad_customer(customer_id)
    if month is not None and (not isinstance(month, str) or not MONTH_RE.match(month)):
        return err("INVALID_MONTH", "month must use YYYY-MM format, for example 2026-09.")
    conn = connect(db_path)
    try:
        if conn.execute("SELECT 1 FROM customers WHERE customer_id = ?", (cid,)).fetchone() is None:
            return err("CUSTOMER_NOT_FOUND", f"No customer with ID {cid} exists in the simulator.")
        months = [r[0] for r in conn.execute(
            "SELECT DISTINCT substr(occurred_at, 1, 7) FROM transactions"
            " WHERE customer_id = ? AND direction = 'DEBIT' AND status = 'COMPLETED'"
            " ORDER BY 1 DESC", (cid,)).fetchall()]
        chosen = month or (months[0] if months else None)
        rows = []
        if chosen:
            rows = rows_to_dicts(conn.execute(
                "SELECT transaction_id, amount, merchant, category FROM transactions"
                " WHERE customer_id = ? AND direction = 'DEBIT' AND status = 'COMPLETED'"
                " AND substr(occurred_at, 1, 7) = ?", (cid, chosen)).fetchall())
    finally:
        conn.close()

    total = round(sum(r["amount"] for r in rows), 2)
    by_cat: dict[str, float] = defaultdict(float)
    by_merchant: dict[str, float] = defaultdict(float)
    for r in rows:
        by_cat[r["category"]] += r["amount"]
        by_merchant[r["merchant"]] += r["amount"]
    categories = [{"category": c, "amount": round(a, 2), "share": round(a / total, 4) if total else 0.0}
                  for c, a in sorted(by_cat.items(), key=lambda kv: kv[1], reverse=True)]
    merchants = [{"merchant": m, "amount": round(a, 2)}
                 for m, a in sorted(by_merchant.items(), key=lambda kv: kv[1], reverse=True)[:5]]
    return ok({
        "customer_id": cid,
        "month": chosen,
        "month_was_requested": month is not None,
        "available_months": months,
        "transaction_count": len(rows),
        "total_spent": total,
        "average_per_transaction": round(total / len(rows), 2) if rows else 0.0,
        "by_category": categories,
        "top_merchants": merchants,
        "currency": "INR",
        "basis": "Completed debit transactions only.",
    })


def compute_financial_summary(
    customer: dict[str, Any],
    balance: dict[str, Any] | None,
    transactions: dict[str, Any] | None,
    loan_profile: dict[str, Any] | None,
) -> dict[str, Any]:
    """Pure aggregation of already-fetched tool outputs (returns the standard result envelope).
    Missing inputs stay missing.

    ``balance`` / ``transactions`` / ``loan_profile`` are the ``data`` payloads of the
    corresponding tools (or None if that tool failed). Nothing is invented.
    """
    unavailable: list[str] = []
    summary: dict[str, Any] = {
        "customer_id": customer["customer_id"],
        "full_name": customer["full_name"],
        "kyc_status": customer["kyc_status"],
        "customer_since": customer["customer_since"],
        "home_city": customer["home_city"],
    }

    if balance is not None:
        summary["total_balance"] = balance["total_balance"]
        summary["currency"] = balance["currency"]
        summary["account_count"] = len(balance["accounts"])
        summary["accounts"] = [
            {k: a[k] for k in ("account_id", "account_type", "status", "balance")}
            for a in balance["accounts"]
        ]
    else:
        unavailable.append("balances")

    if transactions is not None:
        txns = transactions["transactions"]
        completed = [t for t in txns if t["status"] == "COMPLETED"]
        inflow = sum(t["amount"] for t in completed if t["direction"] == "CREDIT")
        outflow = sum(t["amount"] for t in completed if t["direction"] == "DEBIT")
        by_cat: dict[str, float] = defaultdict(float)
        for t in completed:
            if t["direction"] == "DEBIT":
                by_cat[t["category"]] += t["amount"]
        top = sorted(by_cat.items(), key=lambda kv: kv[1], reverse=True)[:3]
        summary["activity"] = {
            "transactions_analysed": len(txns),
            "total_matching_on_file": transactions["total_matching"],
            "completed_inflow": round(inflow, 2),
            "completed_outflow": round(outflow, 2),
            "pending_or_failed": sum(1 for t in txns if t["status"] != "COMPLETED"),
            "top_spending_categories": [{"category": c, "amount": round(a, 2)} for c, a in top],
            "latest_transaction_at": txns[0]["occurred_at"] if txns else None,
        }
        summary["recent_transactions"] = [
            {k: t[k] for k in ("transaction_id", "occurred_at", "direction", "amount", "merchant", "category", "status")}
            for t in txns[:5]
        ]
    else:
        unavailable.append("transaction activity")

    if loan_profile is not None:
        summary["credit_profile"] = loan_profile
        if loan_profile.get("monthly_income") in (None, 0):
            unavailable.append("income (not on file)")
    else:
        unavailable.append("credit profile")

    summary["unavailable"] = unavailable
    return ok(summary)


def get_financial_summary(customer_id: str, db_path: str | None = None) -> dict[str, Any]:
    """Composite convenience tool: fetches each component and aggregates them.

    The Banking Agent does NOT call this; it runs the same steps one by one so each tool call
    appears in the execution trace. This function exists for API completeness and tests.
    """
    cust = get_customer(customer_id, db_path)
    if not cust["ok"]:
        return cust
    cid = cust["data"]["customer_id"]
    bal = get_account_balance(cid, db_path)
    txns = get_transactions(cid, limit=50, db_path=db_path)
    prof = loan_tools.get_loan_profile(cid, db_path)
    return compute_financial_summary(
        cust["data"],
        bal["data"] if bal["ok"] else None,
        txns["data"] if txns["ok"] else None,
        prof["data"] if prof["ok"] else None,
    )


# Alias matching the name used in the assignment text.
get_customer_financial_summary = get_financial_summary
