"""Shared helpers for the simulated banking tool layer.

Every tool returns a plain dict:
    {"ok": True,  "data": {...}}
    {"ok": False, "error": {"code": "...", "message": "..."}}
so callers never need try/except for expected failures (missing records, bad input).
"""
from __future__ import annotations

import re
from typing import Any

CUSTOMER_ID_RE = re.compile(r"^C\d{4}$")
TRANSACTION_ID_RE = re.compile(r"^TXN-\d{4,}$")
MAX_TXN_LIMIT = 50
DEFAULT_TXN_LIMIT = 5
VALID_TXN_STATUSES = ("COMPLETED", "PENDING", "FAILED")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


def ok(data: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True, "data": data}


def err(code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "error": {"code": code, "message": message}}


def normalize_customer_id(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    candidate = value.strip().upper()
    return candidate if CUSTOMER_ID_RE.match(candidate) else None


def normalize_transaction_id(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    candidate = value.strip().upper()
    return candidate if TRANSACTION_ID_RE.match(candidate) else None


def validate_limit(value: Any) -> tuple[int | None, str | None]:
    """Return (limit, error). Booleans and non-integers are rejected."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None, "limit must be a whole number"
    if int(value) != value:
        return None, "limit must be a whole number"
    value = int(value)
    if value < 1 or value > MAX_TXN_LIMIT:
        return None, f"limit must be between 1 and {MAX_TXN_LIMIT}"
    return value, None


def validate_amount(value: Any, minimum: float, maximum: float) -> tuple[float | None, str | None]:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None, "amount must be a number"
    if value != value or value in (float("inf"), float("-inf")):
        return None, "amount must be a finite number"
    if value <= 0:
        return None, "amount must be greater than zero"
    if value < minimum:
        return None, f"amount is below the simulator minimum of {minimum:,.0f}"
    if value > maximum:
        return None, f"amount exceeds the simulator maximum of {maximum:,.0f}"
    return float(value), None


def mask_email(email: str) -> str:
    if "@" not in email:
        return "***"
    local, domain = email.split("@", 1)
    return f"{local[:1]}***@{domain}"


def mask_phone(phone: str) -> str:
    digits = re.sub(r"\D", "", phone)
    return f"+**-*****-**{digits[-3:]}" if len(digits) >= 3 else "***"
