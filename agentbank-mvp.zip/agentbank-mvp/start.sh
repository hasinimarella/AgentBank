#!/usr/bin/env bash
# macOS / Linux equivalent of start.bat
set -euo pipefail
cd "$(dirname "$0")"

PY=""
for candidate in python3.13 python3.12 python3.11 python3 python; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
    PY="$candidate"; break
  fi
done
if [ -z "$PY" ]; then
  echo "[ERROR] Python 3.11 or newer was not found." >&2
  exit 1
fi

[ -d .venv ] || "$PY" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --disable-pip-version-check -r requirements.txt
python -m data.seed_data
echo "Starting AgentBank at http://localhost:8501"
exec python -m streamlit run app.py
