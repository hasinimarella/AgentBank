"""The local rule-based intent classifier and entity extractor (no LLM involved)."""
import pytest

from llm.base import Intent
from llm.entities import extract_amount, extract_entities, extract_limit, extract_month, find_ids
from llm.fallback_provider import FallbackProvider

clf = FallbackProvider()


def classify(text):
    return clf.classify_intent(text)


# 1-5: every supported intent, several phrasings each ---------------------------------------------------------
INTENT_CASES = {
    Intent.ACCOUNT_BALANCE: [
        "What is the account balance for customer C1001?", "balance of C1002", "How much money does C1003 have?",
        "show me the account status for C1005"],
    Intent.TRANSACTION_HISTORY: [
        "Show the last five transactions for customer C1002.", "transaction history for C1004",
        "list 3 recent transactions of C1001", "Show TXN-9003", "statement for C1002"],
    Intent.FRAUD_ASSESSMENT: [
        "Check transaction TXN-9003 for fraud risk.", "Is TXN-9004 suspicious?", "fraud check on TXN-9010",
        "how risky is TXN-9102", "Could TXN-9003 be a scam?"],
    Intent.LOAN_ELIGIBILITY: [
        "Is customer C1001 eligible for a loan of ₹200000?", "Can C1002 borrow Rs 2,00,000?",
        "loan eligibility for C1003 for 3 lakh", "Will C1001 qualify for a 5 lakh loan"],
    Intent.CUSTOMER_FINANCIAL_SUMMARY: [
        "Give me a complete financial summary for customer C1003.", "financial summary for C1001",
        "overview of C1004", "financial profile of C1002"],
    Intent.SPENDING_ANALYSIS: [
        "Show the monthly spending analysis for customer C1002.", "How much did C1004 spend in October 2026?",
        "expenses of C1001"],
}


@pytest.mark.parametrize("intent,text", [(i, t) for i, ts in INTENT_CASES.items() for t in ts])
def test_intent_classification(intent, text):
    assert classify(text).intent == intent


@pytest.mark.parametrize("text", [
    "hello", "what can you do", "tell me a joke", "asdf qwer", "", "1234", "C1001", "weather in Chennai",
    "Transfer ₹5000 from C1001 to C1002", "freeze the account of C1004", "approve the loan for C1001"])
def test_unknown_and_unsupported_map_to_unknown(text):
    assert classify(text).intent == Intent.UNKNOWN


def test_action_requests_are_flagged_unsupported():
    assert FallbackProvider.is_unsupported_action("Transfer ₹5000 from C1001 to C1002")
    assert FallbackProvider.is_unsupported_action("approve the loan for C1001")
    assert not FallbackProvider.is_unsupported_action("What is the balance for C1001?")
    assert not FallbackProvider.is_unsupported_action("hello")


def test_case_and_punctuation_insensitive():
    assert classify("WHAT IS THE ACCOUNT BALANCE FOR CUSTOMER c1001???").intent == Intent.ACCOUNT_BALANCE


def test_fraud_beats_transaction_keyword():
    assert classify("Check transaction TXN-9003 for fraud risk").intent == Intent.FRAUD_ASSESSMENT


# 6: customer IDs ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("balance for C1001", "C1001"), ("balance for c1001", "C1001"), ("balance for customer 1002", "C1002"),
    ("customer id C1003, please", "C1003"), ("(C1004)", "C1004"), ("balance for C-1005", "C1005")])
def test_customer_id_extraction(text, expected):
    assert extract_entities(text)["customer_id"] == expected


@pytest.mark.parametrize("text", ["balance please", "ABC1001", "C10012", "C100", "customer"])
def test_customer_id_absent_or_malformed(text):
    assert extract_entities(text)["customer_id"] is None


# 7: transaction IDs ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("Check TXN-9003", "TXN-9003"), ("check txn-9003", "TXN-9003"), ("check TXN 9003", "TXN-9003"),
    ("check TXN9003 now", "TXN-9003"), ("TXN_9004?", "TXN-9004")])
def test_transaction_id_extraction(text, expected):
    assert extract_entities(text)["transaction_id"] == expected


def test_transaction_id_absent():
    assert extract_entities("check my last transaction")["transaction_id"] is None


# 8: loan amounts, including ₹ and rupee formats -------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("a loan of ₹200000", 200000), ("₹ 2,00,000", 200000), ("₹2,00,000.50", 200000.5), ("Rs 200000", 200000),
    ("Rs. 75,000", 75000), ("INR 150000", 150000), ("200000 rupees", 200000), ("200000 INR", 200000),
    ("2 lakh", 200000), ("2.5 lakhs", 250000), ("3 lac", 300000), ("50k", 50000), ("1 crore", 10_000_000),
    ("rupees 90000", 90000)])
def test_amount_extraction_formats(text, expected):
    assert extract_amount(text) == pytest.approx(expected)


def test_amount_ignores_ids_and_counts():
    assert extract_amount("last 5 transactions for C1002") is None
    assert extract_amount("TXN-9003 for C1001") is None
    assert extract_entities("Is C1001 eligible for ₹200000?")["amount"] == 200000


def test_loan_prompt_without_currency_symbol_uses_bare_number():
    e = clf.classify_intent("Is customer C1001 eligible for a loan of 250000?")
    assert e.amount == 250000 and e.customer_id == "C1001"


# transaction count / limit ----------------------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("last five transactions", 5), ("last 7 transactions", 7), ("show 3 transactions", 3),
    ("the ten most recent transactions", 10), ("transactions for C1002", None)])
def test_limit_extraction(text, expected):
    assert extract_limit(text) == expected


# other entities ---------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("spending in 2026-09", "2026-09"), ("spending in September 2026", "2026-09"), ("spend in oct 2026", "2026-10"),
    ("spending last month", None), ("spending in September", None), ("since 2026-09-15", None)])
def test_month_extraction(text, expected):
    assert extract_month(text) == expected


def test_status_filter_and_dates():
    e = extract_entities("show failed transactions for C1004 since 2026-09-15")
    assert e["status"] == "FAILED" and e["start_date"] == "2026-09-15"


def test_multiple_ids_are_all_reported():
    assert find_ids("compare C1001 with C1002 and TXN-9003")[0] == ["C1001", "C1002"]


def test_classification_result_is_structured_and_marked_as_rules():
    r = classify("What is the account balance for customer C1001?")
    assert r.source == "fallback" and r.entities()["customer_id"] == "C1001" and 0 < r.confidence <= 1


def test_classifier_is_deterministic():
    text = "Is customer C1001 eligible for a loan of ₹200000?"
    assert classify(text) == classify(text)
