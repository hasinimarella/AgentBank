"""Illustrative loan engine and the LoanAgent workflow."""
import math

import pytest

from config.settings import LoanConfig
from database.db import connect
from tools.loan_tools import assess_loan_eligibility, get_loan_profile, monthly_payment


def decision(db, cid, amount, **kw):
    return assess_loan_eligibility(cid, amount, db_path=db, **kw)


class TestDecisions:
    def test_c1001_200000_eligible(self, db_path):
        r = decision(db_path, "C1001", 200000)
        d = r["data"]
        assert r["ok"] and d["decision"] == "ELIGIBLE"
        assert d["dti_before_loan"] == pytest.approx(15000 / 120000)
        assert d["dti_after_loan"] == pytest.approx((15000 + d["estimated_monthly_payment"]) / 120000, abs=1e-3)
        assert all(c["outcome"] == "PASS" for c in d["checks"])

    def test_c1002_small_loan_eligible_large_loan_referred(self, db_path):
        assert decision(db_path, "C1002", 200000)["data"]["decision"] == "ELIGIBLE"
        big = decision(db_path, "C1002", 600000)["data"]
        assert big["decision"] == "REFER_TO_REVIEW"
        assert any("smaller amount" in r for r in big["recommendations"])

    def test_c1003_not_eligible_with_reasons(self, db_path):
        d = decision(db_path, "C1003", 200000)["data"]
        assert d["decision"] == "NOT_ELIGIBLE"
        failing = {c["check"] for c in d["checks"] if c["outcome"] == "FAIL"}
        assert {"debt_to_income", "employment_stability"} <= failing
        assert d["dti_after_loan"] > 0.5

    def test_c1006_new_low_score_customer_not_eligible(self, db_path):
        d = decision(db_path, "C1006", 200000)["data"]
        assert d["decision"] == "NOT_ELIGIBLE"
        assert {c["check"] for c in d["checks"] if c["outcome"] == "FAIL"} >= {"credit_score", "employment_stability"}

    def test_loan_larger_than_income_multiple_fails(self, db_path):
        d = decision(db_path, "C1003", 2_000_000)["data"]
        assert any(c["check"] == "loan_to_annual_income" and c["outcome"] == "FAIL" for c in d["checks"])

    def test_decisions_are_deterministic(self, db_path):
        assert decision(db_path, "C1002", 600000) == decision(db_path, "C1002", 600000)


class TestMissingData:
    def test_missing_income_is_insufficient_data(self, db_path):
        d = decision(db_path, "C1005", 200000)["data"]
        assert d["decision"] == "INSUFFICIENT_DATA"
        assert "monthly income" in d["missing_information"] and "existing monthly debt" in d["missing_information"]
        assert d["dti_after_loan"] is None and d["checks"] == []
        assert d["recommendations"]

    def test_loan_profile_returns_none_not_zero(self, db_path):
        p = get_loan_profile("C1005", db_path)["data"]
        assert p["monthly_income"] is None and p["current_dti"] is None and p["credit_score"] == 680


class TestValidation:
    @pytest.mark.parametrize("bad", [0, -1, -50000.0, "abc", None, True, float("inf"), float("nan"), 5000, 6_000_000])
    def test_invalid_amounts(self, db_path, bad):
        r = decision(db_path, "C1001", bad)
        assert not r["ok"] and r["error"]["code"] == "INVALID_AMOUNT"

    def test_boundary_amounts_accepted(self, db_path):
        assert decision(db_path, "C1001", 10000)["ok"]
        assert decision(db_path, "C1001", 5_000_000)["ok"]

    def test_invalid_customer_id(self, db_path):
        assert decision(db_path, "bad", 200000)["error"]["code"] == "INVALID_CUSTOMER_ID"

    def test_unknown_customer(self, db_path):
        assert decision(db_path, "C9999", 200000)["error"]["code"] == "CUSTOMER_NOT_FOUND"


class TestConfigurable:
    def test_emi_formula(self):
        assert monthly_payment(200000, 0.11, 36) == pytest.approx(6547.74, abs=0.01)
        assert monthly_payment(120000, 0.0, 12) == pytest.approx(10000)
        r = 0.11 / 12
        assert monthly_payment(1, 0.11, 12) == pytest.approx(r * (1 + r) ** 12 / ((1 + r) ** 12 - 1))

    def test_relaxed_thresholds_flip_c1006(self, db_path):
        relaxed = LoanConfig(min_credit_score=500, refer_credit_score=400, min_employment_years=0.1)
        assert decision(db_path, "C1006", 200000)["data"]["decision"] == "NOT_ELIGIBLE"
        assert decision(db_path, "C1006", 200000, config=relaxed)["data"]["decision"] == "ELIGIBLE"

    def test_stricter_dti_changes_c1001(self, db_path):
        strict = LoanConfig(max_dti=0.10, refer_dti=0.15)
        assert decision(db_path, "C1001", 200000, config=strict)["data"]["decision"] == "NOT_ELIGIBLE"

    def test_persist_writes_assessment_row(self, fresh_db):
        decision(fresh_db, "C1001", 200000, persist=True)
        conn = connect(fresh_db)
        try:
            row = conn.execute("SELECT customer_id, decision FROM loan_assessments").fetchone()
        finally:
            conn.close()
        assert tuple(row) == ("C1001", "ELIGIBLE")

    def test_default_does_not_persist(self, fresh_db):
        decision(fresh_db, "C1001", 200000)
        conn = connect(fresh_db)
        try:
            assert conn.execute("SELECT COUNT(*) FROM loan_assessments").fetchone()[0] == 0
        finally:
            conn.close()

    def test_suggested_smaller_amount_actually_fits(self, db_path):
        d = decision(db_path, "C1002", 600000)["data"]
        text = next(r for r in d["recommendations"] if "smaller amount" in r)
        suggested = float(text.split("about ")[1].split(" ")[0].replace(",", ""))
        assert suggested < 600000
        assert decision(db_path, "C1002", suggested)["data"]["decision"] == "ELIGIBLE"
        assert math.isclose(suggested % 1000, 0)


class TestLabelling:
    def test_illustrative_not_a_real_decision(self, db_path):
        d = decision(db_path, "C1001", 200000)["data"]
        assert "not a real lending decision" in d["disclaimer"].lower()
        assert "not machine learning" in d["engine"]["kind"]


class TestLoanAgentWorkflow:
    def test_supervisor_routes_and_traces(self, supervisor):
        r = supervisor.handle("Is customer C1001 eligible for a loan of ₹200000?")
        assert r.status == "ok" and r.agent == "LoanAgent" and r.entities["amount"] == 200000.0
        assert [c["tool"] for c in r.trace["tool_calls"]] == ["get_customer", "assess_loan_eligibility"]
        assert "ELIGIBLE (illustrative)" in r.message and "not a real lending decision" in r.message.lower()

    def test_invalid_amount_message(self, supervisor):
        r = supervisor.handle("Is C1001 eligible for a loan of 500 rupees?")
        assert r.status == "invalid_input" and "minimum" in r.message

    def test_missing_info_reported(self, supervisor):
        r = supervisor.handle("Is customer C1005 eligible for a loan of ₹200000?")
        assert r.status == "ok" and "INSUFFICIENT DATA" in r.message and "monthly income" in r.message
