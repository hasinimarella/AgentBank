"""LLM layer: output validation, providers (over real HTTP to a local scripted server), selection and fallback.

NOTE: the server in fake_llm_server.py replies with whatever each test scripts. These tests prove the
plumbing, validation, grounding and fallback logic. They do NOT measure how well any real model classifies.
"""
import json
import dataclasses

import pytest

from agents.supervisor import Supervisor
from config.settings import LLMConfig, get_settings
from llm.base import (
    Intent, LLMTimeoutError, LLMUnavailableError, LLMValidationError, LLMError, validate_llm_output)
from llm.factory import select_provider
from llm.ollama_provider import OllamaProvider
from llm.openai_compatible_provider import OpenAICompatibleProvider
from services.response_builder import numbers_grounded
from tests.conftest import settings_with_llm
from tests.fake_llm_server import FakeLLMServer, closed_port_url


@pytest.fixture
def server():
    s = FakeLLMServer().start()
    yield s
    s.stop()


def reply(**fields):
    base = {"intent": "UNKNOWN", "customer_id": None, "transaction_id": None, "amount": None,
            "limit": None, "status": None, "confidence": 0.9}
    base.update(fields)
    return json.dumps(base)


# ---------------------------------------------------------------------------------------------------------
# validate_llm_output
# ---------------------------------------------------------------------------------------------------------
class TestValidation:
    MSG = "What is the account balance for customer C1001?"

    def test_valid_json(self):
        r = validate_llm_output(reply(intent="ACCOUNT_BALANCE", customer_id="C1001"), self.MSG)
        assert r.intent == Intent.ACCOUNT_BALANCE and r.customer_id == "C1001" and r.source == "llm"

    def test_json_in_code_fence_and_with_prose(self):
        raw = "Sure!\n```json\n" + reply(intent="ACCOUNT_BALANCE", customer_id="C1001") + "\n```"
        assert validate_llm_output(raw, self.MSG).customer_id == "C1001"
        raw2 = "Here you go: " + reply(intent="ACCOUNT_BALANCE", customer_id="C1001") + " hope that helps"
        assert validate_llm_output(raw2, self.MSG).intent == Intent.ACCOUNT_BALANCE

    def test_lowercase_id_normalised(self):
        r = validate_llm_output(reply(intent="ACCOUNT_BALANCE", customer_id="c1001"), "balance of c1001")
        assert r.customer_id == "C1001"

    def test_null_strings_become_none(self):
        r = validate_llm_output(reply(intent="ACCOUNT_BALANCE", customer_id="C1001", amount="null", limit=""), self.MSG)
        assert r.amount is None and r.limit is None

    def test_extra_keys_ignored_and_source_cannot_be_spoofed(self):
        raw = json.dumps({"intent": "ACCOUNT_BALANCE", "customer_id": "C1001", "source": "trusted", "run_sql": "DROP"})
        r = validate_llm_output(raw, self.MSG)
        assert r.source == "llm" and not hasattr(r, "run_sql")

    @pytest.mark.parametrize("raw", [
        "", "   ", None, "I think you want the balance.", "{not json", "[1, 2, 3]", '"just a string"', "{}"])
    def test_unparseable_or_empty(self, raw):
        with pytest.raises(LLMValidationError):
            validate_llm_output(raw, self.MSG)

    @pytest.mark.parametrize("fields", [
        {"intent": "DELETE_EVERYTHING"}, {"intent": "balance"}, {"intent": 7},
        {"intent": "ACCOUNT_BALANCE", "customer_id": "CUST-1001"},
        {"intent": "ACCOUNT_BALANCE", "customer_id": "C1001'; DROP TABLE customers;--"},
        {"intent": "FRAUD_ASSESSMENT", "transaction_id": "9003"},
        {"intent": "TRANSACTION_HISTORY", "customer_id": "C1001", "limit": 9999},
        {"intent": "TRANSACTION_HISTORY", "customer_id": "C1001", "limit": 0},
        {"intent": "TRANSACTION_HISTORY", "customer_id": "C1001", "status": "HACKED"},
        {"intent": "LOAN_ELIGIBILITY", "customer_id": "C1001", "amount": -5},
        {"intent": "LOAN_ELIGIBILITY", "customer_id": "C1001", "amount": "lots"},
        {"intent": "ACCOUNT_BALANCE", "customer_id": "C1001", "confidence": 5},
        {"intent": "TRANSACTION_HISTORY", "customer_id": "C1001", "start_date": "yesterday"},
    ])
    def test_schema_violations_rejected(self, fields):
        with pytest.raises(LLMValidationError):
            validate_llm_output(reply(**fields), "Show 5 transactions for C1001 amount 100")

    def test_hallucinated_customer_id_rejected(self):
        with pytest.raises(LLMValidationError, match="customer_id"):
            validate_llm_output(reply(intent="ACCOUNT_BALANCE", customer_id="C1002"), self.MSG)

    def test_hallucinated_transaction_id_rejected(self):
        with pytest.raises(LLMValidationError, match="transaction_id"):
            validate_llm_output(reply(intent="FRAUD_ASSESSMENT", transaction_id="TXN-9003"), "is that transaction fraud?")

    def test_amount_must_agree_with_message(self):
        msg = "Is C1001 eligible for a loan of ₹200000?"
        assert validate_llm_output(reply(intent="LOAN_ELIGIBILITY", customer_id="C1001", amount=200000), msg).amount == 200000
        with pytest.raises(LLMValidationError, match="disagrees"):
            validate_llm_output(reply(intent="LOAN_ELIGIBILITY", customer_id="C1001", amount=2000000), msg)

    def test_invented_amount_without_any_number_rejected(self):
        with pytest.raises(LLMValidationError, match="no number"):
            validate_llm_output(reply(intent="LOAN_ELIGIBILITY", customer_id="C1001", amount=500000),
                                "Is C1001 eligible for a loan?")

    def test_amount_in_words_accepted_when_message_has_number_word(self):
        r = validate_llm_output(reply(intent="LOAN_ELIGIBILITY", customer_id="C1001", amount=200000),
                                "can C1001 get two hundred thousand rupees; that is 2 lakh")
        assert r.amount == 200000

    def test_limit_must_agree(self):
        with pytest.raises(LLMValidationError):
            validate_llm_output(reply(intent="TRANSACTION_HISTORY", customer_id="C1001", limit=20),
                                "last 5 transactions for C1001")


# ---------------------------------------------------------------------------------------------------------
# Ollama provider over HTTP
# ---------------------------------------------------------------------------------------------------------
class TestOllamaProvider:
    def test_available_when_model_installed(self, server):
        st = OllamaProvider(server.base_url, "llama3.2:3b", 2).check_available()
        assert st.available and "installed" in st.detail

    def test_unavailable_when_model_missing_gives_pull_hint(self, server):
        st = OllamaProvider(server.base_url, "mistral:7b", 2).check_available()
        assert not st.available and "ollama pull mistral:7b" in st.detail

    def test_latest_tag_matches_untagged_name(self, server):
        server.models = ["tinyllama:latest"]
        assert OllamaProvider(server.base_url, "tinyllama", 2).check_available().available

    def test_unavailable_when_server_down(self):
        st = OllamaProvider(closed_port_url(), "llama3.2:3b", 2).check_available()
        assert not st.available and "not reachable" in st.detail

    def test_classify_success_sends_json_mode_and_zero_temperature(self, server):
        server.classify_reply = reply(intent="FRAUD_ASSESSMENT", transaction_id="TXN-9003")
        r = OllamaProvider(server.base_url, "llama3.2:3b", 5).classify_intent("Check TXN-9003 for fraud risk")
        assert r.intent == Intent.FRAUD_ASSESSMENT and r.transaction_id == "TXN-9003" and r.source == "llm"
        payload = next(x["payload"] for x in server.requests if x["method"] == "POST")
        assert payload["model"] == "llama3.2:3b" and payload["format"] == "json"
        assert payload["options"]["temperature"] == 0 and payload["stream"] is False

    def test_malformed_response(self, server):
        server.classify_reply = "I'm sorry, I can't produce JSON today."
        with pytest.raises(LLMValidationError):
            OllamaProvider(server.base_url, "llama3.2:3b", 5).classify_intent("balance C1001")

    def test_http_error(self, server):
        server.http_status = 500
        with pytest.raises(LLMError, match="HTTP 500"):
            OllamaProvider(server.base_url, "llama3.2:3b", 5).classify_intent("balance C1001")

    def test_timeout(self, server):
        server.delay = 1.5
        with pytest.raises(LLMTimeoutError):
            OllamaProvider(server.base_url, "llama3.2:3b", 0.3).classify_intent("balance C1001")

    def test_connection_refused(self):
        with pytest.raises(LLMUnavailableError):
            OllamaProvider(closed_port_url(), "llama3.2:3b", 2).classify_intent("balance C1001")


class TestOpenAICompatibleProvider:
    def test_requires_configuration(self):
        st = OpenAICompatibleProvider("", "", "", 2).check_available()
        assert not st.available and "must both be set" in st.detail

    def test_success_and_bearer_key_sent(self, server):
        server.api_key_required = "test-key-not-real"
        server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001")
        p = OpenAICompatibleProvider(server.base_url + "/v1", "any-model", "test-key-not-real", 5)
        assert p.check_available().available
        assert p.classify_intent("balance of C1001").customer_id == "C1001"
        assert [x["auth"] for x in server.requests if x["method"] == "POST"] == ["Bearer test-key-not-real"]

    def test_wrong_key_rejected(self, server):
        server.api_key_required = "right"
        st = OpenAICompatibleProvider(server.base_url + "/v1", "m", "wrong", 5).check_available()
        assert not st.available and "credentials" in st.detail

    def test_key_not_in_repr_or_settings_repr(self):
        cfg = LLMConfig(openai_compat_api_key="super-secret-value")
        assert "super-secret-value" not in repr(cfg)
        assert "super-secret-value" not in repr(dataclasses.replace(get_settings(), llm=cfg))


# ---------------------------------------------------------------------------------------------------------
# Provider selection: modes are honest
# ---------------------------------------------------------------------------------------------------------
class TestSelection:
    def test_fallback_setting_never_contacts_server(self, server):
        sel = select_provider(settings_with_llm(provider="fallback", ollama_base_url=server.base_url))
        assert sel.mode == "FALLBACK" and sel.llm is None and server.requests == []

    def test_auto_uses_llm_when_reachable_and_model_present(self, server):
        sel = select_provider(settings_with_llm(provider="auto", ollama_base_url=server.base_url, ollama_model="llama3.2:3b"))
        assert sel.mode == "LLM" and sel.provider_name == "ollama" and sel.model == "llama3.2:3b"

    @pytest.mark.parametrize("provider", ["auto", "ollama"])
    def test_unreachable_falls_back_with_reason(self, provider):
        sel = select_provider(settings_with_llm(provider=provider, ollama_base_url=closed_port_url(), timeout_seconds=2))
        assert sel.mode == "FALLBACK" and sel.llm is None and "not reachable" in sel.detail

    def test_missing_model_falls_back_with_pull_hint(self, server):
        sel = select_provider(settings_with_llm(provider="ollama", ollama_base_url=server.base_url, ollama_model="nope:1b"))
        assert sel.mode == "FALLBACK" and "ollama pull nope:1b" in sel.detail

    def test_openai_compatible_selection(self, server):
        sel = select_provider(settings_with_llm(provider="openai_compatible", openai_compat_base_url=server.base_url + "/v1",
                                                openai_compat_model="m"))
        assert sel.mode == "LLM" and sel.provider_name == "openai_compatible"

    def test_unconfigured_openai_compatible_falls_back(self):
        assert select_provider(settings_with_llm(provider="openai_compatible")).mode == "FALLBACK"

    def test_invalid_provider_env_defaults_to_auto(self, monkeypatch):
        monkeypatch.setenv("LLM_PROVIDER", "banana")
        assert get_settings().llm.provider == "auto"

    def test_model_is_configurable_without_code_changes(self, monkeypatch):
        monkeypatch.setenv("OLLAMA_MODEL", "qwen2.5:3b")
        monkeypatch.setenv("OLLAMA_BASE_URL", "http://example.invalid:1234/")
        cfg = get_settings().llm
        assert cfg.ollama_model == "qwen2.5:3b" and cfg.ollama_base_url == "http://example.invalid:1234"


# ---------------------------------------------------------------------------------------------------------
# Supervisor in LLM mode (scripted model) and every failure path back to fallback
# ---------------------------------------------------------------------------------------------------------
USE_CASES = [
    ("What is the account balance for customer C1001?", dict(intent="ACCOUNT_BALANCE", customer_id="C1001"), "BankingAgent"),
    ("Show the last five transactions for customer C1002.", dict(intent="TRANSACTION_HISTORY", customer_id="C1002", limit=5), "BankingAgent"),
    ("Check transaction TXN-9003 for fraud risk.", dict(intent="FRAUD_ASSESSMENT", transaction_id="TXN-9003"), "FraudAgent"),
    ("Is customer C1001 eligible for a loan of ₹200000?", dict(intent="LOAN_ELIGIBILITY", customer_id="C1001", amount=200000), "LoanAgent"),
    ("Give me a financial summary for customer C1003.", dict(intent="CUSTOMER_FINANCIAL_SUMMARY", customer_id="C1003"), "BankingAgent"),
]


def llm_supervisor(server, db_path, **llm_kwargs):
    settings = settings_with_llm(provider="ollama", ollama_base_url=server.base_url, ollama_model="llama3.2:3b",
                                 timeout_seconds=llm_kwargs.pop("timeout_seconds", 5), **llm_kwargs)
    return Supervisor(db_path=db_path, settings=settings, selection=select_provider(settings))


@pytest.mark.parametrize("prompt,fields,agent", USE_CASES)
def test_llm_mode_all_five_use_cases(server, db_path, prompt, fields, agent):
    server.classify_reply = reply(**fields)
    sup = llm_supervisor(server, db_path)
    assert sup.mode["mode"] == "LLM"
    r = sup.handle(prompt)
    assert r.status == "ok" and r.agent == agent
    assert r.trace["intent_source"] == "llm" and r.trace["llm"]["used"] is True
    assert r.trace["llm"]["provider"] == "ollama" and server.chat_calls == 1


def test_llm_intent_cannot_pick_tools_directly(server, db_path):
    server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001", tool="run_sql", agent="FraudAgent")
    r = llm_supervisor(server, db_path).handle("What is the account balance for customer C1001?")
    assert r.agent == "BankingAgent" and [c["tool"] for c in r.trace["tool_calls"]] == ["get_customer", "get_account_balance"]


def test_llm_choosing_fraud_without_txn_id_asks_clarification(server, db_path):
    server.classify_reply = reply(intent="FRAUD_ASSESSMENT", customer_id="C1001")
    r = llm_supervisor(server, db_path).handle("Is C1001 doing anything fishy?")
    assert r.status == "clarification" and r.trace["tool_calls"] == [] and r.trace["intent_source"] == "llm"


FAILURES = [
    ("malformed", lambda s: setattr(s, "classify_reply", "totally not json")),
    ("wrong_schema", lambda s: setattr(s, "classify_reply", reply(intent="HACK_THE_BANK"))),
    ("hallucinated_id", lambda s: setattr(s, "classify_reply", reply(intent="ACCOUNT_BALANCE", customer_id="C1002"))),
    ("http_500", lambda s: setattr(s, "http_status", 500)),
    ("timeout", lambda s: setattr(s, "delay", 1.5)),
]


@pytest.mark.parametrize("name,break_it", FAILURES, ids=[f[0] for f in FAILURES])
def test_llm_failures_fall_back_and_still_answer_correctly(server, db_path, name, break_it):
    break_it(server)
    sup = llm_supervisor(server, db_path, timeout_seconds=0.4)
    r = sup.handle("What is the account balance for customer C1001?")
    assert r.status == "ok" and r.agent == "BankingAgent" and "₹5,47,250.75" in r.message
    assert r.trace["intent_source"] == "fallback"
    assert r.trace["llm"]["used"] is False and r.trace["llm"]["fell_back"] is True and r.trace["llm"]["error"]
    assert any("deterministic fallback" in n for n in r.notices)


def test_llm_goes_down_after_selection(server, db_path):
    server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001")
    sup = llm_supervisor(server, db_path, timeout_seconds=1)
    assert sup.handle("balance for C1001").trace["intent_source"] == "llm"
    server.stop()
    r = sup.handle("balance for C1001")
    assert r.status == "ok" and r.trace["intent_source"] == "fallback" and "not reachable" in r.trace["llm"]["error"]


def test_fallback_mode_makes_zero_llm_calls(server, db_path):
    settings = settings_with_llm(provider="fallback", ollama_base_url=server.base_url)
    sup = Supervisor(db_path=db_path, settings=settings, selection=select_provider(settings))
    for prompt, _, _ in USE_CASES:
        assert sup.handle(prompt).status == "ok"
    assert server.requests == []


def test_trace_never_contains_api_key(server, db_path):
    server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001")
    settings = settings_with_llm(provider="openai_compatible", openai_compat_base_url=server.base_url + "/v1",
                                 openai_compat_model="m", openai_compat_api_key="never-log-me", timeout_seconds=5)
    sup = Supervisor(db_path=db_path, settings=settings, selection=select_provider(settings))
    r = sup.handle("balance for C1001")
    assert r.trace["intent_source"] == "llm"
    assert "never-log-me" not in json.dumps(r.to_dict(), default=str)


# ---------------------------------------------------------------------------------------------------------
# Optional response formulation with number grounding
# ---------------------------------------------------------------------------------------------------------
class TestFormulation:
    PROMPT = "What is the account balance for customer C1001?"

    def _sup(self, server, db_path):
        server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001")
        return llm_supervisor(server, db_path, formulate_responses=True)

    def test_grounded_text_accepted(self, server, db_path):
        server.text_reply = "Aarav Mehta holds a total of ₹5,47,250.75 over 2 accounts."
        r = self._sup(server, db_path).handle(self.PROMPT)
        assert r.ai_summary == server.text_reply
        assert "₹5,47,250.75" in r.message  # deterministic answer is always present

    def test_ungrounded_numbers_discarded(self, server, db_path):
        server.text_reply = "Aarav Mehta has ₹9,99,999 in 7 accounts."
        r = self._sup(server, db_path).handle(self.PROMPT)
        assert r.ai_summary is None and any("unverified numbers" in n for n in r.notices)

    def test_disabled_by_default(self, server, db_path):
        server.classify_reply = reply(intent="ACCOUNT_BALANCE", customer_id="C1001")
        r = llm_supervisor(server, db_path).handle(self.PROMPT)
        assert r.ai_summary is None
        assert all(not (x["method"] == "POST" and x["payload"].get("format") != "json") for x in server.requests)

    def test_not_used_after_llm_fallback(self, server, db_path):
        server.classify_reply = "garbage"
        server.text_reply = "should never be used"
        sup = llm_supervisor(server, db_path, formulate_responses=True)
        assert sup.handle(self.PROMPT).ai_summary is None

    @pytest.mark.parametrize("candidate,ok", [
        ("Balance is 5,47,250.75 rupees", True), ("Balance is 547250.75", True), ("2 accounts", True),
        ("Balance is 600000", False), ("You have 3 accounts", False), ("No numbers at all", True)])
    def test_numbers_grounded(self, candidate, ok):
        facts = "total balance of ₹5,47,250.75 across 2 account(s)"
        assert numbers_grounded(candidate, facts, {"total_balance": 547250.75}) is ok


# ---------------------------------------------------------------------------------------------------------
# Spending intent and month entity
# ---------------------------------------------------------------------------------------------------------
class TestSpendingAndMonth:
    def test_month_is_validated_and_grounded(self):
        msg = "How much did C1004 spend in October 2026?"
        ok = validate_llm_output(reply(intent="SPENDING_ANALYSIS", customer_id="C1004", month="2026-10"), msg)
        assert ok.month == "2026-10"
        with pytest.raises(LLMValidationError, match="month"):
            validate_llm_output(reply(intent="SPENDING_ANALYSIS", customer_id="C1004", month="2026-09"), msg)
        with pytest.raises(LLMValidationError):
            validate_llm_output(reply(intent="SPENDING_ANALYSIS", customer_id="C1004", month="October"), msg)

    def test_invented_month_rejected(self):
        with pytest.raises(LLMValidationError, match="month"):
            validate_llm_output(reply(intent="SPENDING_ANALYSIS", customer_id="C1004", month="2026-10"),
                                "how much did C1004 spend?")

    def test_llm_mode_spending_end_to_end(self, server, db_path):
        server.classify_reply = reply(intent="SPENDING_ANALYSIS", customer_id="C1002")
        r = llm_supervisor(server, db_path).handle("Where did C1002's money go?")
        assert r.status == "ok" and r.agent == "BankingAgent" and r.trace["intent_source"] == "llm"
        assert r.result_data["spending"]["total_spent"] == pytest.approx(26800.0)
