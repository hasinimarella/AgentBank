"""Banking tools against the real seeded SQLite data."""
import pytest

from database.db import connect
from tools import banking_tools as b


def codes(result):
    return result["error"]["code"]


class TestCustomer:
    def test_valid_customer(self, db_path):
        r = b.get_customer("C1001", db_path=db_path)
        assert r["ok"]
        assert r["data"]["full_name"] == "Aarav Mehta"
        assert r["data"]["home_city"] == "Bengaluru"

    def test_lowercase_and_whitespace_normalised(self, db_path):
        assert b.get_customer("  c1002 ", db_path=db_path)["data"]["customer_id"] == "C1002"

    def test_contact_details_are_masked(self, db_path):
        data = b.get_customer("C1001", db_path=db_path)["data"]
        assert "aarav.mehta" not in data["email"] and data["email"].startswith("a***@")
        assert "90000" not in data["phone"]

    def test_unknown_customer(self, db_path):
        r = b.get_customer("C9999", db_path=db_path)
        assert not r["ok"] and codes(r) == "CUSTOMER_NOT_FOUND"

    @pytest.mark.parametrize("bad", ["", "1001", "C10", "CUST1001", None, 1001, "C1001; DROP TABLE customers"])
    def test_invalid_customer_id(self, db_path, bad):
        r = b.get_customer(bad, db_path=db_path)
        assert not r["ok"] and codes(r) == "INVALID_CUSTOMER_ID"


class TestBalance:
    def test_balance_c1001_sums_both_accounts(self, db_path):
        r = b.get_account_balance("C1001", db_path=db_path)
        assert r["ok"]
        assert len(r["data"]["accounts"]) == 2
        assert r["data"]["total_balance"] == pytest.approx(485250.75 + 62000.00)
        assert r["data"]["currency"] == "INR"

    def test_account_status_reported(self, db_path):
        r = b.get_account_balance("C1005", db_path=db_path)
        assert r["data"]["accounts"][0]["status"] == "DORMANT"

    def test_unknown_customer(self, db_path):
        assert codes(b.get_account_balance("C4242", db_path=db_path)) == "CUSTOMER_NOT_FOUND"

    def test_invalid_id(self, db_path):
        assert codes(b.get_account_balance("nope", db_path=db_path)) == "INVALID_CUSTOMER_ID"


class TestTransactions:
    def test_limit_and_order(self, db_path):
        r = b.get_transactions("C1002", 5, db_path=db_path)
        assert r["ok"] and r["data"]["returned"] == 5 and r["data"]["total_matching"] == 9
        ids = [t["transaction_id"] for t in r["data"]["transactions"]]
        assert ids == ["TXN-9209", "TXN-9208", "TXN-9207", "TXN-9206", "TXN-9205"]  # newest first

    def test_default_limit_is_five(self, db_path):
        assert b.get_transactions("C1002", db_path=db_path)["data"]["returned"] == 5

    def test_limit_larger_than_history(self, db_path):
        assert b.get_transactions("C1003", 50, db_path=db_path)["data"]["returned"] == 4

    @pytest.mark.parametrize("bad", [0, -1, 51, "five", 2.5, True, None])
    def test_invalid_limit(self, db_path, bad):
        assert codes(b.get_transactions("C1002", bad, db_path=db_path)) == "INVALID_LIMIT"

    def test_empty_history_is_success(self, db_path):
        r = b.get_transactions("C1006", 5, db_path=db_path)
        assert r["ok"] and r["data"]["returned"] == 0 and r["data"]["transactions"] == []

    def test_unknown_customer(self, db_path):
        assert codes(b.get_transactions("C9999", 5, db_path=db_path)) == "CUSTOMER_NOT_FOUND"

    def test_status_filter(self, db_path):
        r = b.get_transactions("C1004", 50, status="failed", db_path=db_path)
        assert r["data"]["total_matching"] == 3
        assert {t["status"] for t in r["data"]["transactions"]} == {"FAILED"}

    def test_invalid_status(self, db_path):
        assert codes(b.get_transactions("C1004", 5, status="DROP", db_path=db_path)) == "INVALID_STATUS"

    def test_date_filter(self, db_path):
        r = b.get_transactions("C1002", 50, start_date="2026-09-20", end_date="2026-09-27", db_path=db_path)
        assert [t["transaction_id"] for t in r["data"]["transactions"]] == ["TXN-9208", "TXN-9207"]

    def test_invalid_date(self, db_path):
        assert codes(b.get_transactions("C1002", 5, start_date="20/09/2026", db_path=db_path)) == "INVALID_DATE"

    def test_transaction_id_filter(self, db_path):
        r = b.get_transactions("C1002", 5, transaction_id="TXN-9205", db_path=db_path)
        assert r["data"]["returned"] == 1 and r["data"]["transactions"][0]["merchant"] == "Personal Loan EMI"

    def test_transaction_id_filter_other_customers_txn_returns_nothing(self, db_path):
        assert b.get_transactions("C1002", 5, transaction_id="TXN-9003", db_path=db_path)["data"]["returned"] == 0

    def test_sql_injection_attempts_are_inert(self, db_path):
        assert codes(b.get_transactions("C1002' OR '1'='1", 5, db_path=db_path)) == "INVALID_CUSTOMER_ID"
        assert codes(b.get_transactions("C1002", 5, status="COMPLETED' OR '1'='1", db_path=db_path)) == "INVALID_STATUS"
        conn = connect(db_path)
        try:
            assert conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0] == 6
        finally:
            conn.close()


class TestSingleTransaction:
    def test_valid(self, db_path):
        r = b.get_transaction("TXN-9003", db_path=db_path)
        assert r["ok"] and r["data"]["amount"] == 185000.0 and r["data"]["country"] == "NG"

    def test_unknown(self, db_path):
        assert codes(b.get_transaction("TXN-0000", db_path=db_path)) == "TRANSACTION_NOT_FOUND"

    @pytest.mark.parametrize("bad", ["9003", "TXN9003", "", None, "TXN-9003' --"])
    def test_invalid(self, db_path, bad):
        assert codes(b.get_transaction(bad, db_path=db_path)) == "INVALID_TRANSACTION_ID"


class TestFinancialSummary:
    def test_c1003_values_come_from_data(self, db_path):
        r = b.get_financial_summary("C1003", db_path=db_path)
        s = r["data"]
        assert r["ok"] and s["full_name"] == "Rohan Das"
        assert s["total_balance"] == pytest.approx(12840.10)
        assert s["activity"]["completed_inflow"] == pytest.approx(45000)
        assert s["activity"]["completed_outflow"] == pytest.approx(22000 + 9000 + 1900)
        assert s["credit_profile"]["credit_score"] == 620
        assert s["credit_profile"]["current_dti"] == pytest.approx(22000 / 45000, abs=1e-4)
        assert s["unavailable"] == []

    def test_no_transactions_is_not_invented(self, db_path):
        s = b.get_financial_summary("C1006", db_path=db_path)["data"]
        assert s["activity"]["transactions_analysed"] == 0
        assert s["activity"]["latest_transaction_at"] is None

    def test_missing_income_reported_not_invented(self, db_path):
        s = b.get_financial_summary("C1005", db_path=db_path)["data"]
        assert s["credit_profile"]["monthly_income"] is None
        assert any("income" in u for u in s["unavailable"])

    def test_unknown_customer(self, db_path):
        assert codes(b.get_financial_summary("C9999", db_path=db_path)) == "CUSTOMER_NOT_FOUND"

    def test_partial_inputs_stay_missing(self):
        cust = {"customer_id": "C1001", "full_name": "X", "kyc_status": "VERIFIED",
                "customer_since": "2020-01-01", "home_city": "Y"}
        s = b.compute_financial_summary(cust, None, None, None)["data"]
        assert set(s["unavailable"]) == {"balances", "transaction activity", "credit profile"}
        assert "total_balance" not in s


def test_tools_are_read_only(fresh_db):
    def counts():
        conn = connect(fresh_db)
        try:
            return [conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("customers", "accounts", "transactions")]
        finally:
            conn.close()

    before = counts()
    b.get_customer("C1001", db_path=fresh_db)
    b.get_account_balance("C1001", db_path=fresh_db)
    b.get_transactions("C1001", 5, db_path=fresh_db)
    b.get_financial_summary("C1001", db_path=fresh_db)
    assert counts() == before
