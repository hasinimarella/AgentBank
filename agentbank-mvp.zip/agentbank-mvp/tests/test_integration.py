"""End-to-end: the five mandatory use cases (plus extras) through Supervisor -> agent -> tools -> data,
and through the real Streamlit UI (headless AppTest)."""
import re
import sqlite3
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from data.seed_data import seed_database
from database.db import connect

ROOT = Path(__file__).resolve().parent.parent


# ---- the five mandatory use cases through the Supervisor ----------------------------------------------------
def test_use_case_1_account_balance(supervisor):
    r = supervisor.handle("What is the account balance for customer C1001?")
    assert (r.status, r.intent, r.agent) == ("ok", "ACCOUNT_BALANCE", "BankingAgent")
    assert r.entities == {"customer_id": "C1001"}
    assert "C1001" in r.message and "₹5,47,250.75" in r.message
    assert r.result_data["balance"]["total_balance"] == pytest.approx(547250.75)
    assert [c["tool"] for c in r.trace["tool_calls"]] == ["get_customer", "get_account_balance"]


def test_use_case_2_transaction_history(supervisor):
    r = supervisor.handle("Show the last five transactions for customer C1002.")
    assert (r.status, r.intent, r.agent) == ("ok", "TRANSACTION_HISTORY", "BankingAgent")
    assert r.entities == {"customer_id": "C1002", "limit": 5}
    txns = r.result_data["history"]["transactions"]
    assert [t["transaction_id"] for t in txns] == ["TXN-9209", "TXN-9208", "TXN-9207", "TXN-9206", "TXN-9205"]
    assert {"occurred_at", "amount", "merchant", "category"} <= set(txns[0])
    assert "Harbour Restaurant" in r.message and "Fuel Point" in r.message


def test_use_case_3_fraud_assessment(supervisor):
    r = supervisor.handle("Check transaction TXN-9003 for fraud risk.")
    assert (r.status, r.intent, r.agent) == ("ok", "FRAUD_ASSESSMENT", "FraudAgent")
    a = r.result_data["assessment"]
    assert (a["risk_score"], a["risk_level"], a["recommended_action"]) == (95, "HIGH", "ESCALATE")
    assert r.result_data["transaction"]["merchant"] == "GlobalCoin Exchange"
    assert len(a["contributing_indicators"]) == 6
    assert "GlobalCoin Exchange" in r.message and "not a confirmed" in r.message.lower()


def test_use_case_4_loan_eligibility(supervisor):
    r = supervisor.handle("Is customer C1001 eligible for a loan of ₹200000?")
    assert (r.status, r.intent, r.agent) == ("ok", "LOAN_ELIGIBILITY", "LoanAgent")
    a = r.result_data["assessment"]
    assert a["decision"] == "ELIGIBLE" and a["requested_amount"] == 200000
    assert a["financial_profile"]["monthly_income"] == 120000 and a["financial_profile"]["credit_score"] == 790
    assert a["estimated_monthly_payment"] == pytest.approx(6547.74, abs=0.01)
    assert "illustrative" in r.message.lower() and "not a real lending decision" in r.message.lower()


def test_use_case_5_financial_summary(supervisor):
    r = supervisor.handle("Give me a complete financial summary for customer C1003.")
    assert (r.status, r.intent, r.agent) == ("ok", "CUSTOMER_FINANCIAL_SUMMARY", "BankingAgent")
    s = r.result_data["summary"]
    assert s["full_name"] == "Rohan Das" and s["total_balance"] == pytest.approx(12840.10)
    assert [t["transaction_id"] for t in s["recent_transactions"]] == ["TXN-9304", "TXN-9303", "TXN-9302", "TXN-9301"]
    assert s["credit_profile"]["credit_score"] == 620
    assert [c["tool"] for c in r.trace["tool_calls"]] == [
        "get_customer", "get_account_balance", "get_transactions", "get_loan_profile", "compute_financial_summary"]


# ---- extra scenarios ----------------------------------------------------------------------------------------------
def test_extra_monthly_spending_analysis(supervisor):
    r = supervisor.handle("Show the monthly spending analysis for customer C1002.")
    s = r.result_data["spending"]
    assert (r.status, r.intent, r.agent) == ("ok", "SPENDING_ANALYSIS", "BankingAgent")
    assert s["month"] == "2026-09" and s["total_spent"] == pytest.approx(26800.0)  # completed debits only
    assert s["by_category"][0]["category"] == "LOAN_EMI"
    assert sum(c["amount"] for c in s["by_category"]) == pytest.approx(s["total_spent"])
    assert [c["tool"] for c in r.trace["tool_calls"]] == ["get_customer", "get_spending_analysis"]


def test_extra_spending_for_requested_month_and_bad_month(supervisor, db_path):
    r = supervisor.handle("How much did C1004 spend in October 2026?")
    assert r.entities["month"] == "2026-10" and r.result_data["spending"]["total_spent"] == pytest.approx(209000)
    from tools.banking_tools import get_spending_analysis
    assert get_spending_analysis("C1004", month="2026-13", db_path=db_path)["error"]["code"] == "INVALID_MONTH"
    assert get_spending_analysis("C9999", db_path=db_path)["error"]["code"] == "CUSTOMER_NOT_FOUND"
    assert get_spending_analysis("C1006", db_path=db_path)["data"]["total_spent"] == 0


def test_extra_missing_customer_clarification_flow(supervisor):
    r = supervisor.handle("Show my recent transactions")
    assert r.status == "clarification" and "customer ID" in r.message and r.trace["tool_calls"] == []
    follow = supervisor.handle("Show my recent transactions for C1002")
    assert follow.status == "ok" and follow.entities["customer_id"] == "C1002"


# ---- seeded data is reproducible -----------------------------------------------------------------------------------
def dump(path):
    conn = sqlite3.connect(path)
    try:
        return {t: conn.execute(f"SELECT * FROM {t} ORDER BY 1").fetchall()
                for t in ("customers", "accounts", "transactions")}
    finally:
        conn.close()


def test_seed_data_is_deterministic(tmp_path):
    a = seed_database(str(tmp_path / "a.db"))
    b = seed_database(str(tmp_path / "b.db"))
    assert dump(a) == dump(b)


def test_seed_is_idempotent_and_reset_rebuilds(tmp_path):
    p = seed_database(str(tmp_path / "x.db"))
    before = dump(p)
    seed_database(p)
    assert dump(p) == before
    conn = connect(p)
    conn.execute("DELETE FROM transactions WHERE transaction_id = 'TXN-9003'")
    conn.commit()
    conn.close()
    seed_database(p, reset=True)
    assert dump(p) == before


def test_seed_meets_assignment_minimums(db_path):
    d = dump(db_path)
    assert len(d["customers"]) >= 5
    per_customer = {}
    for row in d["transactions"]:
        per_customer[row[1]] = per_customer.get(row[1], 0) + 1
    assert sum(1 for n in per_customer.values() if n >= 2) >= 5


# ---- the real Streamlit UI (headless) --------------------------------------------------------------------------------
@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("AGENTBANK_DB_PATH", str(tmp_path / "ui.db"))
    monkeypatch.setenv("LLM_PROVIDER", "fallback")
    import streamlit as st
    st.cache_resource.clear()
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception
    return at


def click(at, label):
    next(b for b in at.sidebar.button if b.label == label).click()
    at.run()
    assert not at.exception, [e.value for e in at.exception]
    return at.session_state.messages[-1]["response"]


def test_ui_shows_mode_and_synthetic_notice(app):
    assert any("Fallback mode" in w.value for w in app.sidebar.warning)
    assert any("synthetic" in w.value.lower() for w in app.warning)


@pytest.mark.parametrize("label,intent,agent", [
    ("1 · Account balance", "ACCOUNT_BALANCE", "BankingAgent"),
    ("2 · Transaction history", "TRANSACTION_HISTORY", "BankingAgent"),
    ("3 · Fraud-risk check", "FRAUD_ASSESSMENT", "FraudAgent"),
    ("4 · Loan eligibility", "LOAN_ELIGIBILITY", "LoanAgent"),
    ("5 · Financial summary", "CUSTOMER_FINANCIAL_SUMMARY", "BankingAgent"),
])
def test_ui_five_mandatory_examples_work(app, label, intent, agent):
    resp = click(app, label)
    assert resp["status"] == "ok" and resp["intent"] == intent and resp["agent"] == agent
    assert resp["trace"]["tool_calls"] and all(c["status"] == "success" for c in resp["trace"]["tool_calls"])
    assert any("Execution trace" in e.label for e in app.expander)


def test_ui_typed_prompt_reset_and_extras(app):
    app.chat_input[0].set_value("What is the account balance for customer C1001?").run()
    assert not app.exception and app.session_state.messages[-1]["response"]["status"] == "ok"
    app.chat_input[0].set_value("Transfer 5000 to C1002").run()
    assert app.session_state.messages[-1]["response"]["status"] == "unsupported"
    next(b for b in app.sidebar.button if "Reset" in b.label).click()
    app.run()
    assert app.session_state.messages == []
    for label in ("Monthly spending", "Missing customer ID", "Unknown customer", "Unsupported action",
                  "Empty history", "Medium-risk txn", "Loan needs review", "Missing income data", "Needs clarification"):
        # "More scenarios" buttons live in an expander inside the sidebar
        btn = next(b for b in app.sidebar.button if b.label == label)
        btn.click()
        app.run()
        assert not app.exception, label


def test_ui_example_prompts_all_resolve_against_seed_data(app):
    expected = {"Monthly spending": "ok", "Missing customer ID": "clarification", "Empty history": "ok",
                "Medium-risk txn": "ok", "Loan needs review": "ok", "Missing income data": "ok",
                "Needs clarification": "clarification", "Unknown customer": "not_found", "Unsupported action": "unsupported"}
    for label, status in expected.items():
        assert click(app, label)["status"] == status, label
    msgs = [m["response"] for m in app.session_state.messages if m["role"] == "assistant"]
    by_label = dict(zip(expected, msgs))
    assert by_label["Loan needs review"]["result_data"]["assessment"]["decision"] == "REFER_TO_REVIEW"
    assert by_label["Missing income data"]["result_data"]["assessment"]["decision"] == "INSUFFICIENT_DATA"
    assert by_label["Medium-risk txn"]["result_data"]["assessment"]["risk_level"] == "MEDIUM"


# ---- packaging sanity ------------------------------------------------------------------------------------------------------
def test_required_project_files_exist():
    for name in ("app.py", "requirements.txt", "README.md", "ARCHITECTURE.md", "DEMO_SCRIPT.md", ".gitignore",
                 ".env.example", "start.bat", "LICENSE", "docs/architecture_notes.md", "docs/design_decisions.md",
                 "docs/demo_checklist.md"):
        assert (ROOT / name).is_file(), name


def test_requirements_are_pinned_and_free_of_llm_vendor_sdks():
    lines = [l.strip() for l in (ROOT / "requirements.txt").read_text().splitlines() if l.strip() and not l.startswith("#")]
    assert lines and all(re.match(r"^[A-Za-z0-9_.-]+==\d", l) for l in lines)
    joined = " ".join(lines).lower()
    for banned in ("anthropic", "openai", "langchain", "torch", "transformers"):
        assert banned not in joined


def test_no_hardcoded_secrets_or_absolute_paths():
    pattern = re.compile(r"(sk-[A-Za-z0-9]{16,}|api[_-]?key\s*=\s*['\"][^'\"]+['\"]|/home/claude|C:\\\\Users)")
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix in {".py", ".md", ".bat", ".example", ".txt", ".sql"} and ".venv" not in path.parts \
                and "tests" not in path.parts:
            assert not pattern.search(path.read_text(encoding="utf-8", errors="ignore")), path
