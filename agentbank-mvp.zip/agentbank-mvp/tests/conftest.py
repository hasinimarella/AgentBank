import dataclasses

import pytest

from agents.supervisor import Supervisor
from config.settings import LLMConfig, get_settings
from data.seed_data import seed_database
from llm.factory import fallback_selection


@pytest.fixture(autouse=True)
def _no_real_llm(monkeypatch):
    """Tests never contact a real LLM unless they explicitly build a provider."""
    monkeypatch.setenv("LLM_PROVIDER", "fallback")


@pytest.fixture(scope="session")
def db_path(tmp_path_factory):
    path = tmp_path_factory.mktemp("agentbank") / "test.db"
    seed_database(str(path))
    return str(path)


@pytest.fixture
def fresh_db(tmp_path):
    """A private, freshly seeded database for tests that write."""
    path = tmp_path / "fresh.db"
    seed_database(str(path))
    return str(path)


@pytest.fixture
def supervisor(db_path):
    return Supervisor(db_path=db_path, selection=fallback_selection())


def settings_with_llm(**llm_kwargs):
    return dataclasses.replace(get_settings(), llm=LLMConfig(**llm_kwargs))
