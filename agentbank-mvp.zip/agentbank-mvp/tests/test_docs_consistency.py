"""Documentation must match the code and the seeded data."""
import re
from pathlib import Path

import pytest

from database.db import connect

ROOT = Path(__file__).resolve().parent.parent
DOCS = ["README.md", "ARCHITECTURE.md", "DEMO_SCRIPT.md", "docs/architecture_notes.md",
        "docs/design_decisions.md", "docs/demo_checklist.md"]
INTENTIONALLY_MISSING = {"C9999", "TXN-0000"}  # used to demonstrate unknown-ID handling


def text(name):
    return (ROOT / name).read_text(encoding="utf-8")


def test_every_id_in_docs_exists_in_seed_data(db_path):
    conn = connect(db_path)
    try:
        customers = {r[0] for r in conn.execute("SELECT customer_id FROM customers")}
        txns = {r[0] for r in conn.execute("SELECT transaction_id FROM transactions")}
    finally:
        conn.close()
    for name in DOCS:
        body = text(name)
        for cid in set(re.findall(r"\bC\d{4}\b", body)) - INTENTIONALLY_MISSING:
            assert cid in customers, f"{name}: {cid}"
        for tid in set(re.findall(r"\bTXN-\d{4}\b", body)) - INTENTIONALLY_MISSING:
            assert tid in txns, f"{name}: {tid}"


def demo_prompts():
    body = text("DEMO_SCRIPT.md")
    out = []
    for kind, prompt in re.findall(r"\*\*Type(?: \((clarification|unsupported)\))?:\*\*\s*`([^`]+)`", body):
        out.append((kind or "ok", prompt))
    return out


def test_demo_script_has_all_required_sections():
    body = text("DEMO_SCRIPT.md").lower()
    for needle in ("introduction", "architecture", "balance", "transaction history", "fraud", "loan",
                   "financial summary", "trace", "tests", "limitations", "closing"):
        assert needle in body, needle
    assert len(demo_prompts()) >= 9


@pytest.mark.parametrize("kind,prompt", demo_prompts())
def test_demo_prompts_behave_as_documented(supervisor, kind, prompt):
    expected = {"ok": "ok", "clarification": "clarification", "unsupported": "unsupported"}[kind]
    assert supervisor.handle(prompt).status == expected


def test_readme_prompt_table_runs(supervisor):
    body = text("README.md")
    prompts = re.findall(r"^\| \d \| `([^`]+)` \|", body, flags=re.MULTILINE)
    assert len(prompts) == 8
    statuses = [supervisor.handle(p).status for p in prompts]
    assert statuses == ["ok"] * 6 + ["clarification", "unsupported"]
    more = re.search(r"^More: (.+)$", body, flags=re.MULTILINE).group(1)
    for p in re.findall(r"`([^`]+\?|[^`]+\.)`", more):
        assert supervisor.handle(p).status == "ok", p


def test_documented_facts_match_tool_output(supervisor):
    r = supervisor.handle("Is customer C1003 eligible for a loan of ₹200000?")
    a = r.result_data["assessment"]
    assert a["decision"] == "NOT_ELIGIBLE" and round(a["dti_after_loan"], 2) == 0.63 and a["financial_profile"]["credit_score"] == 620
    loan = supervisor.handle("Is customer C1001 eligible for a loan of ₹200000?").result_data["assessment"]
    assert f"{loan['dti_before_loan']:.1%}" == "12.5%" and f"{loan['dti_after_loan']:.1%}" == "18.0%"
    assert supervisor.handle("Can customer C1002 borrow ₹6 lakh?").result_data["assessment"]["decision"] == "REFER_TO_REVIEW"
    fraud = supervisor.handle("Is TXN-9003 suspicious?").result_data["assessment"]
    ind = {i["indicator"]: i["points"] for i in fraud["contributing_indicators"]}
    assert ind == {"unusual_amount": 25, "high_absolute_amount": 15, "velocity": 20,
                   "unusual_location": 20, "odd_hours": 5, "risky_merchant_category": 10}


def test_documented_weights_and_thresholds_match_code():
    from config.settings import LoanConfig, RiskConfig
    from tools.fraud_tools import RISKY_CATEGORIES, WEIGHTS
    readme = text("README.md")
    for name, pts in WEIGHTS.items():
        assert f"{name} ({pts})" in readme, name
    for cat in RISKY_CATEGORIES:
        assert cat in readme
    r, l = RiskConfig(), LoanConfig()
    assert (r.medium, r.high) == (30, 60)
    assert (l.min_credit_score, l.refer_credit_score, l.max_dti, l.refer_dti) == (650, 600, 0.40, 0.50)
    assert (l.assumed_annual_rate, l.assumed_tenure_months, l.max_multiple_of_annual_income) == (0.11, 36, 2.0)


def test_env_example_documents_every_setting():
    env = text(".env.example")
    for key in ("LLM_PROVIDER", "OLLAMA_BASE_URL", "OLLAMA_MODEL", "AGENTBANK_DB_PATH", "RISK_THRESHOLD_MEDIUM",
                "RISK_THRESHOLD_HIGH", "LOAN_MAX_DTI", "LOAN_MIN_CREDIT_SCORE", "LLM_FORMULATE_RESPONSES"):
        assert key + "=" in env
    assert "OPENAI_COMPAT_API_KEY=" in env
    assert not re.search(r"API_KEY=\S", env)  # the key is present but blank: no credentials in the example


def test_files_referenced_in_readme_exist():
    body = text("README.md")
    for rel in re.findall(r"\]\(([^)#]+\.md)\)", body):
        assert (ROOT / rel).is_file(), rel
    for rel in ("start.bat", "start.sh", "tests/fake_llm_server.py", "data/seed_data.py", "llm/fallback_provider.py"):
        assert (ROOT / rel).is_file(), rel


def test_start_bat_has_the_required_steps():
    bat = (ROOT / "start.bat").read_bytes().decode("ascii")
    assert "\r\n" in bat  # Windows line endings
    lowered = bat.lower()
    for needle in ("version_info >= (3,11)", "venv", "activate.bat", "pip install", "-r requirements.txt",
                   "streamlit run app.py", "data.seed_data"):
        assert needle.lower() in lowered, needle
