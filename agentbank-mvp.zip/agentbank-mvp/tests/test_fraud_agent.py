"""Rule-based fraud engine and the FraudAgent workflow."""
import pytest

from config.settings import RiskConfig
from database.db import connect
from tools import fraud_tools as f
from tools.fraud_tools import WEIGHTS, RuleBasedRiskEngine, calculate_fraud_risk, categorize


def triggered(result):
    return {i["indicator"] for i in result["data"]["contributing_indicators"]}


class TestScoring:
    def test_weights_sum_to_100(self):
        assert sum(WEIGHTS.values()) == 100

    def test_every_seeded_transaction_scores_within_range(self, db_path):
        conn = connect(db_path)
        try:
            ids = [r[0] for r in conn.execute("SELECT transaction_id FROM transactions")]
        finally:
            conn.close()
        assert len(ids) >= 25
        for tid in ids:
            r = calculate_fraud_risk(tid, db_path=db_path)
            assert r["ok"], tid
            assert 0 <= r["data"]["risk_score"] <= 100
            assert r["data"]["risk_level"] in {"LOW", "MEDIUM", "HIGH"}

    @pytest.mark.parametrize("score,level", [
        (0, "LOW"), (29, "LOW"), (30, "MEDIUM"), (59, "MEDIUM"),
        (60, "HIGH"), (79, "HIGH"), (80, "HIGH"), (100, "HIGH")])
    def test_category_boundaries_default_config(self, score, level):
        assert categorize(score, RiskConfig()) == level

    def test_category_boundaries_are_configurable(self):
        cfg = RiskConfig(medium=10, high=20)
        assert categorize(9, cfg) == "LOW" and categorize(10, cfg) == "MEDIUM"
        assert categorize(19, cfg) == "MEDIUM" and categorize(20, cfg) == "HIGH"

    def test_configured_thresholds_change_the_result(self, db_path):
        default = calculate_fraud_risk("TXN-9004", db_path=db_path)["data"]
        strict = calculate_fraud_risk("TXN-9004", db_path=db_path, config=RiskConfig(10, 20))["data"]
        assert default["risk_level"] == "MEDIUM" and strict["risk_level"] == "HIGH"
        assert default["risk_score"] == strict["risk_score"]


class TestSeededScenarios:
    def test_txn_9003_is_high_with_expected_signals(self, db_path):
        r = calculate_fraud_risk("TXN-9003", db_path=db_path)
        d = r["data"]
        assert d["risk_score"] == 95 and d["risk_level"] == "HIGH" and d["recommended_action"] == "ESCALATE"
        assert triggered(r) == {"unusual_amount", "high_absolute_amount", "velocity",
                                "unusual_location", "odd_hours", "risky_merchant_category"}
        assert d["classification"] == "SUSPICIOUS"

    def test_txn_9004_is_medium(self, db_path):
        r = calculate_fraud_risk("TXN-9004", db_path=db_path)
        assert r["data"]["risk_level"] == "MEDIUM" and r["data"]["recommended_action"] == "REVIEW"
        assert triggered(r) == {"unusual_amount", "unusual_location", "odd_hours", "risky_merchant_category"}

    def test_txn_9010_failed_foreign_attempt_is_high(self, db_path):
        r = calculate_fraud_risk("TXN-9010", db_path=db_path)
        assert r["data"]["risk_level"] == "HIGH" and "transaction_status" in triggered(r)

    @pytest.mark.parametrize("tid", ["TXN-9102", "TXN-9001", "TXN-9201", "TXN-9501"])
    def test_normal_transactions_are_low(self, db_path, tid):
        r = calculate_fraud_risk(tid, db_path=db_path)
        assert r["data"]["risk_level"] == "LOW" and r["data"]["recommended_action"] == "ALLOW"

    def test_no_history_does_not_crash(self, db_path):
        r = calculate_fraud_risk("TXN-9101", db_path=db_path)  # first transaction of C1001
        assert r["ok"]
        by = {i["indicator"]: i for i in r["data"]["all_indicators"]}
        assert "No prior debit history" in by["unusual_amount"]["reason"]


class TestExplainability:
    def test_every_indicator_has_reason_and_points(self, db_path):
        d = calculate_fraud_risk("TXN-9003", db_path=db_path)["data"]
        assert len(d["all_indicators"]) == len(WEIGHTS)
        for i in d["all_indicators"]:
            assert i["reason"] and 0 <= i["points"] <= i["max_points"]
        assert sum(i["points"] for i in d["all_indicators"]) == d["risk_score"]

    def test_recommendations_and_disclaimer(self, db_path):
        d = calculate_fraud_risk("TXN-9003", db_path=db_path)["data"]
        assert d["recommendations"]
        assert d["confirmed_fraud"] is False
        assert "not a confirmed fraudulent" in d["disclaimer"].lower() or "not a confirmed" in d["disclaimer"].lower()
        assert "no account was frozen" in d["disclaimer"].lower()

    def test_engine_is_labelled_rule_based_not_ml(self, db_path):
        d = calculate_fraud_risk("TXN-9003", db_path=db_path)["data"]
        assert "rule-based" in d["engine"]["kind"] and "not machine learning" in d["engine"]["kind"]

    def test_scorer_is_pluggable(self, db_path):
        class FixedModel:
            name, kind = "stub-model", "test stub"

            def score(self, txn, context):
                return {"score": 77, "indicators": []}

        d = calculate_fraud_risk("TXN-9102", db_path=db_path, scorer=FixedModel())["data"]
        assert d["risk_score"] == 77 and d["risk_level"] == "HIGH" and d["engine"]["name"] == "stub-model"


class TestErrorsAndSafety:
    def test_unknown_transaction(self, db_path):
        assert calculate_fraud_risk("TXN-0000", db_path=db_path)["error"]["code"] == "TRANSACTION_NOT_FOUND"

    @pytest.mark.parametrize("bad", ["", "9003", None, "TXN-9003; DROP TABLE transactions"])
    def test_invalid_id(self, db_path, bad):
        assert calculate_fraud_risk(bad, db_path=db_path)["error"]["code"] == "INVALID_TRANSACTION_ID"

    def test_assessment_has_no_side_effects(self, fresh_db):
        calculate_fraud_risk("TXN-9003", db_path=fresh_db)
        conn = connect(fresh_db)
        try:
            assert conn.execute("SELECT status FROM accounts WHERE customer_id='C1004'").fetchone()[0] == "ACTIVE"
            assert conn.execute("SELECT status FROM transactions WHERE transaction_id='TXN-9003'").fetchone()[0] == "COMPLETED"
        finally:
            conn.close()

    def test_engine_class_is_exposed_for_replacement(self):
        assert RuleBasedRiskEngine(RiskConfig()).name == "weighted-rules-v1"
        assert f.RISKY_CATEGORIES


class TestFraudAgentWorkflow:
    def test_routes_to_fraud_agent_and_calls_both_tools(self, supervisor):
        r = supervisor.handle("Check transaction TXN-9003 for fraud risk.")
        assert r.status == "ok" and r.agent == "FraudAgent" and r.intent == "FRAUD_ASSESSMENT"
        assert [(c["tool"], c["status"]) for c in r.trace["tool_calls"]] == [
            ("get_transaction", "success"), ("calculate_fraud_risk", "success")]
        assert "95/100" in r.message and "HIGH" in r.message and "ESCALATE" in r.message
        assert "suspicious" in r.message.lower() and "not a confirmed" in r.message.lower()

    def test_unknown_transaction_via_supervisor(self, supervisor):
        r = supervisor.handle("Check TXN-0000 for fraud")
        assert r.status == "not_found" and r.agent == "FraudAgent"
        assert [c["tool"] for c in r.trace["tool_calls"]] == ["get_transaction"]  # stops early


def test_assignment_style_alias_names_exist(db_path):
    from tools import banking_tools, fraud_tools, loan_tools
    assert fraud_tools.assess_transaction_risk("TXN-9003", db_path=db_path)["data"]["risk_score"] == 95
    assert loan_tools.evaluate_loan_eligibility("C1001", 200000, db_path=db_path)["data"]["decision"] == "ELIGIBLE"
    assert banking_tools.get_customer_financial_summary("C1003", db_path=db_path)["ok"]
