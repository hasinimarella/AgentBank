"""A tiny local HTTP server that speaks just enough of the Ollama and OpenAI-compatible APIs.

It lets the tests exercise the REAL provider HTTP code (requests, timeouts, status codes,
JSON parsing, validation) without needing a model. The *model replies are scripted by each
test*, so these tests prove the plumbing, validation and fallback behaviour; they do not
prove the quality of any real model's classification.
"""
from __future__ import annotations

import json
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeLLMServer:
    def __init__(self):
        self.models = ["llama3.2:3b"]
        self.classify_reply = "{}"        # content for JSON-mode (classification) calls
        self.text_reply = "OK"            # content for free-text (formulation) calls
        self.http_status = 200            # status for POST calls
        self.delay = 0.0                  # seconds to sleep before answering POST
        self.api_key_required: str | None = None
        self.requests: list[dict] = []    # every request received
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # silence
                pass

            def _send(self, status: int, body: dict):
                raw = json.dumps(body).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def _auth_ok(self) -> bool:
                if outer.api_key_required is None:
                    return True
                return self.headers.get("Authorization") == f"Bearer {outer.api_key_required}"

            def do_GET(self):
                outer.requests.append({"method": "GET", "path": self.path})
                if self.path == "/api/tags":
                    return self._send(200, {"models": [{"name": m} for m in outer.models]})
                if self.path == "/v1/models":
                    if not self._auth_ok():
                        return self._send(401, {"error": "bad key"})
                    return self._send(200, {"data": [{"id": m} for m in outer.models]})
                self._send(404, {"error": "not found"})

            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                payload = json.loads(self.rfile.read(length) or b"{}")
                outer.requests.append({"method": "POST", "path": self.path, "payload": payload,
                                       "auth": self.headers.get("Authorization")})
                if outer.delay:
                    time.sleep(outer.delay)
                if outer.http_status != 200:
                    return self._send(outer.http_status, {"error": "scripted failure"})
                if self.path == "/v1/chat/completions" and not self._auth_ok():
                    return self._send(401, {"error": "bad key"})
                json_mode = payload.get("format") == "json" or "JSON object" in json.dumps(payload.get("messages", []))
                content = outer.classify_reply if json_mode else outer.text_reply
                if self.path == "/api/chat":
                    return self._send(200, {"message": {"role": "assistant", "content": content}})
                if self.path == "/v1/chat/completions":
                    return self._send(200, {"choices": [{"message": {"role": "assistant", "content": content}}]})
                self._send(404, {"error": "not found"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self) -> "FakeLLMServer":
        self.thread.start()
        return self

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.httpd.server_address[1]}"

    @property
    def chat_calls(self) -> int:
        return sum(1 for r in self.requests if r["method"] == "POST")


def closed_port_url() -> str:
    """A URL on which nothing is listening."""
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return f"http://127.0.0.1:{port}"
