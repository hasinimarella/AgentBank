# Pre-recording Checklist

## Environment
- [ ] Python 3.11+ available (`python --version`)
- [ ] `start.bat` (or the manual commands in the README) runs without errors
- [ ] http://localhost:8501 opens; sidebar shows the AI mode badge (Fallback is fine)
- [ ] `python -m pytest` passes in a second terminal
- [ ] Browser zoom ~100%, window wide enough that the sidebar and chat are both visible; notifications off

## Data sanity (click **Reset conversation** first)
- [ ] `What is the account balance for customer C1001?` → ₹5,47,250.75, trace shows `get_customer` → `get_account_balance`
- [ ] `Show the last five transactions for customer C1002.` → TXN-9209 … TXN-9205
- [ ] `Check transaction TXN-9003 for fraud risk.` → 95/100, HIGH, ESCALATE
- [ ] `Is TXN-9004 suspicious?` → MEDIUM 41, REVIEW
- [ ] `Is customer C1001 eligible for a loan of ₹200000?` → ELIGIBLE (illustrative)
- [ ] `Is customer C1003 eligible for a loan of ₹200000?` → NOT ELIGIBLE
- [ ] `Give me a complete financial summary for customer C1003.` → five tool calls in the trace
- [ ] `Show the monthly spending analysis for customer C1002.` → ₹26,800.00 for 2026-09 with chart
- [ ] `Show my recent transactions` → clarification; `Transfer ₹5000 from C1001 to C1002` → refused

## UI
- [ ] Every example button in the sidebar works; **Reset conversation** clears the chat
- [ ] Execution trace expands; Steps / Tool calls / Raw JSON tabs show data
- [ ] Architecture tab diagram renders (needs a browser; no extra install)
- [ ] "Simulated data" notice is visible

## Optional LLM mode
- [ ] If demonstrating it: Ollama running, `ollama pull llama3.2:3b` done, sidebar shows **LLM mode**; otherwise say clearly that fallback mode is active

## Say honestly
- [ ] Rule-based classifier, fraud and loan engines are not machine learning
- [ ] All data is synthetic; nothing connects to a real bank; not production software
