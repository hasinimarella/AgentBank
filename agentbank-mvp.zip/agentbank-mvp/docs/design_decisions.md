# Design Decisions

| Decision | Why | Alternatives considered |
|---|---|---|
| **Rule-based NLU as the base, LLM optional** | Must run offline with no key or download; deterministic and testable; honest about limits. | LLM-only (needs a model/key, non-deterministic); training a classifier (no labelled data, would overstate the project). |
| **Validate and ground LLM output** | Model text is untrusted input; hallucinated IDs/amounts must never reach a tool. | Trusting model JSON; letting the model call tools directly (unsafe). |
| **Supervisor + router table + agent classes** | Clear responsibilities, easy to explain and test; routing is auditable. | One function with keyword `if`s (not multi-agent); LLM-planned agent graphs (unpredictable, heavy). |
| **`AgentToolbox` with per-agent allow-lists** | Enforces least privilege and gives one place for timing, error containment and tracing. | Agents importing tools directly (no boundary, no trace). |
| **Tool envelope `{"ok", "data"/"error"}`** | Expected failures (unknown ID, bad amount) need no exceptions; uniform handling. | Raising exceptions for everything. |
| **SQLite, seeded from Python** | Standard library, parameterised queries, constraints, deterministic, reset with one command. | JSON files (no constraints/queries); external DB (needless setup). |
| **Trace built by running code** | The assignment requires a real trace; tests assert it. | Reconstructing a pretty log after the fact (fabrication risk). |
| **Weighted-rule fraud score, median baseline** | Explainable by construction; the median stops one earlier outlier from hiding a later one; `RiskScorer` protocol allows a future model. | Trained model (no labelled data); z-scores (small samples). |
| **Three risk levels with ALLOW/REVIEW/ESCALATE** | Matches the assignment and maps to operational actions; the simulator never acts. | More granular levels (false precision). |
| **Illustrative loan engine with EMI + DTI** | Familiar affordability maths; `INSUFFICIENT_DATA` instead of guessing; configurable thresholds. | Credit-score-only (too thin); ML scorecard (no data). |
| **Financial summary as composite of traced tool calls** | Shows coordinated execution and graceful partial results. | One monolithic summary query (hides the orchestration). |
| **Streamlit-native UI and charts** | Minimal dependencies, beginner friendly. | Plotly (extra dependency with little gain), custom front end. |
| **Tests over real seeded data; scripted local HTTP server for LLM plumbing** | Avoids tests that pass only because everything is mocked; the server exercises the real HTTP/validation code. | Mocking provider methods (would skip the interesting code). |
| **Pinned versions, `start.bat` + `start.sh`** | Reproducible beginner-friendly setup on Windows and Unix. | Docker (heavier, not requested). |

## Bugs found and fixed while building (kept as regression tests)
- An LLM-supplied loan amount slipped through the grounding check because the digits inside `C1001` counted as "the user typed a number". IDs are now stripped before that check.
- `compute_financial_summary` returned a bare dict instead of the standard envelope; the executor correctly flagged it as malformed.
- "customers 1001" could be misread as a rupee amount ("rs 1001"); the amount pattern now requires a word boundary before the currency marker.
- Out-of-range values from the rule classifier (`last 100 transactions`, `loan of 0`) could fail schema validation; they are now clamped or dropped so the supervisor asks again.
