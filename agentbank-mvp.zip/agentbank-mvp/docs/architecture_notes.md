# Architecture Notes

Companion to [ARCHITECTURE.md](../ARCHITECTURE.md): where each assignment concept lives in the code.

| Assignment concept | Module(s) |
|---|---|
| Streamlit chat interface | `app.py` |
| Supervisor / Orchestrator | `agents/supervisor.py` |
| Natural-language intent classification | `llm/fallback_provider.py` (rules); `llm/ollama_provider.py` (optional LLM) |
| Entity extraction and validation | `llm/entities.py`, `llm/base.py` (`IntentResult` schema, grounding), `services/router.py` (required entities) |
| Agent selection and routing | `services/router.py` (`AgentRouter`) |
| Customer / Banking Agent | `agents/banking_agent.py` |
| Risk / Fraud Agent | `agents/fraud_agent.py` + `tools/fraud_tools.py` |
| Credit / Loan Agent | `agents/loan_agent.py` + `tools/loan_tools.py` |
| Tool invocation and aggregation | `services/tool_executor.py`, `agents/*`, `services/response_builder.py` |
| Execution trace and error handling | `services/audit_service.py`, `services/tool_executor.py`, `agents/supervisor.py` |
| Simulated banking service layer | `tools/banking_tools.py`, `tools/fraud_tools.py`, `tools/loan_tools.py` |
| Synthetic dataset | `data/seed_data.py` → SQLite (`database/schema.sql`) |

## Differences from the suggested folder layout
The assignment suggests `banking/`, `core/` and JSON data files. This project keeps the same separation of concerns under different names
(`tools/` = banking service layer, `llm/` = classifier + entity extractor, `services/` = response formatting, router, trace) and stores the
synthetic data in SQLite generated from `data/seed_data.py` (the assignment allows JSON *or* SQLite). SQLite gives parameterised queries,
constraints and a realistic data layer while staying in the standard library.

## Adding a new capability
1. Add a tool in `tools/` (validate inputs, return the `ok/err` envelope) and register it in `services/tool_executor.py`.
2. Give an agent permission for it in `AGENT_PERMISSIONS` (or create a new agent class and list its intents).
3. Add the intent to `llm/base.py`, a rule in `llm/fallback_provider.py`, required entities in `services/router.py`.
4. Add response text in `services/response_builder.py` and a panel in `app.py`; add tests.

## Optional LLM mode, precisely
`llm/factory.py` asks Ollama which models are installed before claiming LLM mode. Each request sends only the user's message to the model;
the reply must be one JSON object that passes `IntentResult` validation and grounding (IDs must appear in the user's text, amount/limit/month must
agree with deterministic extraction). Any failure falls back to the rules for that request. The model never receives banking data and never selects tools.
