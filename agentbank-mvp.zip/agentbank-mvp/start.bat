@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title AgentBank

echo ============================================================
echo  AgentBank - simulated multi-agent banking (synthetic data)
echo ============================================================

rem ---- 1. Find Python 3.11+ (the "py" launcher first, then "python") ----
set "PYCMD="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYCMD=py -3"
)
if not defined PYCMD (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
        if not errorlevel 1 set "PYCMD=python"
    )
)
if not defined PYCMD (
    echo.
    echo [ERROR] Python 3.11 or newer was not found.
    echo Install it from https://www.python.org/downloads/ and tick
    echo "Add python.exe to PATH" during setup, then run start.bat again.
    echo.
    pause
    exit /b 1
)
echo Using Python command: %PYCMD%

rem ---- 2. Create the virtual environment if it does not exist ----
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment in .venv ...
    %PYCMD% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
)

rem ---- 3. Activate it ----
call ".venv\Scripts\activate.bat"
if errorlevel 1 (
    echo [ERROR] Could not activate the virtual environment.
    pause
    exit /b 1
)

rem ---- 4. Install requirements (quick no-op when already installed) ----
echo Installing requirements - the first run can take a few minutes ...
python -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Installing requirements failed. Check your internet connection and try again.
    pause
    exit /b 1
)

rem ---- 5. Create the synthetic database ----
python -m data.seed_data
if errorlevel 1 (
    echo [ERROR] Could not create the synthetic database.
    pause
    exit /b 1
)

rem ---- 6. Launch Streamlit and open the browser ----
echo.
echo Starting AgentBank at http://localhost:8501  (press Ctrl+C in this window to stop)
echo No API key is needed. If Ollama is not running, the app uses its built-in rules engine.
echo.
start "" cmd /c "timeout /t 5 /nobreak >nul & start http://localhost:8501"
python -m streamlit run app.py
if errorlevel 1 (
    echo.
    echo [ERROR] Streamlit stopped with an error. See the messages above.
    pause
    exit /b 1
)
endlocal
