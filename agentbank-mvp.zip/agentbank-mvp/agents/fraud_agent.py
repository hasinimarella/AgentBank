"""Risk/Fraud Agent: explainable, rule-based risk scoring of a single transaction."""
from __future__ import annotations

from agents.base import AgentRequest, AgentResult, BaseAgent, failure_from_tool
from llm.base import Intent
from services.tool_executor import AgentToolbox


class FraudAgent(BaseAgent):
    name = "FraudAgent"
    description = ("Scores a transaction with a transparent weighted-rule engine (not machine learning) "
                   "and explains the contributing risk indicators. Suspicious is not the same as confirmed fraud.")
    supported_intents = (Intent.FRAUD_ASSESSMENT,)

    def handle(self, request: AgentRequest, tools: AgentToolbox) -> AgentResult:
        tid = request.entities["transaction_id"]
        txn = tools.call("get_transaction", transaction_id=tid)
        if not txn["ok"]:
            return failure_from_tool("get_transaction", txn, "fraud")
        risk = tools.call("calculate_fraud_risk", transaction_id=tid)
        if not risk["ok"]:
            return failure_from_tool("calculate_fraud_risk", risk, "fraud")
        return AgentResult("ok", "fraud", {"transaction": txn["data"], "assessment": risk["data"]})
