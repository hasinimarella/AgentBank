"""Customer/Banking Agent: balances, transaction history and the composite financial summary."""
from __future__ import annotations

from agents.base import AgentRequest, AgentResult, BaseAgent, failure_from_tool
from llm.base import Intent
from services.tool_executor import AgentToolbox
from tools.common import DEFAULT_TXN_LIMIT


class BankingAgent(BaseAgent):
    name = "BankingAgent"
    description = "Looks up customer profiles, account balances/status and transactions, and builds financial summaries."
    supported_intents = (Intent.ACCOUNT_BALANCE, Intent.TRANSACTION_HISTORY, Intent.CUSTOMER_FINANCIAL_SUMMARY,
                         Intent.SPENDING_ANALYSIS)

    def handle(self, request: AgentRequest, tools: AgentToolbox) -> AgentResult:
        if request.intent == Intent.ACCOUNT_BALANCE:
            return self._balance(request, tools)
        if request.intent == Intent.TRANSACTION_HISTORY:
            return self._history(request, tools)
        if request.intent == Intent.CUSTOMER_FINANCIAL_SUMMARY:
            return self._summary(request, tools)
        if request.intent == Intent.SPENDING_ANALYSIS:
            return self._spending(request, tools)
        return AgentResult("error", "none", errors=[{"tool": "-", "code": "UNSUPPORTED_INTENT",
                                                      "message": f"{self.name} cannot handle {request.intent.value}."}])

    def _balance(self, req: AgentRequest, tools: AgentToolbox) -> AgentResult:
        cid = req.entities["customer_id"]
        cust = tools.call("get_customer", customer_id=cid)
        if not cust["ok"]:
            return failure_from_tool("get_customer", cust, "balance")
        bal = tools.call("get_account_balance", customer_id=cid)
        if not bal["ok"]:
            return failure_from_tool("get_account_balance", bal, "balance")
        return AgentResult("ok", "balance", {"customer": cust["data"], "balance": bal["data"]})

    def _history(self, req: AgentRequest, tools: AgentToolbox) -> AgentResult:
        e = req.entities
        cid = e.get("customer_id")
        if cid is None:  # only a transaction ID was supplied: look up that single transaction
            txn = tools.call("get_transaction", transaction_id=e["transaction_id"])
            if not txn["ok"]:
                return failure_from_tool("get_transaction", txn, "transaction")
            return AgentResult("ok", "transaction", {"transaction": txn["data"]})

        cust = tools.call("get_customer", customer_id=cid)
        if not cust["ok"]:
            return failure_from_tool("get_customer", cust, "transactions")
        kwargs = {"customer_id": cid, "limit": e.get("limit") or DEFAULT_TXN_LIMIT}
        for key in ("status", "start_date", "end_date", "transaction_id"):
            if e.get(key):
                kwargs[key] = e[key]
        txns = tools.call("get_transactions", **kwargs)
        if not txns["ok"]:
            return failure_from_tool("get_transactions", txns, "transactions")
        return AgentResult("ok", "transactions", {
            "customer": cust["data"],
            "history": txns["data"],
            "filters": {k: v for k, v in kwargs.items() if k not in ("customer_id",)},
        })

    def _spending(self, req: AgentRequest, tools: AgentToolbox) -> AgentResult:
        cid = req.entities["customer_id"]
        cust = tools.call("get_customer", customer_id=cid)
        if not cust["ok"]:
            return failure_from_tool("get_customer", cust, "spending")
        kwargs = {"customer_id": cid}
        if req.entities.get("month"):
            kwargs["month"] = req.entities["month"]
        spend = tools.call("get_spending_analysis", **kwargs)
        if not spend["ok"]:
            return failure_from_tool("get_spending_analysis", spend, "spending")
        return AgentResult("ok", "spending", {"customer": cust["data"], "spending": spend["data"]})

    def _summary(self, req: AgentRequest, tools: AgentToolbox) -> AgentResult:
        """Composite workflow. Each step is a separately traced tool call, run in sequence."""
        cid = req.entities["customer_id"]
        cust = tools.call("get_customer", customer_id=cid)
        if not cust["ok"]:
            return failure_from_tool("get_customer", cust, "summary")

        errors: list[dict[str, str]] = []

        def grab(tool: str, **kwargs):
            res = tools.call(tool, **kwargs)
            if res["ok"]:
                return res["data"]
            errors.append({"tool": tool, **res["error"]})
            return None

        balance = grab("get_account_balance", customer_id=cid)
        txns = grab("get_transactions", customer_id=cid, limit=50)
        profile = grab("get_loan_profile", customer_id=cid)
        agg = tools.call("compute_financial_summary", customer=cust["data"], balance=balance,
                         transactions=txns, loan_profile=profile)
        if not agg["ok"]:
            return failure_from_tool("compute_financial_summary", agg, "summary")
        status = "partial" if errors else "ok"
        return AgentResult(status, "summary", {"summary": agg["data"]}, errors)
