"""Credit/Loan Agent: illustrative, threshold-based eligibility assessment."""
from __future__ import annotations

from agents.base import AgentRequest, AgentResult, BaseAgent, failure_from_tool
from llm.base import Intent
from services.tool_executor import AgentToolbox


class LoanAgent(BaseAgent):
    name = "LoanAgent"
    description = ("Evaluates a requested loan against configurable income, debt-to-income, credit-score "
                   "and employment thresholds. Illustrative only; it is not a lending decision.")
    supported_intents = (Intent.LOAN_ELIGIBILITY,)

    def handle(self, request: AgentRequest, tools: AgentToolbox) -> AgentResult:
        cid = request.entities["customer_id"]
        amount = request.entities["amount"]
        cust = tools.call("get_customer", customer_id=cid)
        if not cust["ok"]:
            return failure_from_tool("get_customer", cust, "loan")
        assessment = tools.call("assess_loan_eligibility", customer_id=cid, requested_amount=amount)
        if not assessment["ok"]:
            return failure_from_tool("assess_loan_eligibility", assessment, "loan")
        return AgentResult("ok", "loan", {"customer": cust["data"], "assessment": assessment["data"]})
