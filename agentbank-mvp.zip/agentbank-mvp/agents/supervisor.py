"""Supervisor / Orchestrator agent.

Pipeline for every message:
  sanitise input -> classify intent (LLM if healthy, else rules) -> validate entities ->
  ask for missing info -> route to a specialised agent -> agent runs allow-listed tools ->
  build a tool-backed answer -> record the trace.

The supervisor never answers from model memory: every figure in the reply comes from a tool.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from agents.banking_agent import BankingAgent
from agents.base import AgentRequest, AgentResult, BaseAgent
from agents.fraud_agent import FraudAgent
from agents.loan_agent import LoanAgent
from config.settings import Settings, get_settings
from llm.base import Intent, IntentResult, LLMError
from llm.entities import find_ids
from llm.factory import ProviderSelection, select_provider
from llm.fallback_provider import FallbackProvider
from services.audit_service import AuditService, Trace
from services.response_builder import (
    UNKNOWN_MESSAGE,
    UNSUPPORTED_ACTION_MESSAGE,
    build_response,
    clarification_message,
    numbers_grounded,
)
from services.router import AgentRouter
from services.tool_executor import AgentToolbox

MAX_MESSAGE_CHARS = 500
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


def sanitize_user_input(message: Any) -> tuple[str, bool]:
    """Strip control characters, collapse whitespace, cap length. Returns (text, was_truncated)."""
    if not isinstance(message, str):
        return "", False
    text = _CONTROL_RE.sub(" ", message)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > MAX_MESSAGE_CHARS:
        return text[:MAX_MESSAGE_CHARS], True
    return text, False


@dataclass
class SupervisorResponse:
    message: str
    status: str                       # ok | partial | clarification | unsupported | not_found | invalid_input | error | empty
    intent: str | None
    entities: dict[str, Any]
    agent: str | None
    result_type: str | None
    result_data: dict[str, Any]
    trace: dict[str, Any]
    mode: dict[str, Any]
    ai_summary: str | None = None
    notices: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


class Supervisor:
    def __init__(
        self,
        db_path: str | None = None,
        settings: Settings | None = None,
        selection: ProviderSelection | None = None,
    ):
        self.settings = settings or get_settings()
        self.db_path = db_path or self.settings.db_path
        self.selection = selection or select_provider(self.settings)
        self.fallback = FallbackProvider()
        self.agents: list[BaseAgent] = [BankingAgent(), FraudAgent(), LoanAgent()]
        self.router = AgentRouter(self.agents)
        self.audit = AuditService(self.db_path)

    # ---- public helpers ------------------------------------------------------------------------
    @property
    def mode(self) -> dict[str, Any]:
        return self.selection.describe()

    # ---- main entry point -------------------------------------------------------------------------
    def handle(self, message: str) -> SupervisorResponse:
        text, truncated = sanitize_user_input(message)
        trace = Trace(user_message=text, mode=self.mode)
        notices: list[str] = []
        if truncated:
            notices.append(f"Message was longer than {MAX_MESSAGE_CHARS} characters and was truncated.")

        if not text:
            trace.step("Supervisor", "validate_input", "empty message")
            trace.finish("empty")
            self.audit.record(trace)
            return self._response("Please type a question, for example: _What is the account balance for customer C1001?_",
                                  "empty", None, {}, None, None, {}, trace, notices)

        # 1. classify ------------------------------------------------------------------------------
        parsed = self._classify(text, trace, notices)
        trace.intent = parsed.intent.value
        trace.intent_source = parsed.source
        trace.confidence = round(parsed.confidence, 2)
        entities = parsed.entities()
        trace.entities = {k: v for k, v in entities.items() if v is not None}
        trace.step("Supervisor", "classify_intent", f"{parsed.intent.value} via {parsed.source}")

        # 2. unknown / unsupported -----------------------------------------------------------------
        if parsed.intent == Intent.UNKNOWN:
            action = FallbackProvider.is_unsupported_action(text)
            trace.step("Supervisor", "no_route", "unsupported action request" if action else "intent not recognised")
            trace.finish("unsupported")
            self.audit.record(trace)
            return self._response(UNSUPPORTED_ACTION_MESSAGE if action else UNKNOWN_MESSAGE, "unsupported",
                                  parsed.intent.value, trace.entities, None, None, {}, trace, notices)

        # 3. ambiguity: several different IDs in one message --------------------------------------------
        customers, txns = find_ids(text)
        if len(customers) > 1 or len(txns) > 1:
            which = "customers" if len(customers) > 1 else "transactions"
            trace.step("Supervisor", "clarify", f"multiple {which} mentioned")
            trace.finish("clarification")
            self.audit.record(trace)
            ids = ", ".join(customers if len(customers) > 1 else txns)
            return self._response(
                f"I found more than one ID in your message ({ids}). I handle one at a time. Which one should I use?",
                "clarification", parsed.intent.value, trace.entities, None, None, {}, trace, notices)

        # 4. required information -----------------------------------------------------------------------
        missing = self.router.missing_entities(parsed.intent, entities)
        if missing:
            trace.step("Supervisor", "clarify", "missing: " + "; ".join(missing))
            trace.finish("clarification")
            self.audit.record(trace)
            return self._response(clarification_message(parsed.intent, missing), "clarification",
                                  parsed.intent.value, trace.entities, None, None, {}, trace, notices)

        # 5. route ------------------------------------------------------------------------------------------
        agent = self.router.route(parsed.intent)
        if agent is None:  # defensive: every supported intent has an agent
            trace.step("Supervisor", "no_route", "no agent registered")
            trace.finish("error")
            self.audit.record(trace)
            return self._response("No specialised agent is available for that request.", "error",
                                  parsed.intent.value, trace.entities, None, None, {}, trace, notices)
        trace.selected_agent = agent.name
        trace.step("Supervisor", "route", f"{parsed.intent.value} -> {agent.name}")

        # 6. run the agent inside an error boundary -----------------------------------------------------
        toolbox = AgentToolbox(agent.name, trace, self.settings, self.db_path)
        trace.step(agent.name, "start", "handling request")
        try:
            result = agent.handle(AgentRequest(parsed.intent, entities), toolbox)
        except Exception as exc:
            result = AgentResult("error", "none", errors=[{"tool": "-", "code": "AGENT_EXCEPTION",
                                                            "message": f"{agent.name} failed ({type(exc).__name__})."}])
            trace.step(agent.name, "exception", type(exc).__name__)

        # 7. respond --------------------------------------------------------------------------------------------
        answer = build_response(parsed.intent, result)
        ai_summary = self._maybe_formulate(text, answer, result, trace, notices)
        trace.finish(result.status)
        self.audit.record(trace)
        return self._response(answer, result.status, parsed.intent.value, trace.entities, agent.name,
                              result.result_type, result.data, trace, notices, ai_summary)

    # ---- internals ----------------------------------------------------------------------------------------------
    def _classify(self, text: str, trace: Trace, notices: list[str]) -> IntentResult:
        provider = self.selection.llm
        if provider is None:
            trace.llm = {"used": False, "reason": self.selection.detail}
            trace.step("Supervisor", "mode", "fallback rules (no LLM call)")
            return self.fallback.classify_intent(text)
        try:
            parsed = provider.classify_intent(text)
            trace.llm = {"used": True, "provider": provider.name, "model": provider.model, "validated": True}
            trace.step("Supervisor", "llm_call", f"{provider.name}/{provider.model} output validated")
            return parsed
        except LLMError as exc:
            reason = str(exc)[:200]
            trace.llm = {"used": False, "provider": provider.name, "model": provider.model,
                         "error": reason, "fell_back": True}
            trace.step("Supervisor", "llm_failed", reason)
            notices.append(f"LLM unavailable or invalid for this request ({reason}); used the deterministic fallback instead.")
            return self.fallback.classify_intent(text)

    def _maybe_formulate(self, text: str, answer: str, result: AgentResult, trace: Trace, notices: list[str]) -> str | None:
        provider = self.selection.llm
        if provider is None or not self.settings.llm.formulate_responses:
            return None
        if not trace.llm.get("used") or not result.succeeded:
            return None
        try:
            phrased = provider.formulate(text, answer)
        except LLMError as exc:
            trace.step("Supervisor", "llm_formulate_failed", str(exc)[:120])
            return None
        if not phrased:
            return None
        if not numbers_grounded(phrased, answer, result.data):
            trace.step("Supervisor", "llm_formulate_rejected", "contained numbers not found in tool results")
            notices.append("An AI-phrased summary was discarded because it contained unverified numbers.")
            return None
        trace.step("Supervisor", "llm_formulate", "AI-phrased summary accepted after number check")
        return phrased

    def _response(self, message, status, intent, entities, agent, result_type, data, trace: Trace,
                  notices, ai_summary=None) -> SupervisorResponse:
        return SupervisorResponse(
            message=message, status=status, intent=intent, entities=entities, agent=agent,
            result_type=result_type, result_data=data, trace=trace.to_dict(), mode=self.mode,
            ai_summary=ai_summary, notices=notices)
