"""Common agent contract."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from llm.base import Intent
from services.tool_executor import AgentToolbox


@dataclass
class AgentRequest:
    intent: Intent
    entities: dict[str, Any]


@dataclass
class AgentResult:
    status: str                      # ok | partial | not_found | invalid_input | error
    result_type: str                 # balance | transactions | transaction | fraud | loan | summary | none
    data: dict[str, Any] = field(default_factory=dict)
    errors: list[dict[str, str]] = field(default_factory=list)   # [{"tool","code","message"}]

    @property
    def succeeded(self) -> bool:
        return self.status in ("ok", "partial")


NOT_FOUND_CODES = {"CUSTOMER_NOT_FOUND", "TRANSACTION_NOT_FOUND", "NO_ACCOUNTS"}


def failure_from_tool(tool: str, result: dict[str, Any], result_type: str = "none") -> AgentResult:
    """Convert a failed tool envelope into an AgentResult with the right status."""
    error = result["error"]
    code = error["code"]
    if code in NOT_FOUND_CODES:
        status = "not_found"
    elif code.startswith("INVALID_"):
        status = "invalid_input"
    else:
        status = "error"
    return AgentResult(status=status, result_type=result_type,
                       errors=[{"tool": tool, "code": code, "message": error["message"]}])


class BaseAgent(ABC):
    name: str = "BaseAgent"
    description: str = ""
    supported_intents: tuple[Intent, ...] = ()

    @abstractmethod
    def handle(self, request: AgentRequest, tools: AgentToolbox) -> AgentResult:
        ...
