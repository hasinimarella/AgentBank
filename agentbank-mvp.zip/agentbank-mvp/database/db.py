"""SQLite helpers. Every query in the project is parameterised."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from config.settings import get_settings

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"


def connect(db_path: str | None = None) -> sqlite3.Connection:
    """Open a connection with row access by column name and FK enforcement."""
    path = db_path or get_settings().db_path
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def create_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    conn.commit()


def database_ready(db_path: str | None = None) -> bool:
    """True when the DB file exists and contains seeded customers."""
    path = Path(db_path or get_settings().db_path)
    if not path.exists():
        return False
    try:
        conn = connect(str(path))
        try:
            row = conn.execute("SELECT COUNT(*) AS n FROM customers").fetchone()
            return bool(row and row["n"] > 0)
        finally:
            conn.close()
    except sqlite3.Error:
        return False


def rows_to_dicts(rows) -> list[dict]:
    return [dict(r) for r in rows]
