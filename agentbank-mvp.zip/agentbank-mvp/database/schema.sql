-- AgentBank simulated banking schema. All data is synthetic.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS customers (
    customer_id        TEXT PRIMARY KEY CHECK (customer_id GLOB 'C[0-9][0-9][0-9][0-9]'),
    full_name          TEXT NOT NULL,
    email              TEXT NOT NULL,
    phone              TEXT NOT NULL,
    home_city          TEXT NOT NULL,
    home_country       TEXT NOT NULL DEFAULT 'IN',
    kyc_status         TEXT NOT NULL CHECK (kyc_status IN ('VERIFIED','PENDING','EXPIRED')),
    customer_since     TEXT NOT NULL,           -- ISO date
    -- Financial profile used by the illustrative loan engine (NULL = not on file)
    monthly_income     REAL CHECK (monthly_income IS NULL OR monthly_income >= 0),
    monthly_debt       REAL CHECK (monthly_debt IS NULL OR monthly_debt >= 0),
    employment_status  TEXT,
    employment_years   REAL CHECK (employment_years IS NULL OR employment_years >= 0),
    credit_score       INTEGER CHECK (credit_score IS NULL OR credit_score BETWEEN 300 AND 900)
);

CREATE TABLE IF NOT EXISTS accounts (
    account_id    TEXT PRIMARY KEY,
    customer_id   TEXT NOT NULL REFERENCES customers(customer_id),
    account_type  TEXT NOT NULL CHECK (account_type IN ('SAVINGS','CURRENT','SALARY')),
    balance       REAL NOT NULL,
    currency      TEXT NOT NULL DEFAULT 'INR',
    status        TEXT NOT NULL CHECK (status IN ('ACTIVE','DORMANT','FROZEN','CLOSED')),
    opened_on     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id TEXT PRIMARY KEY CHECK (transaction_id GLOB 'TXN-[0-9][0-9][0-9][0-9]*'),
    customer_id    TEXT NOT NULL REFERENCES customers(customer_id),
    account_id     TEXT NOT NULL REFERENCES accounts(account_id),
    amount         REAL NOT NULL CHECK (amount > 0),
    direction      TEXT NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
    merchant       TEXT NOT NULL,
    category       TEXT NOT NULL,
    city           TEXT NOT NULL,
    country        TEXT NOT NULL,
    channel        TEXT NOT NULL CHECK (channel IN ('UPI','CARD','NETBANKING','ATM','BRANCH')),
    status         TEXT NOT NULL CHECK (status IN ('COMPLETED','PENDING','FAILED')),
    occurred_at    TEXT NOT NULL                -- ISO 8601 timestamp, naive local time
);
CREATE INDEX IF NOT EXISTS idx_txn_customer_time ON transactions(customer_id, occurred_at);

-- Stored loan assessments (illustrative; written only when persistence is requested)
CREATE TABLE IF NOT EXISTS loan_assessments (
    assessment_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id       TEXT NOT NULL REFERENCES customers(customer_id),
    requested_amount  REAL NOT NULL,
    decision          TEXT NOT NULL,
    dti_after_loan    REAL,
    created_at        TEXT NOT NULL
);

-- Execution audit trail (sanitised; no secrets, no raw model output)
CREATE TABLE IF NOT EXISTS audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id        TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    intent          TEXT,
    selected_agent  TEXT,
    llm_mode        TEXT,
    status          TEXT,
    trace_json      TEXT NOT NULL
);
